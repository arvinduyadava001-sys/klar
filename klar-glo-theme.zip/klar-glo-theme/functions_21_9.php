<?php
/**
 * Skincare Clean theme functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SC_THEME_VERSION', '1.0.2-' . time() );

/** ---------------------------------------------------------
 * Theme setup
 * --------------------------------------------------------- */
function sc_setup() {
	load_theme_textdomain( 'skincare-clean', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'woocommerce' ); // WooCommerce compatibility, matches storefront-style layout

	register_nav_menus( array(
		'top-bar' => __( 'Top Announcement Bar', 'skincare-clean' ),
		'primary' => __( 'Primary Navigation', 'skincare-clean' ),
		'footer-1' => __( 'Footer Column 1', 'skincare-clean' ),
		'footer-2' => __( 'Footer Column 2', 'skincare-clean' ),
		'footer-3' => __( 'Footer Column 3', 'skincare-clean' ),
	) );
}
add_action( 'after_setup_theme', 'sc_setup' );

/** ---------------------------------------------------------
 * Enqueue styles & scripts
 * --------------------------------------------------------- */
function sc_scripts() {
	wp_enqueue_style( 'skincare-clean-style', get_stylesheet_uri(), array(), SC_THEME_VERSION );
	wp_enqueue_script( 'skincare-clean-main', get_template_directory_uri() . '/assets/js/main.js', array(), SC_THEME_VERSION, true );

	if ( is_singular() && comments_open() ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'sc_scripts' );

/** ---------------------------------------------------------
 * Widgets
 * --------------------------------------------------------- */
function sc_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Shop Sidebar', 'skincare-clean' ),
		'id'            => 'shop-sidebar',
		'before_widget' => '<div class="sc-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'sc_widgets_init' );

/** ---------------------------------------------------------
 * Excerpt length / more
 * --------------------------------------------------------- */
add_filter( 'excerpt_length', function( $length ) { return 22; } );
add_filter( 'excerpt_more', function( $more ) { return '&hellip;'; } );

/** ---------------------------------------------------------
 * Includes
 * --------------------------------------------------------- */
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/product-details.php';

/** ---------------------------------------------------------
 * WooCommerce theme support tweaks
 * --------------------------------------------------------- */
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

function sc_woocommerce_loop_columns() {
	return 4;
}
add_filter( 'loop_shop_columns', 'sc_woocommerce_loop_columns' );

/** ---------------------------------------------------------
 * Move the product Description out of the tabs and place it
 * wherever you like on the single product page.
 * --------------------------------------------------------- */

// 1) Remove "Description" from the default tabs (Additional Info / Reviews stay).
add_filter( 'woocommerce_product_tabs', function( $tabs ) {
	unset( $tabs['description'] );
	return $tabs;
} );

// The subtitle, feature checkmarks, and "Key Actives & Benefits" / "How to Use" /
// "Full Ingredients" accordions (see inc/product-details.php) now cover what the
// short description AND the old full-width Description block used to show —
// so both are disabled below to avoid repeating the same copy twice.
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
