<?php
/**
 * Custom archive-product.php for Skincare Clean theme
 * Based on WooCommerce core template structure.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );
?>
<div class="container sc-section">

	<header class="sc-page-header">
		<span class="sc-eyebrow"><?php esc_html_e( 'Shop the Range', 'skincare-clean' ); ?></span>
		<h1><?php echo is_search() ? esc_html__( 'Search Results', 'skincare-clean' ) : esc_html__( 'All Products', 'skincare-clean' ); ?></h1>
	</header>

	<?php do_action( 'woocommerce_before_main_content' ); ?>

	<?php if ( woocommerce_product_loop() ) : ?>

		<?php do_action( 'woocommerce_before_shop_loop' ); ?>

		<?php woocommerce_product_loop_start(); ?>

		<?php if ( wc_get_loop_prop( 'total' ) ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php wc_get_template_part( 'content', 'product' ); ?>
			<?php endwhile; ?>
		<?php endif; ?>

		<?php woocommerce_product_loop_end(); ?>

		<?php do_action( 'woocommerce_after_shop_loop' ); ?>

	<?php else : ?>

		<?php do_action( 'woocommerce_no_products_found' ); ?>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_main_content' ); ?>

</div>
<?php get_footer( 'shop' ); ?>
