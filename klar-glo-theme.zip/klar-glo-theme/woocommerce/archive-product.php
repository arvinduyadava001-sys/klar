<?php
/**
 * Custom archive-product.php for Skincare Clean theme
 * Based on WooCommerce core template structure.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );
?>
<?php
// Category / concern landing page data (title, description, banner)
$sc_term   = is_product_taxonomy() ? get_queried_object() : null;
$sc_term   = ( $sc_term && ! is_wp_error( $sc_term ) && isset( $sc_term->term_id ) ) ? $sc_term : null;
$sc_banner   = '';
$sc_banner_w = 0;
if ( $sc_term ) {
	$sc_thumb_id = (int) get_term_meta( $sc_term->term_id, 'thumbnail_id', true );
	if ( $sc_thumb_id ) {
		$sc_src = wp_get_attachment_image_src( $sc_thumb_id, 'full' );
		if ( $sc_src ) {
			$sc_banner   = $sc_src[0];
			$sc_banner_w = (int) $sc_src[1];
		}
	}
	if ( ! $sc_banner ) { // bundled wide banner (slug-banner.jpg), then the small concern tile photo
		foreach ( array( $sc_term->slug . '-banner', $sc_term->slug ) as $sc_name ) {
			foreach ( array( 'jpg', 'jpeg', 'png', 'webp' ) as $sc_ext ) {
				$sc_rel = '/assets/img/concerns/' . $sc_name . '.' . $sc_ext;
				$sc_abs = get_template_directory() . $sc_rel;
				if ( file_exists( $sc_abs ) ) {
					$sc_size     = @getimagesize( $sc_abs );
					$sc_banner   = get_template_directory_uri() . $sc_rel;
					$sc_banner_w = $sc_size ? (int) $sc_size[0] : 0;
					break 2;
				}
			}
		}
	}
}
// Wide photo (1200px+) -> full-width hero banner. Small photo -> shown at a sharp, smaller size.
$sc_wide    = $sc_term && $sc_banner && $sc_banner_w >= 1200;
$sc_total   = $sc_term ? (int) wc_get_loop_prop( 'total' ) : 0;
$sc_eyebrow = ( $sc_term && array_key_exists( $sc_term->slug, sc_concern_definitions() ) ) ? __( 'Shop by Concern', 'skincare-clean' ) : __( 'Shop the Range', 'skincare-clean' );
?>
<?php if ( $sc_term && $sc_banner ) : ?>
<header class="sc-concern-banner<?php echo $sc_wide ? '' : ' is-soft'; ?>"<?php echo $sc_wide ? ' style="background-image:url(\'' . esc_url( $sc_banner ) . '\');"' : ''; ?>>
	<?php if ( ! $sc_wide ) : // small photo: soft blurred backdrop + the sharp photo at its real size ?>
		<span class="sc-concern-banner-bg" style="background-image:url('<?php echo esc_url( $sc_banner ); ?>');"></span>
	<?php endif; ?>
	<div class="container">
		<div class="sc-concern-banner-row">
			<div class="sc-concern-banner-inner">
				<span class="sc-eyebrow"><?php echo esc_html( $sc_eyebrow ); ?></span>
				<h1><?php echo esc_html( $sc_term->name ); ?></h1>
				<?php if ( term_description() ) : ?>
					<div class="sc-concern-hero-desc"><?php echo wp_kses_post( term_description() ); ?></div>
				<?php endif; ?>
				<?php if ( $sc_total > 0 ) : ?>
					<div class="sc-concern-hero-count"><?php echo esc_html( sprintf( _n( '%d product', '%d products', $sc_total, 'skincare-clean' ), $sc_total ) ); ?></div>
				<?php endif; ?>
			</div>
			<?php if ( ! $sc_wide ) : ?>
				<div class="sc-concern-hero-img" role="img" aria-label="<?php echo esc_attr( $sc_term->name ); ?>" style="background-image:url('<?php echo esc_url( $sc_banner ); ?>');"></div>
			<?php endif; ?>
		</div>
	</div>
</header>
<?php endif; ?>
<div class="container sc-section">

<?php if ( $sc_term && ! $sc_banner ) : ?>
	<header class="sc-concern-hero">
		<div class="sc-concern-hero-text">
			<span class="sc-eyebrow"><?php echo esc_html( $sc_eyebrow ); ?></span>
			<h1><?php echo esc_html( $sc_term->name ); ?></h1>
			<?php if ( term_description() ) : ?>
				<div class="sc-concern-hero-desc"><?php echo wp_kses_post( term_description() ); ?></div>
			<?php endif; ?>
			<?php if ( $sc_total > 0 ) : ?>
				<div class="sc-concern-hero-count"><?php echo esc_html( sprintf( _n( '%d product', '%d products', $sc_total, 'skincare-clean' ), $sc_total ) ); ?></div>
			<?php endif; ?>
		</div>
	</header>
<?php elseif ( ! $sc_term ) : ?>
	<header class="sc-page-header">
		<span class="sc-eyebrow"><?php esc_html_e( 'Shop the Range', 'skincare-clean' ); ?></span>
		<h1><?php echo is_search() ? esc_html__( 'Search Results', 'skincare-clean' ) : esc_html__( 'All Products', 'skincare-clean' ); ?></h1>
	</header>
<?php endif; ?>

	<?php do_action( 'woocommerce_before_main_content' ); ?>

	<?php if ( woocommerce_product_loop() ) : ?>

		<?php do_action( 'woocommerce_before_shop_loop' ); ?>

		<?php woocommerce_product_loop_start(); ?>

		<?php if ( wc_get_loop_prop( 'total' ) ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php wc_get_template_part( 'content', 'product' ); ?>
			<?php endwhile; ?>
		<?php endif; ?>

		<?php woocommerce_product_loop_end(); ?>

		<?php do_action( 'woocommerce_after_shop_loop' ); ?>

	<?php else : ?>

		<?php if ( $sc_term ) : ?>
			<div class="sc-concern-empty">
				<p><?php esc_html_e( 'Products for this concern are coming soon.', 'skincare-clean' ); ?></p>
				<a class="sc-btn" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Shop All Products', 'skincare-clean' ); ?></a>
			</div>
		<?php else : ?>
			<?php do_action( 'woocommerce_no_products_found' ); ?>
		<?php endif; ?>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_main_content' ); ?>

</div>
<?php get_footer( 'shop' ); ?>
