<?php
/**
 * Shop / category loop product card — KLAR & GLO custom layout.
 * Matches the same card design used on the homepage Bestsellers row,
 * so the Shop page no longer falls back to WooCommerce's bare default
 * markup. Based on WooCommerce core's content-product.php, same hooks kept.
 */
defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<li <?php wc_product_class( 'sc-product-card', $product ); ?>>
	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

	<?php if ( $product->is_on_sale() ) : ?>
		<span class="sc-product-badge"><?php esc_html_e( 'Sale', 'skincare-clean' ); ?></span>
	<?php endif; ?>

	<a href="<?php the_permalink(); ?>" class="sc-product-thumb">
		<?php echo sc_product_thumb_markup( get_the_ID(), get_the_title() ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</a>

	<div class="sc-product-title"><?php the_title(); ?></div>

	<div class="sc-product-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>

	<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</li>