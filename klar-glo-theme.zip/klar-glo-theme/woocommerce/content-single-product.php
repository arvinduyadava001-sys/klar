<?php
/**
 * Custom content-single-product.php for Skincare Clean / KLAR & GLO theme.
 * Based on WooCommerce core's own template structure — keeps all standard
 * hooks (gallery, price, add-to-cart, variations, tabs, related products)
 * so cart/checkout/reviews keep working exactly as WooCommerce expects.
 * Only the wrapping markup/classes are ours, so our CSS applies directly
 * without needing heavy specificity overrides.
 */
defined( 'ABSPATH' ) || exit;

global $product;

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'sc-single-product-inner', $product ); ?>>

	<?php
	/**
	 * Hook: woocommerce_before_single_product_summary.
	 * Default: product gallery (images), sale flash badge.
	 */
	do_action( 'woocommerce_before_single_product_summary' );
	?>

	<div class="summary entry-summary">
		<?php
		/**
		 * Hook: woocommerce_single_product_summary.
		 * Default: title, rating, price, short description, add-to-cart
		 * form (with variations if applicable), meta (SKU/categories).
		 */
		 do_action( 'woocommerce_single_product_summary' );
		?>
	</div><!-- .summary -->

	<?php
	/**
	 * Hook: woocommerce_after_single_product_summary.
	 * Default: description/reviews tabs, upsells, related products.
	 */
	do_action( 'woocommerce_after_single_product_summary' );
	?>

</div><!-- #product-<?php the_ID(); ?> -->
