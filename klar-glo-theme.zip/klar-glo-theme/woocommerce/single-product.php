<?php
/**
 * Custom single-product.php for Skincare Clean / KLAR & GLO theme.
 * Wraps WooCommerce's own content-single-product template part with our
 * theme's header/footer and container styling.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );
?>
<div class="container sc-section sc-single-product">

	<?php do_action( 'woocommerce_before_main_content' ); ?>

	<?php while ( have_posts() ) : the_post(); ?>

		<?php wc_get_template_part( 'content', 'single-product' ); ?>

	<?php endwhile; ?>

	<?php do_action( 'woocommerce_after_main_content' ); ?>

</div>
<?php get_footer( 'shop' ); ?>
