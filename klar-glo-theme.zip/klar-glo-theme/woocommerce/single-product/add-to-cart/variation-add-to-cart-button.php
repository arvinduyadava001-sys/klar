<?php
/**
 * Variation add-to-cart button — KLAR & GLO custom layout.
 * Shown inside .single_variation_wrap once a variation is matched.
 * Based on WooCommerce core's variation-add-to-cart-button.php.
 */
defined( 'ABSPATH' ) || exit;

global $product;

$min_value      = apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product );
$max_value      = apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product );
$step           = apply_filters( 'woocommerce_quantity_input_step', 1, $product );
$input_value    = isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $min_value; // phpcs:ignore WordPress.Security.NonceVerification
?>
<div class="woocommerce-variation-add-to-cart variations_button">

	<?php do_action( 'woocommerce_before_add_to_cart_quantity' ); ?>

	<?php
	if ( ! $product->is_sold_individually() ) {
		echo '<div class="sc-qty-row"><span class="sc-qty-label">' . esc_html__( 'Quantity', 'skincare-clean' ) . '</span>';
		woocommerce_quantity_input(
			array(
				'min_value'   => $min_value,
				'max_value'   => $max_value,
				'input_value' => $input_value,
				'step'        => $step,
			)
		);
		echo '</div>';
	}
	?>

	<?php do_action( 'woocommerce_after_add_to_cart_quantity' ); ?>



</div>
<br/><br/><br/>
	<div class="sc-cart-buttons">
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="single_add_to_cart_button button alt"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="sc-buy-now-button" data-sc-buy-now><?php esc_html_e( 'Buy It Now', 'skincare-clean' ); ?></button>
		<input type="hidden" name="buy_now" value="" data-sc-buy-now-flag />
		<input type="hidden" name="variation_id" class="variation_id" value="0" />
	</div>
