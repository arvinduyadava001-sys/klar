<?php
/**
 * Variable product add-to-cart template — KLAR & GLO custom layout.
 * Renders each attribute (e.g. "Size") as pill buttons instead of a
 * dropdown, while keeping WooCommerce's native <select> elements in
 * the markup (visually hidden) so its variation-matching JS keeps
 * working untouched. Quantity stepper + Add to Cart + Buy It Now
 * come from variation-add-to-cart-button.php below.
 *
 * Based on WooCommerce core's variable.php, same hooks/data kept intact.
 */
defined( 'ABSPATH' ) || exit;

global $product;

$attribute_keys  = array_keys( $attributes );
$variations_json = wp_json_encode( $available_variations );
$variations_attr = function_exists( 'wc_esc_json' ) ? wc_esc_json( $variations_json ) : _wp_specialchars( $variations_json, ENT_QUOTES, 'UTF-8', true );
?>

<?php do_action( 'woocommerce_before_add_to_cart_form' ); ?>

<form class="variations_form cart sc-add-to-cart-form" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint( $product->get_id() ); ?>" data-product_variations="<?php echo $variations_attr; ?>">
	<?php do_action( 'woocommerce_before_variations_form' ); ?>

	<?php if ( empty( $available_variations ) && false !== $available_variations ) : ?>
		<p class="stock out-of-stock"><?php echo esc_html( apply_filters( 'woocommerce_out_of_stock_message', __( 'This product is currently out of stock and unavailable.', 'woocommerce' ) ) ); ?></p>
	<?php else : ?>

		<div class="variations sc-variations-wrap">
			<?php foreach ( $attributes as $attribute_name => $options ) :
				$attribute_id     = sanitize_title( $attribute_name );
				$selected_value   = isset( $_REQUEST[ 'attribute_' . $attribute_id ] ) ? wc_clean( wp_unslash( $_REQUEST[ 'attribute_' . $attribute_id ] ) ) : $product->get_variation_default_attribute( $attribute_name ); // phpcs:ignore WordPress.Security.NonceVerification
				?>
				<div class="sc-variation-row" data-sc-variation-swatch data-attribute_name="attribute_<?php echo esc_attr( $attribute_id ); ?>">
					<span class="sc-variation-label"><?php echo esc_html( wc_attribute_label( $attribute_name ) ); ?><?php echo $selected_value ? ': <strong class="sc-variation-selected">' . esc_html( $selected_value ) . '</strong>' : ''; ?></span>

					<div class="sc-variation-pills">
						<?php
						if ( is_object( $options ) ) {
							// Product-level attribute (taxonomy) options.
							$options = wc_get_product_terms( $product->get_id(), $attribute_name, array( 'fields' => 'slugs' ) );
						}
						foreach ( $options as $option ) :
							$term = taxonomy_exists( $attribute_name ) ? get_term_by( 'slug', $option, $attribute_name ) : false;
							$label = $term && ! is_wp_error( $term ) ? $term->name : $option;
							?>
							<button
								type="button"
								class="sc-variation-pill <?php echo ( $selected_value === $option ) ? 'is-active' : ''; ?>"
								data-value="<?php echo esc_attr( $option ); ?>"
							><?php echo esc_html( $label ); ?></button>
						<?php endforeach; ?>
					</div>

					<!-- Native select kept for WooCommerce's variation-matching JS; visually hidden. -->
					<select
						id="<?php echo esc_attr( $attribute_id ); ?>"
						class="sc-visually-hidden-select"
						name="attribute_<?php echo esc_attr( $attribute_id ); ?>"
						data-attribute_name="attribute_<?php echo esc_attr( $attribute_id ); ?>"
					>
						<option value=""><?php esc_html_e( 'Choose an option', 'woocommerce' ); ?></option>
						<?php
						if ( is_object( $options ) ) {
							$options = wc_get_product_terms( $product->get_id(), $attribute_name, array( 'fields' => 'slugs' ) );
						}
						foreach ( $options as $option ) :
							$term = taxonomy_exists( $attribute_name ) ? get_term_by( 'slug', $option, $attribute_name ) : false;
							$label = $term && ! is_wp_error( $term ) ? $term->name : $option;
							?>
							<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $selected_value, $option ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			<?php endforeach; ?>
		</div>

		<?php do_action( 'woocommerce_before_single_variation' ); ?>

		<div class="single_variation_wrap">
			<?php
				do_action( 'woocommerce_single_variation' );
				do_action( 'woocommerce_after_single_variation' );
			?>
		</div>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_variations_form' ); ?>
</form>

<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>