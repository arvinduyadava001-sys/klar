<?php
/**
 * Simple product add-to-cart template — KLAR & GLO custom layout.
 * Quantity stepper + full-width "Add to Cart" + "Buy It Now" button.
 * Based on WooCommerce core's simple.php, same hooks kept intact.
 */
defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product->is_purchasable() ) {
	return;
}

echo wc_get_stock_html( $product ); // WPCS: XSS ok.

if ( $product->is_in_stock() ) :
	?>

	<?php do_action( 'woocommerce_before_add_to_cart_form' ); ?>

	<form class="cart sc-add-to-cart-form" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>

		<?php
		if ( ! $product->is_sold_individually() ) {
			echo '<div class="sc-qty-row"><span class="sc-qty-label">' . esc_html__( 'Quantity', 'skincare-clean' ) . '</span>';
			woocommerce_quantity_input(
				array(
					'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
					'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
					'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // phpcs:ignore WordPress.Security.NonceVerification
				)
			);
			echo '</div>';
		}
		?>

		<?php do_action( 'woocommerce_after_add_to_cart_quantity' ); ?>

		<div class="sc-cart-buttons">
			<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="single_add_to_cart_button button alt"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
			<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="sc-buy-now-button" data-sc-buy-now><?php esc_html_e( 'Buy It Now', 'skincare-clean' ); ?></button>
			<input type="hidden" name="buy_now" value="" data-sc-buy-now-flag />
		</div>

		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>

	<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>

<?php endif; ?>
