<?php
/**
 * Single product gallery (custom for KLAR & GLO).
 * Main image + thumbnails, arrows, swipe, counter and full-screen zoom.
 * Uses the product's featured image + every image added in the WooCommerce
 * "Product gallery" box, in that order.
 */
defined( 'ABSPATH' ) || exit;

global $product;
if ( ! $product ) {
	return;
}

$ids = array();
$main_id = $product->get_image_id();
if ( $main_id ) {
	$ids[] = (int) $main_id;
}
foreach ( $product->get_gallery_image_ids() as $gid ) {
	$ids[] = (int) $gid;
}
$ids = array_values( array_unique( $ids ) );

$slides = array();
foreach ( $ids as $id ) {
	$full = wp_get_attachment_image_src( $id, 'full' );
	if ( ! $full ) {
		continue;
	}
	$thumb = wp_get_attachment_image_src( $id, 'medium' );
	$alt   = get_post_meta( $id, '_wp_attachment_image_alt', true );
	$slides[] = array(
		'id'    => $id,
		'full'  => $full[0],
		'thumb' => $thumb ? $thumb[0] : $full[0],
		'alt'   => $alt ? $alt : $product->get_name(),
	);
}

// No images uploaded yet: fall back to the bundled picture / WooCommerce placeholder
if ( empty( $slides ) ) {
	$slug = get_post_field( 'post_name', $product->get_id() );
	$fb   = function_exists( 'sc_product_bundled_image' ) ? sc_product_bundled_image( $slug ) : '';
	$src  = $fb ? $fb : wc_placeholder_img_src( 'woocommerce_single' );
	$slides[] = array( 'id' => 0, 'full' => $src, 'thumb' => $src, 'alt' => $product->get_name() );
}
$n = count( $slides );
?>
<div class="sc-gallery" data-sc-gallery data-count="<?php echo esc_attr( $n ); ?>">
	<div class="sc-gallery-stage">
		<div class="sc-gallery-track" data-sc-gallery-track>
			<?php foreach ( $slides as $i => $s ) : ?>
				<div class="sc-gallery-slide" data-full="<?php echo esc_url( $s['full'] ); ?>">
					<?php
					if ( $s['id'] ) {
						echo wp_get_attachment_image( $s['id'], 'large', false, array(
							'class'    => 'sc-gallery-img',
							'alt'      => $s['alt'],
							'loading'  => 0 === $i ? 'eager' : 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 900px) 100vw, 50vw',
						) );
					} else {
						echo '<img class="sc-gallery-img" src="' . esc_url( $s['full'] ) . '" alt="' . esc_attr( $s['alt'] ) . '">';
					}
					?>
				</div>
			<?php endforeach; ?>
		</div>

		<button type="button" class="sc-gallery-zoom" data-sc-gallery-zoom aria-label="<?php esc_attr_e( 'View full size', 'skincare-clean' ); ?>">
			<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2M11 8v6M8 11h6"/></svg>
		</button>

		<?php if ( $n > 1 ) : ?>
			<button type="button" class="sc-gallery-arrow prev" data-sc-gallery-prev aria-label="<?php esc_attr_e( 'Previous image', 'skincare-clean' ); ?>">&#8249;</button>
			<button type="button" class="sc-gallery-arrow next" data-sc-gallery-next aria-label="<?php esc_attr_e( 'Next image', 'skincare-clean' ); ?>">&#8250;</button>
			<div class="sc-gallery-count" data-sc-gallery-count>1 / <?php echo esc_html( $n ); ?></div>
		<?php endif; ?>
	</div>

	<?php if ( $n > 1 ) : ?>
		<div class="sc-gallery-thumbs" data-sc-gallery-thumbs>
			<?php foreach ( $slides as $i => $s ) : ?>
				<button type="button" class="sc-gallery-thumb<?php echo 0 === $i ? ' is-active' : ''; ?>" data-index="<?php echo esc_attr( $i ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show image %d', 'skincare-clean' ), $i + 1 ) ); ?>">
					<img src="<?php echo esc_url( $s['thumb'] ); ?>" alt="" loading="lazy">
				</button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
