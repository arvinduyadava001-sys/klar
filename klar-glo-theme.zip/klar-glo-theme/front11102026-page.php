<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

$slide_content_defaults = array(
	1 => array(
		'title'    => 'Korean-Inspired Skincare, Made Simple.',
		'subtitle' => 'KLAR & GLO formulations are built on Niacinamide, Centella Asiatica and Ginseng Exosome technology — for a clearer, calmer, more radiant barrier.',
		'btn'      => 'Shop Bestsellers',
		'url'      => '#bestsellers',
	),
	2 => array(
		'title'    => 'Broad Spectrum Sun Protection.',
		'subtitle' => 'White-cast free, non-comedogenic Sunscreen with Niacinamide 2% and Korean Ginseng Exosome.',
		'btn'      => 'Shop Sunscreen',
		'url'      => '#sunscreen',
	),
	3 => array(
		'title'    => '10% Niacinamide Glow Serum.',
		'subtitle' => 'Brightens uneven tone, fades dark spots, and repairs the skin barrier.',
		'btn'      => 'Shop Serums',
		'url'      => '#serums',
	),
);
$slide_banner_defaults = array(
	1 => 'hero-banner.png',
	2 => 'hero-banner-2.png',
	3 => 'hero-banner-3.png',
);

$slides = array();
for ( $i = 1; $i <= 3; $i++ ) {
	$cd = $slide_content_defaults[ $i ];
	$default_image_path = get_template_directory() . '/assets/img/' . $slide_banner_defaults[ $i ];
	$default_image_url  = get_template_directory_uri() . '/assets/img/' . $slide_banner_defaults[ $i ];
	if ( file_exists( $default_image_path ) ) {
		$default_image_url = add_query_arg( 'v', filemtime( $default_image_path ), $default_image_url );
	}
	$img_url = get_theme_mod( "sc_hero_slide{$i}_image", $default_image_url );
	// Cache-bust ANY hero image URL (default or Customizer-set) so hosting/CDN
	// caches never serve a stale banner after it's replaced on the server.
	if ( $img_url ) {
		$img_url = add_query_arg( 'scv', defined( 'SC_THEME_VERSION' ) ? SC_THEME_VERSION : time(), $img_url );
	}
	$slides[] = array(
		'image'    => $img_url,
		'video'    => get_theme_mod( "sc_hero_slide{$i}_video", '' ),
		'title'    => get_theme_mod( "sc_hero_slide{$i}_title", $cd['title'] ),
		'subtitle' => get_theme_mod( "sc_hero_slide{$i}_subtitle", $cd['subtitle'] ),
		'btn_text' => get_theme_mod( "sc_hero_slide{$i}_button_text", $cd['btn'] ),
		'btn_url'  => get_theme_mod( "sc_hero_slide{$i}_button_url", $cd['url'] ),
	);
}
$active_slides = array_values( array_filter( $slides, function( $s ) { return ! empty( $s['title'] ); } ) );
?>

<?php if ( ! empty( $active_slides ) ) : ?>
<section class="sc-hero-slider" data-sc-hero-slider>
	<div class="sc-hero-track">
		<?php foreach ( $active_slides as $i => $slide ) :
			$has_img   = ! empty( $slide['image'] );
			$has_video = ! empty( $slide['video'] );
			$style     = ( $has_img && ! $has_video ) ? 'background-image:url(' . esc_url( $slide['image'] ) . ');' : '';
			$grad      = ( ! $has_img && ! $has_video ) ? 'sc-hero-grad-' . ( ( $i % 3 ) + 1 ) : '';
		?>
		<div class="sc-hero-slide<?php echo $i === 0 ? ' is-active' : ''; ?><?php echo $grad ? ' ' . esc_attr( $grad ) : ''; ?>" style="<?php echo esc_attr( $style ); ?>" data-index="<?php echo esc_attr( $i ); ?>">
			<?php if ( $has_img && ! $has_video ) : ?>
				<img class="sc-hero-img" src="<?php echo esc_url( $slide['image'] ); ?>" alt="<?php echo esc_attr( $slide['title'] ); ?>" <?php echo 0 === $i ? 'fetchpriority="high"' : 'loading="eager"'; ?> />
			<?php endif; ?>
			<?php if ( $has_video ) : ?>
				<video class="sc-hero-video" autoplay muted loop playsinline>
					<source src="<?php echo esc_url( $slide['video'] ); ?>" type="video/mp4">
				</video>
			<?php endif; ?>
			<div class="sc-hero-content">
				<!--span class="sc-eyebrow"><?php esc_html_e( 'New Formulation', 'skincare-clean' ); ?></span-->
				<h1><?php echo esc_html( $slide['title'] ); ?></h1>
				<?php if ( $slide['subtitle'] ) : ?><p><?php echo esc_html( $slide['subtitle'] ); ?></p><?php endif; ?>
				<?php if ( $slide['btn_text'] ) : ?><a class="sc-btn" href="<?php echo esc_url( $slide['btn_url'] ); ?>"><?php echo esc_html( $slide['btn_text'] ); ?></a><?php endif; ?>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
	<?php if ( count( $active_slides ) > 1 ) : ?>
		<button class="sc-hero-arrow prev" data-sc-hero-prev aria-label="<?php esc_attr_e( 'Previous slide', 'skincare-clean' ); ?>">&#8249;</button>
		<button class="sc-hero-arrow next" data-sc-hero-next aria-label="<?php esc_attr_e( 'Next slide', 'skincare-clean' ); ?>">&#8250;</button>
		<div class="sc-hero-dots" data-sc-hero-dots>
			<?php foreach ( $active_slides as $i => $slide ) : ?>
				<button class="<?php echo $i === 0 ? 'is-active' : ''; ?>" data-slide="<?php echo esc_attr( $i ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'skincare-clean' ), $i + 1 ) ); ?>"></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>
<?php endif; ?>

<section class="sc-section alt" id="bestsellers">
	<div class="container">
		<?php sc_render_bestsellers( 8, __( 'Bestsellers', 'skincare-clean' ), '#' ); ?>
	</div>
</section>

<section class="sc-section sc-formula-section">
	<div class="container">
		<div class="sc-formula" data-sc-formula>
			<div class="sc-formula-copy">
				<span class="sc-eyebrow"><?php esc_html_e( 'The Science Behind KLAR & GLO', 'skincare-clean' ); ?></span>
				<h2><?php esc_html_e( 'Know Your Ingredients.', 'skincare-clean' ); ?></h2>
				<p><?php esc_html_e( 'Every ingredient in KLAR & GLO is selected based on efficacy, stability, and compatibility with Indian skin types.', 'skincare-clean' ); ?></p>
				<?php $sc_shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : '#'; ?>
				<a class="sc-btn" href="<?php echo esc_url( $sc_shop_url ); ?>"><?php esc_html_e( 'Explore Ingredients', 'skincare-clean' ); ?></a>
			</div>

			<?php
			$key_ingredients = array(
				array( 'key' => 'niacinamide', 'name' => 'Niacinamide', 'desc' => 'A Vitamin B3 derivative known for brightening tone, refining the look of pores, and strengthening the skin barrier.' ),
				array( 'key' => 'centella-asiatica', 'name' => 'Centella Asiatica', 'desc' => 'A calming Korean botanical extract widely used to soothe irritation and support barrier repair.' ),
				array( 'key' => 'ginseng-exosome', 'name' => 'Ginseng Exosome', 'desc' => "A Korean-sourced active that supports the skin's natural renewal process and helps calm inflammation." ),
				array( 'key' => 'hyaluronic-acid', 'name' => 'Hyaluronic Acid', 'desc' => 'A powerful humectant that draws in and holds moisture for lasting hydration.' ),
				array( 'key' => 'ceramides', 'name' => 'Ceramides', 'desc' => 'Lipids that reinforce the skin barrier and help prevent moisture loss.' ),
				array( 'key' => 'retinol', 'name' => 'Retinol', 'desc' => 'A well-studied Vitamin A derivative known for improving the appearance of fine lines and uneven texture.' ),
			);
			?>

			<div class="sc-formula-visual">
				<?php foreach ( $key_ingredients as $i => $ing ) :
					$img_rel  = '/assets/img/ingredients/' . $ing['key'] . '.jpeg';
					$img_path = get_template_directory() . $img_rel;
					// The bundled PNGs are ~2 KB placeholder gradients. Show a large icon + name on top of them
					// until a real photo (anything over ~20 KB) replaces the file.
					$is_placeholder = ! file_exists( $img_path ) || filesize( $img_path ) < 20000;
					?>
					<div class="sc-formula-slide<?php echo 0 === $i ? ' is-active' : ''; ?>" data-ing="<?php echo esc_attr( $ing['key'] ); ?>">
						<img src="<?php echo esc_url( get_template_directory_uri() . $img_rel ); ?>" alt="<?php echo esc_attr( $ing['name'] ); ?>" loading="lazy" />
						<?php if ( $is_placeholder ) : ?>
							<div class="sc-formula-placeholder">
								<?php //echo sc_ingredient_icon( $ing['key'] ); ?>
								<span><?php //echo esc_html( $ing['name'] ); ?></span>
							</div>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<ul class="sc-formula-list">
				<?php foreach ( $key_ingredients as $i => $ing ) : ?>
					<li>
						<button type="button" class="sc-formula-item<?php echo 0 === $i ? ' is-active' : ''; ?>" data-ing="<?php echo esc_attr( $ing['key'] ); ?>" aria-pressed="<?php echo 0 === $i ? 'true' : 'false'; ?>">
							<span class="sc-formula-radio" aria-hidden="true"></span>
							<span class="sc-formula-text">
								<span class="sc-formula-name"><?php echo esc_html( $ing['name'] ); ?></span>
								<span class="sc-formula-desc"><?php echo esc_html( $ing['desc'] ); ?></span>
							</span>
						</button>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>

<section class="sc-section alt" id="skin-concerns">
	<div class="container">
		<div class="sc-section-head" style="text-align:left; max-width:100%; margin-bottom:24px;">
			<!--span class="sc-eyebrow"><?php esc_html_e( 'Not Sure Where to Begin?', 'skincare-clean' ); ?></span-->
			<h2><?php esc_html_e( 'Shop by Concerns', 'skincare-clean' ); ?></h2>
		</div>
		<?php
		$concerns = array(
			'aging'       => __( 'Aging', 'skincare-clean' ),
			'congestion'    => __( 'Congestion', 'skincare-clean' ),
			'dryness'          => __( 'Dryness', 'skincare-clean' ),
			//'eye_care' => __( 'Eye Care', 'eye_care' ),
			'redness'       => __( 'Redness', 'redness' ),
			'texture'    => __( 'Texture', 'texture' ),
		);
		?>
		<div class="sc-concern-scroll-wrap" data-sc-concern-scroll>
			<div class="sc-concern-grid-big">
				<?php foreach ( $concerns as $key => $label ) : ?>
					<div class="sc-concern-photo">
						<div class="sc-concern-photo-visual" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/concerns/' . $key . '.jpeg' ); ?>');"></div>
						<span><?php echo esc_html( $label ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
			<button class="sc-concern-scroll-arrow prev" data-sc-concern-prev aria-label="<?php esc_attr_e( 'Previous', 'skincare-clean' ); ?>">&#8249;</button>
			<button class="sc-concern-scroll-arrow next" data-sc-concern-next aria-label="<?php esc_attr_e( 'Next', 'skincare-clean' ); ?>">&#8250;</button>
		</div>
	</div>
</section>

<section class="sc-section">
	<div class="container">
		<div class="sc-section-head">
			<!--span class="sc-eyebrow"><?php esc_html_e( 'Skincare, Simplified', 'skincare-clean' ); ?></span-->
			<h2><?php esc_html_e( 'Build Your Regimen.', 'skincare-clean' ); ?></h2>
		</div>
		<?php
		$routines = array(
			'morning' => array(
				'label' => __( 'Morning Routine', 'skincare-clean' ),
				'steps' => array(
					array( 'step' => __( 'Cleanse', 'skincare-clean' ), 'slug' => 'klar-glo-hydrating-cleanser' ),
					array( 'step' => __( 'Tone', 'skincare-clean' ), 'slug' => 'klar-glo-skin-tonic' ),
					array( 'step' => __( 'Treat', 'skincare-clean' ), 'slug' => 'klar-glo-glow-serum' ),
					array( 'step' => __( 'Moisturize', 'skincare-clean' ), 'slug' => 'klar-glo-hydra-gel-cream' ),
					array( 'step' => __( 'Protect', 'skincare-clean' ), 'slug' => 'klar-glo-sunscreen' ),
				),
			),
			'evening' => array(
				'label' => __( 'Evening Routine', 'skincare-clean' ),
				'steps' => array(
					array( 'step' => __( 'Cleanse', 'skincare-clean' ), 'slug' => 'klar-glo-hydrating-cleanser' ),
					array( 'step' => __( 'Tone', 'skincare-clean' ), 'slug' => 'klar-glo-skin-tonic' ),
					array( 'step' => __( 'Treat', 'skincare-clean' ), 'slug' => 'klar-glo-glow-serum' ),
					array( 'step' => __( 'Repair', 'skincare-clean' ), 'slug' => 'klar-glo-night-cream' ),
				),
			),
		);
		foreach ( $routines as $key => $routine ) {
			echo '<div class="sc-routine-block">';
			echo '<h3 class="sc-routine-subhead">' . esc_html( $routine['label'] ) . '</h3>';
			echo '<div class="sc-routine-row">';
			foreach ( $routine['steps'] as $i => $s ) {
				$product = get_page_by_path( $s['slug'], OBJECT, 'product' );
				$title   = $product ? get_the_title( $product->ID ) : ucwords( str_replace( array( 'klar-glo-', '-' ), array( '', ' ' ), $s['slug'] ) );
				$link    = $product ? get_permalink( $product->ID ) : '#';
				$thumb   = $product ? sc_product_thumb_markup( $product->ID, $title ) : '';
				echo '<div class="sc-routine-step">';
			//	echo '<span class="sc-routine-num">' . esc_html( $i + 1 ) . '</span>';
				echo '<a href="' . esc_url( $link ) . '" class="sc-routine-thumb">' . $thumb . '</a>';
				echo '<span class="sc-routine-step-label">' . esc_html( $s['step'] ) . '</span>';
				echo '<a href="' . esc_url( $link ) . '" class="sc-routine-title">' . '' . '</a>';
				echo '</div>';
				if ( $i < count( $routine['steps'] ) - 1 ) {
					echo '<span class="sc-routine-arrow">&#8250;</span>';
				}
			}
			echo '</div>';
			echo '</div>';
		}
		?>
	</div>
</section>

<?php get_footer(); ?>