(function () {
	'use strict';
	var cfg = window.scAuth || {};
	function $(s, r) { return (r || document).querySelector(s); }
	function post(data) {
		var body = new URLSearchParams();
		Object.keys(data).forEach(function (k) { body.append(k, data[k]); });
		return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (r) { return r.json(); });
	}

	/* ---------------- Search bar ---------------- */
	var panel = $('[data-sc-search-panel]');
	var openBtn = $('[data-sc-search-open]');
	if (panel && openBtn) {
		var input = $('[data-sc-search-input]', panel);
		var results = $('[data-sc-search-results]', panel);
		var timer = null, lastQ = '';

		function openSearch() {
			panel.hidden = false;
			requestAnimationFrame(function () { panel.classList.add('is-open'); });
			openBtn.setAttribute('aria-expanded', 'true');
			setTimeout(function () { input.focus(); }, 60);
		}
		function closeSearch() {
			panel.classList.remove('is-open');
			openBtn.setAttribute('aria-expanded', 'false');
			setTimeout(function () { if (!panel.classList.contains('is-open')) panel.hidden = true; }, 200);
		}
		openBtn.addEventListener('click', function () { if (panel.hidden) { openSearch(); } else { closeSearch(); } });
		$('[data-sc-search-close]', panel).addEventListener('click', closeSearch);
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) closeSearch(); });
		document.addEventListener('click', function (e) {
			if (!panel.hidden && !panel.contains(e.target) && !openBtn.contains(e.target)) closeSearch();
		});

		function esc(t) { var d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
		function render(items, q) {
			if (!items.length) { results.innerHTML = '<p class="sc-search-empty">No results for \u201c' + esc(q) + '\u201d. Press Enter to search the whole site.</p>'; return; }
			results.innerHTML = items.map(function (i) {
				return '<a class="sc-search-item" href="' + esc(i.url) + '">' +
					(i.img ? '<img src="' + esc(i.img) + '" alt="" loading="lazy">' : '<span class="sc-search-noimg"></span>') +
					'<span class="sc-search-txt"><strong>' + esc(i.title) + '</strong><em>' + esc(i.type) + (i.price ? ' \u00b7 ' + esc(i.price) : '') + '</em></span></a>';
			}).join('') + '<a class="sc-search-all" href="' + esc(panel.querySelector('form').action + '?s=' + encodeURIComponent(q)) + '">See all results</a>';
		}
		input.addEventListener('input', function () {
			var q = input.value.trim();
			clearTimeout(timer);
			if (q.length < 2) { results.innerHTML = ''; lastQ = ''; return; }
			timer = setTimeout(function () {
				if (q === lastQ) return;
				lastQ = q;
				fetch(cfg.ajaxUrl + '?action=sc_live_search&q=' + encodeURIComponent(q), { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (d) { if (input.value.trim() === q) render((d && d.data && d.data.items) || [], q); })
					.catch(function () {});
			}, 250);
		});
	}

	/* ---------------- Mobile OTP login ---------------- */
	var box = $('[data-sc-login]');
	if (!box) return;
	var stepPhone = $('[data-sc-step="phone"]', box), stepOtp = $('[data-sc-step="otp"]', box);
	var phoneIn = $('[data-sc-login-phone]', box), otpIn = $('[data-sc-login-otp]', box);
	var msg1 = $('[data-sc-login-msg]', box), msg2 = $('[data-sc-login-msg2]', box);
	var sendBtn = $('[data-sc-login-send]', box), verifyBtn = $('[data-sc-login-verify]', box);
	var resendBtn = $('[data-sc-login-resend]', box), timerEl = $('[data-sc-login-timer]', box);
	var sentTo = $('[data-sc-login-sentto]', box);
	var isEmail = (box.getAttribute('data-sc-method') || cfg.method) === 'email';
	var phone = '', cd = null;

	function openLogin(e) {
		if (e) e.preventDefault();
		box.hidden = false; document.body.classList.add('sc-login-open');
		showStep('phone');
		setTimeout(function () { phoneIn.focus(); }, 60);
	}
	function closeLogin() { box.hidden = true; document.body.classList.remove('sc-login-open'); clearInterval(cd); }
	function showStep(s) {
		stepPhone.hidden = s !== 'phone'; stepOtp.hidden = s !== 'otp';
		msg1.textContent = ''; msg2.textContent = '';
	}
	function startTimer() {
		var left = 30; resendBtn.disabled = true; timerEl.textContent = 'in ' + left + 's';
		clearInterval(cd);
		cd = setInterval(function () {
			left--;
			if (left <= 0) { clearInterval(cd); resendBtn.disabled = false; timerEl.textContent = ''; }
			else timerEl.textContent = 'in ' + left + 's';
		}, 1000);
	}
	function sendOtp(isResend) {
		var p, payload;
		if (isEmail) {
			p = phoneIn.value.trim().toLowerCase();
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(p)) { msg1.textContent = 'Please enter a valid email address.'; return; }
			payload = { action: 'sc_otp_send', email: p };
		} else {
			p = phoneIn.value.replace(/\D/g, '');
			if (!/^[6-9][0-9]{9}$/.test(p)) { msg1.textContent = 'Please enter a valid 10-digit mobile number.'; return; }
			payload = { action: 'sc_otp_send', phone: p };
		}
		phone = p; sendBtn.disabled = true; resendBtn.disabled = true;
		(isResend ? msg2 : msg1).textContent = 'Sending OTP\u2026';
		post(payload).then(function (d) {
			if (d && d.success) {
				sentTo.textContent = (isEmail ? 'OTP sent to ' : 'OTP sent to +91 ') + phone;
				showStep('otp'); otpIn.value = ''; otpIn.focus(); startTimer();
			} else {
				(isResend ? msg2 : msg1).textContent = (d && d.data && d.data.message) || 'Something went wrong. Please try again.';
				if (isResend) resendBtn.disabled = false;
			}
		}).catch(function () { (isResend ? msg2 : msg1).textContent = 'Network error. Please try again.'; })
		.then(function () { sendBtn.disabled = false; });
	}
	function verify() {
		var o = otpIn.value.replace(/\D/g, '');
		if (o.length !== 6) { msg2.textContent = 'Please enter the 6-digit OTP.'; return; }
		verifyBtn.disabled = true; msg2.textContent = 'Verifying\u2026';
		post(Object.assign({ action: 'sc_otp_verify', otp: o, redirect: location.href }, isEmail ? { email: phone } : { phone: phone })).then(function (d) {
			if (d && d.success) {
				msg2.textContent = 'Logged in!';
				location.href = (d.data && d.data.redirect) || location.href;
			} else {
				msg2.textContent = (d && d.data && d.data.message) || 'Could not verify. Please try again.';
				if (d && d.data && d.data.expired) { resendBtn.disabled = false; }
				verifyBtn.disabled = false;
			}
		}).catch(function () { msg2.textContent = 'Network error. Please try again.'; verifyBtn.disabled = false; });
	}

	document.querySelectorAll('[data-sc-login-open]').forEach(function (a) { a.addEventListener('click', openLogin); });
	box.querySelectorAll('[data-sc-login-close]').forEach(function (b) { b.addEventListener('click', closeLogin); });
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !box.hidden) closeLogin(); });
	sendBtn.addEventListener('click', function () { sendOtp(false); });
	resendBtn.addEventListener('click', function () { sendOtp(true); });
	verifyBtn.addEventListener('click', verify);
	$('[data-sc-login-change]', box).addEventListener('click', function () { clearInterval(cd); showStep('phone'); phoneIn.focus(); });
	if (!isEmail) phoneIn.addEventListener('input', function () { phoneIn.value = phoneIn.value.replace(/\D/g, '').slice(0, 10); });
	phoneIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); sendOtp(false); } });
	otpIn.addEventListener('input', function () { otpIn.value = otpIn.value.replace(/\D/g, '').slice(0, 6); if (otpIn.value.length === 6) verify(); });
	otpIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); verify(); } });

	// My Account page for logged-out visitors: show the OTP login straight away
	if (cfg.isAccount && !cfg.loggedIn) openLogin();
})();
