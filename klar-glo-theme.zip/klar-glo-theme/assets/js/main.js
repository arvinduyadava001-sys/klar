(function () {
	'use strict';

	// Mobile menu toggle
	var toggle = document.querySelector('[data-sc-menu-toggle]');
	var nav = document.querySelector('[data-sc-nav]');
	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			nav.classList.toggle('is-open');
		});
	}

	// Announcement bar rotation (5s, pauses while hovered / focused so codes can be read and copied)
	var announceTrack = document.querySelector('[data-sc-announce]');
	if (announceTrack) {
		var spans = Array.prototype.filter.call(announceTrack.children, function (el) { return el.tagName === 'SPAN'; });
		if (spans.length > 1) {
			var idx = 0, paused = false;
			['mouseenter', 'focusin', 'touchstart'].forEach(function (ev) { announceTrack.addEventListener(ev, function () { paused = true; }, { passive: true }); });
			['mouseleave', 'focusout'].forEach(function (ev) { announceTrack.addEventListener(ev, function () { paused = false; }); });
			setInterval(function () {
				if (paused) return;
				spans[idx].classList.remove('is-active');
				idx = (idx + 1) % spans.length;
				spans[idx].classList.add('is-active');
			}, 5000);
		}
	}

	// Tap a coupon code in the announcement bar to copy it
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('[data-sc-copy]') : null;
		if (!btn) return;
		var code = btn.getAttribute('data-sc-copy'), label = btn.getAttribute('data-sc-label') || btn.textContent;
		btn.setAttribute('data-sc-label', label);
		function done() { btn.textContent = 'Copied!'; setTimeout(function () { btn.textContent = label; }, 1500); }
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(code).then(done, done);
		} else {
			var t = document.createElement('textarea'); t.value = code; t.style.position = 'fixed'; t.style.opacity = '0';
			document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (x) {} document.body.removeChild(t); done();
		}
	});

	// ---------------------------------------------------------------
	// Infinite forward loop helper for the Bestsellers + Shop by Concerns rows.
	// The original items are wrapped with a clone set on each side, so the row
	// always keeps moving in the SAME direction and never rewinds to the start.
	// After a move settles we silently jump one set-width, which looks identical.
	// ---------------------------------------------------------------
	function scLoopScroller(track, itemSel, prevBtn, nextBtn, autoplayMs) {
		var originals = Array.prototype.slice.call(track.querySelectorAll(itemSel));
		var n = originals.length;
		if (n < 2) return;

		function makeClones() {
			return originals.map(function (el) {
				var c = el.cloneNode(true);
				c.setAttribute('aria-hidden', 'true');
				c.removeAttribute('id');
				c.querySelectorAll('a, button').forEach(function (a) { a.setAttribute('tabindex', '-1'); });
				return c;
			});
		}
		var before = makeClones(), after = makeClones();
		before.forEach(function (c) { track.insertBefore(c, originals[0]); });
		after.forEach(function (c) { track.appendChild(c); });

		var all = Array.prototype.slice.call(track.querySelectorAll(itemSel));
		var setW = 0, idleTimer = null, autoTimer = null;

		function measure() { setW = all[n].offsetLeft - all[0].offsetLeft; }
		function stepWidth() { return all[1].offsetLeft - all[0].offsetLeft; }
		function instant(left) {
			var prevB = track.style.scrollBehavior, prevS = track.style.scrollSnapType;
			track.style.scrollBehavior = 'auto';
			track.style.scrollSnapType = 'none';
			track.scrollLeft = left;
			void track.offsetWidth;
			track.style.scrollBehavior = prevB;
			track.style.scrollSnapType = prevS;
		}
		function recenter() {
			if (!setW) return;
			var sl = track.scrollLeft;
			if (sl < setW - 2) instant(sl + setW);
			else if (sl >= 2 * setW - 2) instant(sl - setW);
		}
		function onScroll() {
			clearTimeout(idleTimer);
			idleTimer = setTimeout(recenter, 140);
		}
		function next() { track.scrollBy({ left: stepWidth(), behavior: 'smooth' }); }
		function prev() { track.scrollBy({ left: -stepWidth(), behavior: 'smooth' }); }
		function stop() { if (autoTimer) { clearInterval(autoTimer); autoTimer = null; } }
		function start() {
			stop();
			if (autoplayMs) autoTimer = setInterval(next, autoplayMs);
		}

		measure();
		instant(setW);
		track.addEventListener('scroll', onScroll, { passive: true });
		window.addEventListener('resize', function () {
			var ratio = setW ? (track.scrollLeft % setW) / setW : 0;
			measure();
			instant(setW + ratio * setW);
		});

		if (nextBtn) { nextBtn.disabled = false; nextBtn.addEventListener('click', function () { next(); start(); }); }
		if (prevBtn) { prevBtn.disabled = false; prevBtn.addEventListener('click', function () { prev(); start(); }); }

		var wrap = track.parentNode;
		if (autoplayMs) {
			wrap.addEventListener('mouseenter', stop);
			wrap.addEventListener('mouseleave', start);
			wrap.addEventListener('touchstart', stop, { passive: true });
			wrap.addEventListener('touchend', start, { passive: true });
			document.addEventListener('visibilitychange', function () { if (document.hidden) { stop(); } else { start(); } });
			start();
		}
	}

	// Hero slider — infinite forward loop. Clones of the last and first slide sit at
	// either end of the track; when the slide reaches a clone we jump (without any
	// animation) to the identical real slide, so it keeps gliding the same way
	// forever instead of sweeping back through every slide to the first one.
	var slider = document.querySelector('[data-sc-hero-slider]');
	if (slider) {
		var heroTrack = slider.querySelector('.sc-hero-track');
		var slides = slider.querySelectorAll('.sc-hero-slide');
		var dots = slider.querySelectorAll('[data-sc-hero-dots] button');
		var heroPrev = slider.querySelector('[data-sc-hero-prev]');
		var heroNext = slider.querySelector('[data-sc-hero-next]');
		var total = slides.length;
		var pos = 0;          // index inside the track (1..total are the real slides when looping)
		var animating = false;
		var animTimer = null;
		var timer = null;
		var looping = total > 1;

		if (looping) {
			var firstClone = slides[0].cloneNode(true);
			var lastClone = slides[total - 1].cloneNode(true);
			[firstClone, lastClone].forEach(function (c) {
				c.classList.remove('is-active');
				c.setAttribute('aria-hidden', 'true');
				c.querySelectorAll('a, button').forEach(function (a) { a.setAttribute('tabindex', '-1'); });
			});
			heroTrack.insertBefore(lastClone, slides[0]);
			heroTrack.appendChild(firstClone);
			pos = 1;
		}

		function realIndex() {
			if (!looping) return 0;
			return (pos - 1 + total) % total;
		}
		function render(animate) {
			if (!animate) heroTrack.classList.add('is-dragging');
			heroTrack.style.transform = 'translate3d(' + (-pos * 100) + '%,0,0)';
			if (!animate) {
				void heroTrack.offsetWidth;
				heroTrack.classList.remove('is-dragging');
			}
			var ri = realIndex();
			slides.forEach(function (s, i) {
				s.classList.toggle('is-active', i === ri);
				s.setAttribute('aria-hidden', i === ri ? 'false' : 'true');
			});
			dots.forEach(function (d, i) { d.classList.toggle('is-active', i === ri); });
		}
		function settle() {
			clearTimeout(animTimer);
			animating = false;
			if (!looping) return;
			if (pos === total + 1) { pos = 1; render(false); }
			else if (pos === 0) { pos = total; render(false); }
		}
		function moveTo(newPos) {
			if (!looping || animating) return;
			animating = true;
			pos = newPos;
			render(true);
			clearTimeout(animTimer);
			animTimer = setTimeout(settle, 800); // fallback if transitionend never fires
		}
		heroTrack.addEventListener('transitionend', function (e) {
			if (e.target === heroTrack && e.propertyName === 'transform') settle();
		});

		function stopAutoplay() {
			if (timer) { clearInterval(timer); timer = null; }
		}
		function startAutoplay() {
			return; // autoplay disabled: hero banner moves only on arrows / dots / swipe
			if (total < 2) return;
			stopAutoplay();
			timer = setInterval(function () { moveTo(pos + 1); }, 6000);
		}

		if (heroPrev) heroPrev.addEventListener('click', function () { moveTo(pos - 1); startAutoplay(); });
		if (heroNext) heroNext.addEventListener('click', function () { moveTo(pos + 1); startAutoplay(); });
		dots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				moveTo((parseInt(dot.getAttribute('data-slide'), 10) || 0) + 1);
				startAutoplay();
			});
		});

		// Pause on hover only on devices that really hover (not on phones)
		if (window.matchMedia && window.matchMedia('(hover: hover)').matches) {
			slider.addEventListener('mouseenter', stopAutoplay);
			slider.addEventListener('mouseleave', startAutoplay);
		}
		// Don't keep rotating in a background tab
		document.addEventListener('visibilitychange', function () {
			if (document.hidden) { stopAutoplay(); } else { settle(); startAutoplay(); }
		});

		// Touch swipe: the track follows the finger, then glides on to the next/previous slide
		var sx = null, sy = null, dx = 0, axis = null;
		slider.addEventListener('touchstart', function (e) {
			if (e.touches.length !== 1 || animating) return;
			sx = e.touches[0].clientX; sy = e.touches[0].clientY; dx = 0; axis = null;
			stopAutoplay();
		}, { passive: true });
		slider.addEventListener('touchmove', function (e) {
			if (sx === null) return;
			var mx = e.touches[0].clientX - sx;
			var my = e.touches[0].clientY - sy;
			if (axis === null && (Math.abs(mx) > 8 || Math.abs(my) > 8)) {
				axis = Math.abs(mx) > Math.abs(my) ? 'x' : 'y';
				if (axis === 'x') heroTrack.classList.add('is-dragging');
			}
			if (axis === 'x') {
				dx = mx;
				heroTrack.style.transform = 'translate3d(' + (-pos * slider.offsetWidth + dx) + 'px,0,0)';
			}
		}, { passive: true });
		function endTouch() {
			if (sx === null) return;
			heroTrack.classList.remove('is-dragging');
			var swipe = axis === 'x' && Math.abs(dx) > Math.min(70, slider.offsetWidth * 0.18);
			var target = swipe ? pos + (dx < 0 ? 1 : -1) : pos;
			sx = sy = null; axis = null; dx = 0;
			if (target === pos) { render(true); } else { moveTo(target); }
			startAutoplay();
		}
		slider.addEventListener('touchend', endTouch, { passive: true });
		slider.addEventListener('touchcancel', endTouch, { passive: true });

		render(false);
		startAutoplay();
	}

	// Shop by Concerns slider
	var concernSlider = document.querySelector('[data-sc-concern-slider]');
	if (concernSlider) {
		var cSlides = concernSlider.querySelectorAll('.sc-concern-slide');
		var cDots = document.querySelectorAll('[data-sc-concern-progress] span');
		var cPrev = document.querySelector('[data-sc-concern-prev]');
		var cNext = document.querySelector('[data-sc-concern-next]');
		var cCurrent = 0;

		function cGoTo(index) {
			if (!cSlides.length) return;
			cCurrent = (index + cSlides.length) % cSlides.length;
			cSlides.forEach(function (s, i) { s.classList.toggle('is-active', i === cCurrent); });
			cDots.forEach(function (d, i) { d.classList.toggle('is-active', i === cCurrent); });
		}
		if (cPrev) cPrev.addEventListener('click', function () { cGoTo(cCurrent - 1); });
		if (cNext) cNext.addEventListener('click', function () { cGoTo(cCurrent + 1); });
		cDots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				cGoTo(parseInt(dot.getAttribute('data-slide'), 10) || 0);
			});
		});
	}

	// Shop by Concerns — endless horizontal loop (arrows + autoplay, always moves forward)
	var concernScroll = document.querySelector('[data-sc-concern-scroll]');
	if (concernScroll) {
		scLoopScroller(
			concernScroll.querySelector('.sc-concern-grid-big'),
			'.sc-concern-photo',
			concernScroll.querySelector('[data-sc-concern-prev]'),
			concernScroll.querySelector('[data-sc-concern-next]'),
			3500
		);
	}

	// Morning / Evening routine icons next to product names
	var SC_SUN_ICON = '<svg class="sc-routine-icon sc-routine-icon-sun" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4.8"></circle><line x1="12.00" y1="4.40" x2="12.00" y2="2.00"></line><line x1="17.37" y1="6.63" x2="19.07" y2="4.93"></line><line x1="19.60" y1="12.00" x2="22.00" y2="12.00"></line><line x1="17.37" y1="17.37" x2="19.07" y2="19.07"></line><line x1="12.00" y1="19.60" x2="12.00" y2="22.00"></line><line x1="6.63" y1="17.37" x2="4.93" y2="19.07"></line><line x1="4.40" y1="12.00" x2="2.00" y2="12.00"></line><line x1="6.63" y1="6.63" x2="4.93" y2="4.93"></line></svg>';
	var SC_MOON_ICON = '<svg class="sc-routine-icon sc-routine-icon-moon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.8 2.6A9.7 9.7 0 1 0 21 16.2A8.6 8.6 0 0 1 9.8 2.6z"></path></svg>';

	function scRoutineIconsFor(name) {
		var n = (name || '').toLowerCase();
		if (n.indexOf('night') !== -1) {
			return '<span class="sc-routine-icons" title="Evening">' + SC_MOON_ICON + '</span>';
		}
		if (n.indexOf('sunscreen') !== -1 || n.indexOf('sun screen') !== -1 || n.indexOf('spf') !== -1) {
			return '<span class="sc-routine-icons" title="Morning">' + SC_SUN_ICON + '</span>';
		}
		if (
			n.indexOf('cleanser') !== -1 ||
			n.indexOf('mist') !== -1 ||
			n.indexOf('serum') !== -1 ||
			n.indexOf('moisturizer') !== -1 ||
			n.indexOf('moisturiser') !== -1 ||
			n.indexOf('day cream') !== -1 ||
			n.indexOf('tonic') !== -1 ||
			n.indexOf('gel cream') !== -1 ||
			n.indexOf('hydra gel cream') !== -1
		) {
			return '<span class="sc-routine-icons" title="Morning & Evening">' + SC_SUN_ICON + SC_MOON_ICON + '</span>';
		}
		return '';
	}

	var scTitleSelectors = [
		'.sc-product-title',
		'.woocommerce-loop-product__title',
		'.woocommerce ul.products li.product h2',
		'h1.product_title',
		'.product_title'
	];
	document.querySelectorAll(scTitleSelectors.join(',')).forEach(function (el) {
		if (el.querySelector('.sc-routine-icons')) return; // already processed
		if (el.closest('.sc-carousel')) return; // Bestsellers row: no routine icons here
		var icons = scRoutineIconsFor(el.textContent);
		if (icons) el.insertAdjacentHTML('beforeend', ' ' + icons);
	});

	// Bestsellers carousel — endless loop (arrows + autoplay, always moves forward)
	document.querySelectorAll('[data-sc-carousel]').forEach(function (carousel) {
		var track = carousel.querySelector('[data-sc-carousel-track]');
		if (!track) return;
		scLoopScroller(
			track,
			'.sc-product-card',
			carousel.querySelector('[data-sc-carousel-prev]'),
			carousel.querySelector('[data-sc-carousel-next]'),
			0 // 0 = no autoplay: moves only when the arrow buttons are clicked (or the row is swiped)
		);
	});

	// Single product: clicking the rating/reviews link opens the Reviews tab and scrolls to it
	document.querySelectorAll('.sc-rating-count').forEach(function (a) {
		a.addEventListener('click', function (e) {
			var tabLink = document.querySelector('.woocommerce-tabs .reviews_tab a');
			var target = document.querySelector('#reviews') || document.querySelector('.woocommerce-tabs');
			if (!tabLink && !target) return;
			e.preventDefault();
			if (tabLink) tabLink.click();
			setTimeout(function () {
				var t = document.querySelector('.sc-review-summary') || document.querySelector('#reviews') || document.querySelector('.woocommerce-tabs');
				if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}, 80);
		});
	});

	// Single product: pincode / delivery check
	document.querySelectorAll('[data-sc-pin-check]').forEach(function (box) {
		var input = box.querySelector('[data-sc-pin-input]');
		var btn = box.querySelector('[data-sc-pin-btn]');
		var msg = box.querySelector('[data-sc-pin-msg]');
		if (!input || !btn || !msg) return;
		var KEY = 'sc_pincode';

		function show(text, ok) {
			msg.textContent = text;
			msg.className = 'sc-pin-msg ' + (ok === true ? 'is-ok' : ok === false ? 'is-error' : '');
		}
		function check() {
			var pin = (input.value || '').replace(/\D/g, '');
			input.value = pin;
			if (!/^[1-9][0-9]{5}$/.test(pin)) { show('Please enter a valid 6-digit pincode.', false); return; }
			if (!window.scTheme || !window.fetch) { show('Delivery is available across India (4-7 business days).', true); return; }
			btn.disabled = true; show('Checking\u2026', null);
			var body = new URLSearchParams();
			body.append('action', 'sc_check_pincode');
			body.append('pincode', pin);
			fetch(window.scTheme.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (d && d.ok) {
						show((d.place ? d.place + ' \u2014 ' : '') + d.message, true);
						try { localStorage.setItem(KEY, pin); } catch (e) {}
					} else {
						show((d && d.message) || 'Could not check this pincode. Please try again.', false);
					}
				})
				.catch(function () { show('Could not check right now. Please try again.', false); })
				.then(function () { btn.disabled = false; });
		}
		btn.addEventListener('click', check);
		input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); check(); } });
		input.addEventListener('input', function () { input.value = input.value.replace(/\D/g, '').slice(0, 6); });
		try {
			var saved = localStorage.getItem(KEY);
			if (saved && /^[1-9][0-9]{5}$/.test(saved)) { input.value = saved; check(); }
		} catch (e) {}
	});

	// Single product: quantity stepper (- / number / +)
	document.querySelectorAll('.sc-qty-row .quantity').forEach(function (qtyWrap) {
		var input = qtyWrap.querySelector('input.qty');
		if (!input || qtyWrap.querySelector('.sc-qty-btn')) return;

		var minus = document.createElement('button');
		minus.type = 'button';
		minus.className = 'sc-qty-btn sc-qty-minus';
		minus.setAttribute('aria-label', 'Decrease quantity');
		minus.textContent = '\u2212';

		var plus = document.createElement('button');
		plus.type = 'button';
		plus.className = 'sc-qty-btn sc-qty-plus';
		plus.setAttribute('aria-label', 'Increase quantity');
		plus.textContent = '+';

		qtyWrap.insertBefore(minus, input);
		qtyWrap.appendChild(plus);
		qtyWrap.classList.add('sc-qty-stepper');

		function step(dir) {
			var min = parseFloat(input.getAttribute('min')) || 1;
			var max = input.getAttribute('max') ? parseFloat(input.getAttribute('max')) : Infinity;
			var stepVal = parseFloat(input.getAttribute('step')) || 1;
			var val = parseFloat(input.value) || min;
			val = dir > 0 ? Math.min(max, val + stepVal) : Math.max(min, val - stepVal);
			input.value = val;
			input.dispatchEvent(new Event('change', { bubbles: true }));
		}
		minus.addEventListener('click', function () { step(-1); });
		plus.addEventListener('click', function () { step(1); });
	});

	// Single product: "Size" pill buttons sync to WooCommerce's hidden native select
	document.querySelectorAll('[data-sc-variation-swatch]').forEach(function (row) {
		var select = row.querySelector('select');
		var pills = row.querySelectorAll('.sc-variation-pill');
		if (!select || !pills.length) return;

		pills.forEach(function (pill) {
			pill.addEventListener('click', function () {
				pills.forEach(function (p) { p.classList.remove('is-active'); });
				pill.classList.add('is-active');
				select.value = pill.getAttribute('data-value');

				// Fire both a native change event and, if jQuery is present
				// (WooCommerce always loads it), a jQuery-triggered change —
				// WooCommerce's own variation script listens via jQuery and
				// this guarantees it picks up the selection reliably.
				select.dispatchEvent(new Event('change', { bubbles: true }));
				if (window.jQuery) {
					window.jQuery(select).val(pill.getAttribute('data-value')).trigger('change');
				}

				var labelStrong = row.querySelector('.sc-variation-selected');
				if (labelStrong) {
					labelStrong.textContent = pill.textContent;
				} else {
					var label = row.querySelector('.sc-variation-label');
					if (label) label.insertAdjacentHTML('beforeend', ' <strong class="sc-variation-selected">' + pill.textContent + '</strong>');
				}
			});
		});
	});

	// Single product: hide the top summary price range once a variation is
	// picked, so only the selected variation's own price shows (no duplicate).
	if (window.jQuery) {
		document.querySelectorAll('form.variations_form').forEach(function (form) {
			var summary = form.parentElement;
			var topPrice = summary ? summary.querySelector(':scope > p.price, :scope > .price') : null;
			if (!topPrice) return;
			window.jQuery(form).on('found_variation', function () {
				topPrice.style.display = 'none';
			});
			window.jQuery(form).on('reset_data hide_variation', function () {
				topPrice.style.display = '';
			});
		});
	}

	// Single product: "Buy It Now" — flag the form so it redirects to checkout
	document.querySelectorAll('[data-sc-buy-now]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var form = btn.closest('form');
			if (!form) return;
			var flag = form.querySelector('[data-sc-buy-now-flag]');
			if (flag) flag.value = '1';
		});
	});
	// Any normal "Add to Cart" click should not carry a stale buy_now flag forward.
	document.querySelectorAll('.single_add_to_cart_button').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var form = btn.closest('form');
			if (!form) return;
			var flag = form.querySelector('[data-sc-buy-now-flag]');
			if (flag) flag.value = '';
		});
	});

	// Front page: "Know Your Ingredients" — swap the image when an ingredient is chosen
	document.querySelectorAll('[data-sc-formula]').forEach(function (wrap) {
		var items = wrap.querySelectorAll('.sc-formula-item');
		var imgs = wrap.querySelectorAll('.sc-formula-slide');
		function activate(key) {
			items.forEach(function (it) {
				var on = it.getAttribute('data-ing') === key;
				it.classList.toggle('is-active', on);
				it.setAttribute('aria-pressed', on ? 'true' : 'false');
			});
			imgs.forEach(function (img) {
				img.classList.toggle('is-active', img.getAttribute('data-ing') === key);
			});
		}
		items.forEach(function (it) {
			var key = it.getAttribute('data-ing');
			it.addEventListener('click', function () { activate(key); });
			it.addEventListener('mouseenter', function () {
				if (window.matchMedia('(hover: hover)').matches) activate(key);
			});
		});
	});
})();
// Product page gallery: thumbnails, arrows, swipe, keyboard and full-screen zoom
(function () {
	var galleries = document.querySelectorAll('[data-sc-gallery]');
	if (!galleries.length) return;

	var lb, lbImg, lbCount, lbGallery = null, lbIndex = 0;
	function buildLightbox() {
		if (lb) return;
		lb = document.createElement('div');
		lb.className = 'sc-lightbox';
		lb.innerHTML = '<button type="button" class="sc-lightbox-close" aria-label="Close">&times;</button>' +
			'<button type="button" class="sc-lightbox-arrow prev" aria-label="Previous">&#8249;</button>' +
			'<img alt="">' +
			'<button type="button" class="sc-lightbox-arrow next" aria-label="Next">&#8250;</button>' +
			'<div class="sc-lightbox-count"></div>';
		document.body.appendChild(lb);
		lbImg = lb.querySelector('img');
		lbCount = lb.querySelector('.sc-lightbox-count');
		lb.querySelector('.sc-lightbox-close').addEventListener('click', closeLb);
		lb.querySelector('.prev').addEventListener('click', function (e) { e.stopPropagation(); stepLb(-1); });
		lb.querySelector('.next').addEventListener('click', function (e) { e.stopPropagation(); stepLb(1); });
		lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); });
		document.addEventListener('keydown', function (e) {
			if (!lb.classList.contains('is-open')) return;
			if (e.key === 'Escape') closeLb();
			if (e.key === 'ArrowLeft') stepLb(-1);
			if (e.key === 'ArrowRight') stepLb(1);
		});
	}
	function showLb() {
		var slides = lbGallery.querySelectorAll('.sc-gallery-slide');
		lbImg.src = slides[lbIndex].getAttribute('data-full');
		lbCount.textContent = slides.length > 1 ? (lbIndex + 1) + ' / ' + slides.length : '';
		lb.classList.toggle('single', slides.length < 2);
	}
	function openLb(g, i) { buildLightbox(); lbGallery = g; lbIndex = i; showLb(); lb.classList.add('is-open'); document.body.classList.add('sc-lb-open'); }
	function closeLb() { lb.classList.remove('is-open'); document.body.classList.remove('sc-lb-open'); }
	function stepLb(d) { var n = lbGallery.querySelectorAll('.sc-gallery-slide').length; lbIndex = (lbIndex + d + n) % n; showLb(); }

	galleries.forEach(function (g) {
		var track = g.querySelector('[data-sc-gallery-track]');
		var slides = g.querySelectorAll('.sc-gallery-slide');
		var thumbs = g.querySelectorAll('.sc-gallery-thumb');
		var thumbBar = g.querySelector('[data-sc-gallery-thumbs]');
		var count = g.querySelector('[data-sc-gallery-count]');
		var n = slides.length, i = 0;

		function go(k) {
			i = (k + n) % n;
			track.style.transform = 'translateX(' + (-100 * i) + '%)';
			thumbs.forEach(function (t, idx) {
				t.classList.toggle('is-active', idx === i);
				if (idx === i && thumbBar) {
					var left = t.offsetLeft - (thumbBar.clientWidth - t.offsetWidth) / 2;
					thumbBar.scrollTo({ left: left, behavior: 'smooth' });
				}
			});
			if (count) count.textContent = (i + 1) + ' / ' + n;
		}
		var prev = g.querySelector('[data-sc-gallery-prev]');
		var next = g.querySelector('[data-sc-gallery-next]');
		if (prev) prev.addEventListener('click', function () { go(i - 1); });
		if (next) next.addEventListener('click', function () { go(i + 1); });
		thumbs.forEach(function (t, idx) { t.addEventListener('click', function () { go(idx); }); });

		// swipe
		var sx = 0, sy = 0, moved = false;
		track.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; moved = false; }, { passive: true });
		track.addEventListener('touchmove', function (e) {
			if (Math.abs(e.touches[0].clientX - sx) > 10) moved = true;
		}, { passive: true });
		track.addEventListener('touchend', function (e) {
			var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
			if (n > 1 && Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) { go(dx < 0 ? i + 1 : i - 1); }
		}, { passive: true });
		g.setAttribute('tabindex', '0');
		g.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') go(i - 1);
			if (e.key === 'ArrowRight') go(i + 1);
		});

		// hover zoom (desktop / mouse only): image zooms in-place and follows the cursor
		if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
			slides.forEach(function (s) {
				var img = s.querySelector('.sc-gallery-img');
				if (!img) return;
				var hiRes = false;
				s.addEventListener('mouseenter', function () {
					if (!hiRes) { // load the full-size file once, for a sharp zoom
						hiRes = true;
						var full = s.getAttribute('data-full');
						if (full && img.getAttribute('src') !== full) { img.removeAttribute('srcset'); img.removeAttribute('sizes'); img.src = full; }
					}
					s.classList.add('is-zooming');
				});
				s.addEventListener('mousemove', function (e) {
					var r = s.getBoundingClientRect();
					var x = ((e.clientX - r.left) / r.width) * 100;
					var y = ((e.clientY - r.top) / r.height) * 100;
					img.style.transformOrigin = x + '% ' + y + '%';
				});
				s.addEventListener('mouseleave', function () {
					s.classList.remove('is-zooming');
					img.style.transformOrigin = '';
				});
			});
		}

		// full-screen zoom
		slides.forEach(function (s) { s.addEventListener('click', function () { if (!moved) openLb(g, i); }); });
		var z = g.querySelector('[data-sc-gallery-zoom]');
		if (z) z.addEventListener('click', function () { openLb(g, i); });
	});
})();