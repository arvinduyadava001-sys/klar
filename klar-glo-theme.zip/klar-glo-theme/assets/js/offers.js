/**
 * KLAR & GLO – Offers & Coupons panel (WooCommerce Cart / Checkout blocks)
 * Data comes from inc/offers.php (admin-ajax: kg_offers).
 * Apply / remove goes through the WooCommerce cart store, so totals update live.
 */
( function () {
	'use strict';

	var cfg   = window.kgOffers || {};
	var STORE = 'wc/store/cart';

	var state = {
		offers: [],
		loaded: false,
		drawer: false,
		showInput: false,
		busy: '',
		err: '',
		input: '',
		know: {}
	};

	/* ---------- helpers ---------- */
	function esc( s ) {
		return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}
	function qsa( sel, root ) { return Array.prototype.slice.call( ( root || document ).querySelectorAll( sel ) ); }

	var ICON = {
		tag:   '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.2"/></svg>',
		gift:  '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8M7.5 8a2.5 2.5 0 1 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 1 1 0 5"/></svg>',
		down:  '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
		right: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>',
		close: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
	};

	/* ---------- data ---------- */
	function load() {
		if ( ! cfg.ajax ) return;
		fetch( cfg.ajax + '?action=kg_offers&_=' + Date.now(), { credentials: 'same-origin' } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( j ) {
				state.offers = ( j && j.success && j.data && j.data.offers ) || [];
				state.loaded = true;
				renderAll();
			} )
			.catch( function () { state.loaded = true; renderAll(); } );
	}

	function cartStore() {
		return window.wp && wp.data && wp.data.dispatch( STORE );
	}

	function applyCode( code ) {
		code = ( code || '' ).trim();
		if ( ! code ) return;
		var st = cartStore();
		if ( ! st || ! st.applyCoupon ) { state.err = 'Please refresh the page and try again.'; renderAll(); return; }
		state.busy = code; state.err = ''; renderAll();
		Promise.resolve( st.applyCoupon( code ) )
			.then( function () {
				state.busy = ''; state.input = ''; state.showInput = false; state.drawer = false;
				renderAll(); load();
			} )
			.catch( function ( e ) {
				state.busy = '';
				state.err = ( e && e.message ) ? String( e.message ).replace( /<[^>]*>/g, '' ) : 'This coupon could not be applied.';
				renderAll();
			} );
	}

	function removeCode( code ) {
		var st = cartStore();
		if ( ! st || ! st.removeCoupon ) return;
		state.busy = code; renderAll();
		Promise.resolve( st.removeCoupon( code ) ).then( function () { state.busy = ''; renderAll(); load(); } )
			.catch( function () { state.busy = ''; renderAll(); } );
	}

	/* ---------- templates ---------- */
	function errHtml() { return state.err ? '<div class="kg-offers__err">' + esc( state.err ) + '</div>' : ''; }

	function savingLine( o ) {
		if ( o.savingText ) return '<div class="kg-offers__save">Save ' + esc( o.savingText ) + '</div>';
		if ( o.freeShip )   return '<div class="kg-offers__save">Free shipping</div>';
		return '';
	}

	function panelHtml() {
		var avail   = state.offers.filter( function ( o ) { return o.status === 'available' && ! o.applied; } );
		var applied = state.offers.filter( function ( o ) { return o.applied; } );
		var best    = avail[ 0 ];
		var h = '<div class="kg-offers__card">';

		applied.forEach( function ( o ) {
			h += '<div class="kg-offers__row">' +
				'<span class="kg-offers__ico is-on">' + ICON.tag + '</span>' +
				'<div class="kg-offers__txt"><div class="kg-offers__code">' + esc( o.code ) + '</div>' +
				'<div class="kg-offers__save">Coupon applied' + ( o.savingText ? ' · you save ' + esc( o.savingText ) : '' ) + '</div></div>' +
				'<button type="button" class="kg-offers__btn is-ghost" data-kg="remove" data-code="' + esc( o.code ) + '"' + ( state.busy === o.code ? ' disabled' : '' ) + '>Remove</button></div>';
		} );

		if ( best ) {
			h += '<div class="kg-offers__row">' +
				'<span class="kg-offers__ico">' + ICON.tag + '</span>' +
				'<div class="kg-offers__txt"><div class="kg-offers__code">' + esc( best.code ) + '</div>' +
				( best.desc ? '<div class="kg-offers__desc">' + esc( best.desc ) + '</div>' : '' ) +
				savingLine( best ) + '</div>' +
				'<button type="button" class="kg-offers__btn" data-kg="apply" data-code="' + esc( best.code ) + '"' + ( state.busy ? ' disabled' : '' ) + '>' + ( state.busy === best.code ? '…' : 'Apply' ) + '</button></div>';
		}

		h += '<div class="kg-offers__enter-wrap"><button type="button" class="kg-offers__enter" data-kg="toggle-input" aria-expanded="' + state.showInput + '">Enter coupon code <span class="' + ( state.showInput ? 'is-up' : '' ) + '">' + ICON.down + '</span></button>';
		if ( state.showInput ) {
			h += '<div class="kg-offers__input"><input type="text" data-kg-input placeholder="Enter coupon code" value="' + esc( state.input ) + '" autocomplete="off">' +
				'<button type="button" class="kg-offers__btn" data-kg="apply-input"' + ( state.input.trim() && ! state.busy ? '' : ' disabled' ) + '>' + ( state.busy && state.busy === state.input.trim() ? '…' : 'Apply' ) + '</button></div>';
		}
		h += errHtml() + '</div>';

		if ( state.offers.length ) {
			h += '<button type="button" class="kg-offers__all" data-kg="open-drawer">' +
				'<span class="kg-offers__ico is-grey">' + ICON.gift + '</span>' +
				'<span class="kg-offers__txt"><span class="kg-offers__code">View all offers</span><span class="kg-offers__desc">Coupons</span></span>' +
				'<span class="kg-offers__count">' + state.offers.length + '</span>' + ICON.right + '</button>';
		}
		return h + '</div>';
	}

	function offerCard( o, idx ) {
		var key = 'd' + idx + o.code;
		var open = !! state.know[ key ];
		var unavailable = o.status !== 'available' && ! o.applied;
		var h = '<div class="kg-offers__oc' + ( ! unavailable && idx === 0 && ! o.applied ? ' is-best' : '' ) + '">' +
			'<div class="kg-offers__oc-main"><div class="kg-offers__txt">' +
			'<div class="kg-offers__code">' + esc( o.code ) + '</div>' +
			( o.desc ? '<div class="kg-offers__desc">' + esc( o.desc ) + '</div>' : '' );
		if ( unavailable ) {
			if ( o.needText ) h += '<div class="kg-offers__need">Add items worth ' + esc( o.needText ) + ' more to avail</div>';
			else if ( o.reason ) h += '<div class="kg-offers__need">' + esc( o.reason ) + '</div>';
		} else if ( o.applied ) {
			h += '<div class="kg-offers__save">Applied' + ( o.savingText ? ' · saving ' + esc( o.savingText ) : '' ) + '</div>';
		} else {
			h += savingLine( o );
		}
		if ( o.more && o.more.length ) {
			h += '<button type="button" class="kg-offers__know" data-kg="know" data-key="' + esc( key ) + '">Know more <span class="' + ( open ? 'is-up' : '' ) + '">' + ICON.down + '</span></button>';
			if ( open ) h += '<ul class="kg-offers__more">' + o.more.map( function ( m ) { return '<li>' + esc( m ) + '</li>'; } ).join( '' ) + '</ul>';
		}
		h += '</div>';
		if ( o.applied ) {
			h += '<button type="button" class="kg-offers__btn is-ghost" data-kg="remove" data-code="' + esc( o.code ) + '">Remove</button>';
		} else if ( unavailable ) {
			h += '<a class="kg-offers__add" href="' + esc( cfg.shopUrl || '/' ) + '">+ Add item(s)</a>';
		} else {
			h += '<button type="button" class="kg-offers__btn" data-kg="apply" data-code="' + esc( o.code ) + '"' + ( state.busy ? ' disabled' : '' ) + '>' + ( state.busy === o.code ? '…' : 'Apply' ) + '</button>';
		}
		return h + '</div></div>';
	}

	function drawerHtml() {
		var usable = state.offers.filter( function ( o ) { return o.status === 'available' || o.applied; } );
		var no     = state.offers.filter( function ( o ) { return o.status !== 'available' && ! o.applied; } );
		var h = '<div class="kg-offers__panel" role="dialog" aria-modal="true" aria-label="All offers">' +
			'<div class="kg-offers__head"><span class="kg-offers__ico is-on">' + ICON.gift + '</span><h3>All Offers</h3>' +
			'<button type="button" class="kg-offers__x" data-kg="close-drawer" aria-label="Close">' + ICON.close + '</button></div>' +
			'<div class="kg-offers__body">' +
			'<div class="kg-offers__input is-big"><input type="text" data-kg-input placeholder="Enter coupon code" value="' + esc( state.input ) + '" autocomplete="off">' +
			'<button type="button" class="kg-offers__btn" data-kg="apply-input"' + ( state.input.trim() && ! state.busy ? '' : ' disabled' ) + '>Apply</button></div>' + errHtml();
		usable.forEach( function ( o, i ) { h += offerCard( o, i ); } );
		if ( no.length ) {
			h += '<div class="kg-offers__sub">Unavailable offers</div>';
			no.forEach( function ( o, i ) { h += offerCard( o, 100 + i ); } );
		}
		if ( ! state.offers.length ) h += '<p class="kg-offers__empty">No offers available right now.</p>';
		return h + '</div></div>';
	}

	/* ---------- render ---------- */
	function ensureDrawer() {
		var d = document.getElementById( 'kg-offers-drawer' );
		if ( ! d ) {
			d = document.createElement( 'div' );
			d.id = 'kg-offers-drawer';
			d.className = 'kg-offers__drawer';
			d.innerHTML = '<div class="kg-offers__overlay" data-kg="close-drawer"></div><div class="kg-offers__slot"></div>';
			document.body.appendChild( d );
		}
		return d;
	}

	function renderAll() {
		var active = document.activeElement;
		var refocus = active && active.hasAttribute && active.hasAttribute( 'data-kg-input' );
		var inDrawer = refocus && active.closest && active.closest( '#kg-offers-drawer' );

		qsa( '.kg-offers' ).forEach( function ( root ) { root.innerHTML = panelHtml(); } );

		var d = ensureDrawer();
		d.classList.toggle( 'is-open', state.drawer );
		document.documentElement.classList.toggle( 'kg-offers-lock', state.drawer );
		if ( state.drawer ) d.querySelector( '.kg-offers__slot' ).innerHTML = drawerHtml();

		if ( refocus ) {
			var scope = inDrawer ? d : document;
			var inp = scope.querySelector( '[data-kg-input]' );
			if ( inp ) { inp.focus(); var l = inp.value.length; try { inp.setSelectionRange( l, l ); } catch ( e ) {} }
		}
	}

	/* ---------- injection next to the native coupon box ---------- */
	function inject() {
		var made = false;
		qsa( '.wc-block-components-totals-coupon' ).forEach( function ( el ) {
			var wrap = el.closest( '.wp-block-woocommerce-cart-order-summary-coupon-form-block, .wp-block-woocommerce-checkout-order-summary-coupon-form-block' ) ||
				el.closest( '.wc-block-components-totals-wrapper' ) || el;
			var prev = wrap.previousElementSibling;
			if ( prev && prev.classList.contains( 'kg-offers' ) ) return;
			var root = document.createElement( 'div' );
			root.className = 'kg-offers';
			wrap.parentNode.insertBefore( root, wrap );
			made = true;
		} );
		if ( made ) {
			document.body.classList.add( 'kg-offers-on' ); // native coupon box is hidden only once ours exists
			renderAll();
		}
	}

	/* ---------- events ---------- */
	document.addEventListener( 'click', function ( e ) {
		var t = e.target.closest ? e.target.closest( '[data-kg]' ) : null;
		if ( ! t ) return;
		var a = t.getAttribute( 'data-kg' );
		if ( a === 'apply' )            { applyCode( t.getAttribute( 'data-code' ) ); }
		else if ( a === 'apply-input' ) { applyCode( state.input ); }
		else if ( a === 'remove' )      { removeCode( t.getAttribute( 'data-code' ) ); }
		else if ( a === 'toggle-input' ){ state.showInput = ! state.showInput; state.err = ''; renderAll(); var i = document.querySelector( '.kg-offers [data-kg-input]' ); if ( i ) i.focus(); }
		else if ( a === 'open-drawer' ) { state.drawer = true; state.err = ''; renderAll(); }
		else if ( a === 'close-drawer' ){ state.drawer = false; state.err = ''; renderAll(); }
		else if ( a === 'know' )        { var k = t.getAttribute( 'data-key' ); state.know[ k ] = ! state.know[ k ]; renderAll(); }
	} );

	document.addEventListener( 'input', function ( e ) {
		if ( ! e.target.hasAttribute || ! e.target.hasAttribute( 'data-kg-input' ) ) return;
		state.input = e.target.value;
		qsa( '[data-kg="apply-input"]' ).forEach( function ( b ) { b.disabled = ! state.input.trim() || !! state.busy; } );
		qsa( '[data-kg-input]' ).forEach( function ( i ) { if ( i !== e.target ) i.value = state.input; } );
	} );

	document.addEventListener( 'keydown', function ( e ) {
		if ( e.key === 'Escape' && state.drawer ) { state.drawer = false; renderAll(); }
		if ( e.key === 'Enter' && e.target.hasAttribute && e.target.hasAttribute( 'data-kg-input' ) ) { e.preventDefault(); applyCode( state.input ); }
	} );

	/* ---------- boot ---------- */
	function boot() {
		inject();
		load();

		var t;
		new MutationObserver( function () { clearTimeout( t ); t = setTimeout( inject, 80 ); } )
			.observe( document.body, { childList: true, subtree: true } );

		// re-check offers whenever cart items / coupons change
		var last = '';
		if ( window.wp && wp.data && wp.data.subscribe ) {
			var timer;
			wp.data.subscribe( function () {
				var sel = wp.data.select( STORE );
				if ( ! sel || ! sel.getCartData ) return;
				var d = sel.getCartData() || {};
				var sig = ( d.items || [] ).map( function ( i ) { return i.key + ':' + i.quantity; } ).join( ',' ) + '|' +
					( d.coupons || [] ).map( function ( c ) { return c.code; } ).join( ',' );
				if ( sig === last ) return;
				var first = last === '';
				last = sig;
				if ( first ) return; // initial load already fetched
				clearTimeout( timer );
				timer = setTimeout( load, 250 );
			} );
		}
	}

	if ( window.wp && wp.domReady ) wp.domReady( boot ); else document.addEventListener( 'DOMContentLoaded', boot );
} )();
