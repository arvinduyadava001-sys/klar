(function () {
	'use strict';

	// Mobile menu toggle
	var toggle = document.querySelector('[data-sc-menu-toggle]');
	var nav = document.querySelector('[data-sc-nav]');
	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			nav.classList.toggle('is-open');
		});
	}

	// Announcement bar rotation
	var track = document.querySelector('[data-sc-announce]');
	if (track) {
		var spans = track.querySelectorAll('span');
		if (spans.length > 1) {
			var idx = 0;
			setInterval(function () {
				spans[idx].classList.remove('is-active');
				idx = (idx + 1) % spans.length;
				spans[idx].classList.add('is-active');
			}, 4000);
		}
	}

	// Hero slider
	var slider = document.querySelector('[data-sc-hero-slider]');
	if (slider) {
		var slides = slider.querySelectorAll('.sc-hero-slide');
		var dots = slider.querySelectorAll('[data-sc-hero-dots] button');
		var prevBtn = slider.querySelector('[data-sc-hero-prev]');
		var nextBtn = slider.querySelector('[data-sc-hero-next]');
		var current = 0;
		var timer = null;

		function goTo(index) {
			if (!slides.length) return;
			current = (index + slides.length) % slides.length;
			slides.forEach(function (s, i) {
				s.classList.toggle('is-active', i === current);
			});
			dots.forEach(function (d, i) {
				d.classList.toggle('is-active', i === current);
			});
		}

		function startAutoplay() {
			if (slides.length < 2) return;
			stopAutoplay();
			timer = setInterval(function () { goTo(current + 1); }, 6000);
		}
		function stopAutoplay() {
			if (timer) clearInterval(timer);
		}

		if (prevBtn) prevBtn.addEventListener('click', function () { goTo(current - 1); startAutoplay(); });
		if (nextBtn) nextBtn.addEventListener('click', function () { goTo(current + 1); startAutoplay(); });
		dots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				goTo(parseInt(dot.getAttribute('data-slide'), 10) || 0);
				startAutoplay();
			});
		});

		slider.addEventListener('mouseenter', stopAutoplay);
		slider.addEventListener('mouseleave', startAutoplay);

		// Touch swipe (mobile)
		var touchX = null;
		slider.addEventListener('touchstart', function (e) { touchX = e.touches[0].clientX; stopAutoplay(); }, { passive: true });
		slider.addEventListener('touchend', function (e) {
			if (touchX === null) return;
			var dx = e.changedTouches[0].clientX - touchX;
			touchX = null;
			if (Math.abs(dx) > 40) goTo(current + (dx < 0 ? 1 : -1));
			startAutoplay();
		}, { passive: true });

		startAutoplay();
	}

	// Shop by Concerns slider
	var concernSlider = document.querySelector('[data-sc-concern-slider]');
	if (concernSlider) {
		var cSlides = concernSlider.querySelectorAll('.sc-concern-slide');
		var cDots = document.querySelectorAll('[data-sc-concern-progress] span');
		var cPrev = document.querySelector('[data-sc-concern-prev]');
		var cNext = document.querySelector('[data-sc-concern-next]');
		var cCurrent = 0;

		function cGoTo(index) {
			if (!cSlides.length) return;
			cCurrent = (index + cSlides.length) % cSlides.length;
			cSlides.forEach(function (s, i) { s.classList.toggle('is-active', i === cCurrent); });
			cDots.forEach(function (d, i) { d.classList.toggle('is-active', i === cCurrent); });
		}
		if (cPrev) cPrev.addEventListener('click', function () { cGoTo(cCurrent - 1); });
		if (cNext) cNext.addEventListener('click', function () { cGoTo(cCurrent + 1); });
		cDots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				cGoTo(parseInt(dot.getAttribute('data-slide'), 10) || 0);
			});
		});
	}

	// Shop by Concerns — horizontal scroll with arrows + autoplay
	var concernScroll = document.querySelector('[data-sc-concern-scroll]');
	if (concernScroll) {
		var track = concernScroll.querySelector('.sc-concern-grid-big');
		var prevBtn = concernScroll.querySelector('[data-sc-concern-prev]');
		var nextBtn = concernScroll.querySelector('[data-sc-concern-next]');
		var scrollTimer = null;

		function stepWidth() {
			var item = track.querySelector('.sc-concern-photo');
			if (!item) return 300;
			var style = window.getComputedStyle(track);
			var gap = parseFloat(style.columnGap || style.gap || 18);
			return item.getBoundingClientRect().width + gap;
		}
		function scrollNext() {
			var maxScroll = track.scrollWidth - track.clientWidth - 2;
			if (track.scrollLeft >= maxScroll) {
				track.scrollTo({ left: 0, behavior: 'smooth' });
			} else {
				track.scrollBy({ left: stepWidth(), behavior: 'smooth' });
			}
		}
		function scrollPrev() {
			track.scrollBy({ left: -stepWidth(), behavior: 'smooth' });
		}
		function startConcernAutoplay() {
			stopConcernAutoplay();
			scrollTimer = setInterval(scrollNext, 3500);
		}
		function stopConcernAutoplay() {
			if (scrollTimer) clearInterval(scrollTimer);
		}

		if (nextBtn) nextBtn.addEventListener('click', function () { scrollNext(); startConcernAutoplay(); });
		if (prevBtn) prevBtn.addEventListener('click', function () { scrollPrev(); startConcernAutoplay(); });
		concernScroll.addEventListener('mouseenter', stopConcernAutoplay);
		concernScroll.addEventListener('mouseleave', startConcernAutoplay);
		concernScroll.addEventListener('touchstart', stopConcernAutoplay, { passive: true });
		concernScroll.addEventListener('touchend', startConcernAutoplay, { passive: true });

		startConcernAutoplay();
	}

	// Morning / Evening routine icons next to product names
	var SC_SUN_ICON = '<svg class="sc-routine-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><line x1="12" y1="2" x2="12" y2="4"></line><line x1="12" y1="20" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="6.34" y2="6.34"></line><line x1="17.66" y1="17.66" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="4" y2="12"></line><line x1="20" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="6.34" y2="17.66"></line><line x1="17.66" y1="6.34" x2="19.07" y2="4.93"></line></svg>';
	var SC_MOON_ICON = '<svg class="sc-routine-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';

	function scRoutineIconsFor(name) {
		var n = (name || '').toLowerCase();
		if (n.indexOf('night') !== -1) {
			return '<span class="sc-routine-icons" title="Evening">' + SC_MOON_ICON + '</span>';
		}
		if (n.indexOf('sunscreen') !== -1 || n.indexOf('sun screen') !== -1 || n.indexOf('spf') !== -1) {
			return '<span class="sc-routine-icons" title="Morning">' + SC_SUN_ICON + '</span>';
		}
		if (
			n.indexOf('cleanser') !== -1 ||
			n.indexOf('mist') !== -1 ||
			n.indexOf('serum') !== -1 ||
			n.indexOf('moisturizer') !== -1 ||
			n.indexOf('moisturiser') !== -1 ||
			n.indexOf('day cream') !== -1 ||
			n.indexOf('tonic') !== -1 ||
			n.indexOf('gel cream') !== -1 ||
			n.indexOf('hydra gel cream') !== -1
		) {
			return '<span class="sc-routine-icons" title="Morning & Evening">' + SC_SUN_ICON + SC_MOON_ICON + '</span>';
		}
		return '';
	}

	var scTitleSelectors = [
		'.sc-product-title',
		'.woocommerce-loop-product__title',
		'.woocommerce ul.products li.product h2',
		'h1.product_title',
		'.product_title'
	];
	document.querySelectorAll(scTitleSelectors.join(',')).forEach(function (el) {
		if (el.querySelector('.sc-routine-icons')) return; // already processed
		if (el.closest('.sc-carousel')) return; // Bestsellers row: no routine icons here
		var icons = scRoutineIconsFor(el.textContent);
		if (icons) el.insertAdjacentHTML('beforeend', ' ' + icons);
	});

	// Bestsellers carousel (left/right arrow buttons)
	var carousels = document.querySelectorAll('[data-sc-carousel]');
	carousels.forEach(function (carousel) {
		var track = carousel.querySelector('[data-sc-carousel-track]');
		var prevBtn = carousel.querySelector('[data-sc-carousel-prev]');
		var nextBtn = carousel.querySelector('[data-sc-carousel-next]');
		if (!track) return;

		function stepWidth() {
			var item = track.querySelector('.sc-product-card');
			if (!item) return track.clientWidth;
			var style = window.getComputedStyle(track);
			var gap = parseFloat(style.columnGap || style.gap || 22);
			return item.getBoundingClientRect().width + gap;
		}

		function updateArrowState() {
			if (!prevBtn || !nextBtn) return;
			var maxScroll = track.scrollWidth - track.clientWidth - 2;
			prevBtn.disabled = track.scrollLeft <= 2;
			nextBtn.disabled = track.scrollLeft >= maxScroll;
		}

		if (nextBtn) {
			nextBtn.addEventListener('click', function () {
				track.scrollBy({ left: stepWidth(), behavior: 'smooth' });
			});
		}
		if (prevBtn) {
			prevBtn.addEventListener('click', function () {
				track.scrollBy({ left: -stepWidth(), behavior: 'smooth' });
			});
		}
		track.addEventListener('scroll', updateArrowState);
		window.addEventListener('resize', updateArrowState);
		updateArrowState();
	});

	// Single product: quantity stepper (- / number / +)
	document.querySelectorAll('.sc-qty-row .quantity').forEach(function (qtyWrap) {
		var input = qtyWrap.querySelector('input.qty');
		if (!input || qtyWrap.querySelector('.sc-qty-btn')) return;

		var minus = document.createElement('button');
		minus.type = 'button';
		minus.className = 'sc-qty-btn sc-qty-minus';
		minus.setAttribute('aria-label', 'Decrease quantity');
		minus.textContent = '\u2212';

		var plus = document.createElement('button');
		plus.type = 'button';
		plus.className = 'sc-qty-btn sc-qty-plus';
		plus.setAttribute('aria-label', 'Increase quantity');
		plus.textContent = '+';

		qtyWrap.insertBefore(minus, input);
		qtyWrap.appendChild(plus);
		qtyWrap.classList.add('sc-qty-stepper');

		function step(dir) {
			var min = parseFloat(input.getAttribute('min')) || 1;
			var max = input.getAttribute('max') ? parseFloat(input.getAttribute('max')) : Infinity;
			var stepVal = parseFloat(input.getAttribute('step')) || 1;
			var val = parseFloat(input.value) || min;
			val = dir > 0 ? Math.min(max, val + stepVal) : Math.max(min, val - stepVal);
			input.value = val;
			input.dispatchEvent(new Event('change', { bubbles: true }));
		}
		minus.addEventListener('click', function () { step(-1); });
		plus.addEventListener('click', function () { step(1); });
	});

	// Single product: "Size" pill buttons sync to WooCommerce's hidden native select
	document.querySelectorAll('[data-sc-variation-swatch]').forEach(function (row) {
		var select = row.querySelector('select');
		var pills = row.querySelectorAll('.sc-variation-pill');
		if (!select || !pills.length) return;

		pills.forEach(function (pill) {
			pill.addEventListener('click', function () {
				pills.forEach(function (p) { p.classList.remove('is-active'); });
				pill.classList.add('is-active');
				select.value = pill.getAttribute('data-value');

				// Fire both a native change event and, if jQuery is present
				// (WooCommerce always loads it), a jQuery-triggered change —
				// WooCommerce's own variation script listens via jQuery and
				// this guarantees it picks up the selection reliably.
				select.dispatchEvent(new Event('change', { bubbles: true }));
				if (window.jQuery) {
					window.jQuery(select).val(pill.getAttribute('data-value')).trigger('change');
				}

				var labelStrong = row.querySelector('.sc-variation-selected');
				if (labelStrong) {
					labelStrong.textContent = pill.textContent;
				} else {
					var label = row.querySelector('.sc-variation-label');
					if (label) label.insertAdjacentHTML('beforeend', ' <strong class="sc-variation-selected">' + pill.textContent + '</strong>');
				}
			});
		});
	});

	// Single product: "Buy It Now" — flag the form so it redirects to checkout
	document.querySelectorAll('[data-sc-buy-now]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var form = btn.closest('form');
			if (!form) return;
			var flag = form.querySelector('[data-sc-buy-now-flag]');
			if (flag) flag.value = '1';
		});
	});
	// Any normal "Add to Cart" click should not carry a stale buy_now flag forward.
	document.querySelectorAll('.single_add_to_cart_button').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var form = btn.closest('form');
			if (!form) return;
			var flag = form.querySelector('[data-sc-buy-now-flag]');
			if (flag) flag.value = '';
		});
	});

	// Front page: "Know Your Ingredients" — swap the image when an ingredient is chosen
	document.querySelectorAll('[data-sc-formula]').forEach(function (wrap) {
		var items = wrap.querySelectorAll('.sc-formula-item');
		var imgs = wrap.querySelectorAll('.sc-formula-slide');
		function activate(key) {
			items.forEach(function (it) {
				var on = it.getAttribute('data-ing') === key;
				it.classList.toggle('is-active', on);
				it.setAttribute('aria-pressed', on ? 'true' : 'false');
			});
			imgs.forEach(function (img) {
				img.classList.toggle('is-active', img.getAttribute('data-ing') === key);
			});
		}
		items.forEach(function (it) {
			var key = it.getAttribute('data-ing');
			it.addEventListener('click', function () { activate(key); });
			it.addEventListener('mouseenter', function () {
				if (window.matchMedia('(hover: hover)').matches) activate(key);
			});
		});
	});
})();
