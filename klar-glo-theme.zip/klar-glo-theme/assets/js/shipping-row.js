/**
 * KLAR & GLO – Cart + Checkout shipping row
 * "Free shipping  FREE"  ->  "Shipping  ~~₹55.00~~ FREE"
 * Only when shipping is free; paid shipping is left untouched.
 */
( function () {
	'use strict';

	var cfg = window.kgShipping || {};
	var WAS = cfg.was || '\u20b955.00';

	function apply() {
		var rows = document.querySelectorAll( '.wc-block-components-totals-shipping .wc-block-components-totals-item' );
		Array.prototype.forEach.call( rows, function ( row ) {
			var label = row.querySelector( '.wc-block-components-totals-item__label' );
			var value = row.querySelector( '.wc-block-components-totals-item__value' );
			if ( ! label || ! value ) return;

			if ( /^\s*free\s*$/i.test( value.textContent ) ) {
				// change only the text node (safe for React)
				var node = label.firstChild;
				while ( node && node.nodeType !== 3 ) node = node.nextSibling;
				if ( node && node.nodeValue !== 'Shipping' ) node.nodeValue = 'Shipping';
				if ( value.getAttribute( 'data-kg-was' ) !== WAS ) value.setAttribute( 'data-kg-was', WAS );
				if ( ! value.classList.contains( 'kg-ship-free' ) ) value.classList.add( 'kg-ship-free' );
			} else if ( value.classList.contains( 'kg-ship-free' ) ) {
				value.classList.remove( 'kg-ship-free' );
				value.removeAttribute( 'data-kg-was' );
			}
		} );
	}

	wp.domReady( function () {
		apply();
		var t;
		new MutationObserver( function () {
			clearTimeout( t );
			t = setTimeout( apply, 60 );
		} ).observe( document.body, { childList: true, subtree: true } );
	} );
} )();
