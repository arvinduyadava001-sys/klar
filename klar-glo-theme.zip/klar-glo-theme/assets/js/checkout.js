/**
 * KLAR & GLO – Checkout: Email ki jagah Mobile number
 *
 * WooCommerce Block Checkout me email field hataya nahi ja sakta, isliye:
 *  1) Contact information me "Mobile number" field dikhate hain
 *  2) Asli email field hide hota hai; uski value mobile se banti hai (98xxxxxx@guest.klarglo.in)
 *     (agar logged-in customer ka real email already hai to wahi rehta hai)
 *  3) Mobile number billing + shipping phone me save hota hai
 */
( function () {
	'use strict';

	var cfg = window.kgCheckout || {};
	var DOMAIN = cfg.emailDomain || 'guest.klarglo.in';
	var CART = 'wc/store/cart';
	var WAS = cfg.shippingWas || '₹55.00';  // old shipping price shown struck-through when shipping is free
	var touched = false;
	var wrap, input, errorEl;

	function digits( v ) {
		v = String( v || '' ).replace( /\D/g, '' );
		if ( v.length === 12 && v.indexOf( '91' ) === 0 ) v = v.slice( 2 );
		if ( v.length === 11 && v.charAt( 0 ) === '0' ) v = v.slice( 1 );
		return v.slice( 0, 10 );
	}
	function isValid( d ) { return /^[6-9]\d{9}$/.test( d ); }
	function isPlaceholder( e ) { return !! e && e.toLowerCase().slice( -( DOMAIN.length + 1 ) ) === '@' + DOMAIN; }

	function store() {
		return window.wp && wp.data ? { s: wp.data.select( CART ), d: wp.data.dispatch( CART ) } : null;
	}

	function customerData() {
		var st = store();
		try { return st.s.getCustomerData(); } catch ( e ) { return null; }
	}

	/* ---- store me number + email likhna ---- */
	function push( d ) {
		var st = store(), cd = customerData();
		if ( ! st || ! cd ) return;
		var phone = '+91' + d;
		var cur = ( cd.billingAddress && cd.billingAddress.email ) || '';
		var email = cur && ! isPlaceholder( cur ) ? cur : d + '@' + DOMAIN;
		try {
			st.d.setBillingAddress( { email: email, phone: phone } );
			st.d.setShippingAddress( { phone: phone } );
		} catch ( e ) { /* ignore */ }
	}

	function showError( on ) {
		if ( ! wrap ) return;
		wrap.classList.toggle( 'kg-has-error', on );
		errorEl.hidden = ! on;
	}

	/* ---- field banana ---- */
	function build() {
		wrap = document.createElement( 'div' );
		wrap.className = 'kg-mobile-field';
		wrap.innerHTML =
			'<label for="kg-mobile">Mobile number</label>' +
			'<div class="kg-mobile-input"><span class="kg-cc">+91</span>' +
			'<input id="kg-mobile" type="tel" inputmode="numeric" autocomplete="tel-national" maxlength="14" placeholder="10-digit mobile number" required></div>' +
			'<p class="kg-help">We\'ll use this number for order & delivery updates.</p>' +
			'<p class="kg-error" role="alert" hidden>Please enter a valid 10-digit mobile number.</p>';
		input = wrap.querySelector( 'input' );
		errorEl = wrap.querySelector( '.kg-error' );

		input.addEventListener( 'input', function () {
			touched = true;
			var d = digits( input.value );
			input.value = d;
			if ( isValid( d ) ) { showError( false ); push( d ); }
		} );
		input.addEventListener( 'blur', function () {
			if ( touched ) showError( ! isValid( digits( input.value ) ) );
		} );
	}

	/* ---- DOM me lagana / email + phone fields chhupana ---- */
	function ensure() {
		shippingRow();
		var block = document.querySelector( '.wp-block-woocommerce-checkout-contact-information-block' );
		if ( ! block ) return;
		if ( ! wrap ) build();

		if ( ! wrap.isConnected ) {
			var host = block.querySelector( '.wc-block-components-checkout-step__content' ) || block;
			host.insertBefore( wrap, host.firstChild );
		}

		var email = document.getElementById( 'email' );
		if ( email ) {
			var box = email.closest( '.wc-block-components-text-input' );
			if ( box ) box.classList.add( 'kg-hide' );
		}

		// store se existing number prefill (returning customers / saved address)
		if ( ! touched && ! input.value ) {
			var cd = customerData();
			var ph = cd && ( ( cd.shippingAddress && cd.shippingAddress.phone ) || ( cd.billingAddress && cd.billingAddress.phone ) );
			var d = digits( ph );
			if ( isValid( d ) ) { input.value = d; push( d ); }
		}
	}

	/* ---- Shipping row: "Free shipping / FREE"  ->  "Shipping / ~~₹55~~ FREE" ---- */
	function shippingRow() {
		var rows = document.querySelectorAll( '.wc-block-components-totals-shipping .wc-block-components-totals-item' );
		Array.prototype.forEach.call( rows, function ( row ) {
			var label = row.querySelector( '.wc-block-components-totals-item__label' );
			var value = row.querySelector( '.wc-block-components-totals-item__value' );
			if ( ! label || ! value ) return;

			var isFree = /^\s*free\s*$/i.test( value.textContent );
			if ( isFree ) {
				// label text: change only the text node (safe for React)
				var node = label.firstChild;
				while ( node && node.nodeType !== 3 ) node = node.nextSibling;
				if ( node && node.nodeValue !== 'Shipping' ) node.nodeValue = 'Shipping';
				// struck-through old price is drawn by CSS (::before) from this attribute
				if ( value.getAttribute( 'data-kg-was' ) !== WAS ) value.setAttribute( 'data-kg-was', WAS );
				if ( ! value.classList.contains( 'kg-ship-free' ) ) value.classList.add( 'kg-ship-free' );
			} else if ( value.classList.contains( 'kg-ship-free' ) ) {
				value.classList.remove( 'kg-ship-free' );
				value.removeAttribute( 'data-kg-was' );
			}
		} );
	}

	/* ---- Place order guard ---- */
	function guard( e ) {
		if ( ! wrap || ! wrap.isConnected ) return;
		if ( isValid( digits( input.value ) ) ) return;
		e.preventDefault();
		e.stopImmediatePropagation();
		showError( true );
		wrap.scrollIntoView( { behavior: 'smooth', block: 'center' } );
		input.focus( { preventScroll: true } );
	}
	document.addEventListener( 'click', function ( e ) {
		if ( e.target.closest && e.target.closest( '.wc-block-components-checkout-place-order-button' ) ) guard( e );
	}, true );
	document.addEventListener( 'submit', function ( e ) {
		if ( e.target.closest && e.target.closest( '.wc-block-checkout__form' ) ) guard( e );
	}, true );

	/* ---- React re-render ke baad dobara apply ---- */
	wp.domReady( function () {
		ensure();
		var t;
		new MutationObserver( function () {
			clearTimeout( t );
			t = setTimeout( ensure, 60 );
		} ).observe( document.body, { childList: true, subtree: true } );
	} );
} )();
