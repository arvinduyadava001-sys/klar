<?php
/**
 * KLAR & GLO – Cart / Checkout "Offers & Coupons" panel
 *
 *  - Best available coupon on top with one-tap Apply
 *  - "View all offers" drawer: available + unavailable coupons
 *    ("Add items worth ₹X more to avail")
 *
 * Which coupons are listed?  Only coupons where you tick
 * "Show in cart offers" (WooCommerce > Marketing > Coupons > edit coupon > General).
 * The coupon "Description" field is used as the offer text.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
 * 1) Admin: checkbox on the coupon screen
 * ------------------------------------------------------------- */
add_action( 'woocommerce_coupon_options', function () {
	woocommerce_wp_checkbox( array(
		'id'          => '_kg_show_offer',
		'label'       => __( 'Show in cart offers', 'skincare-clean' ),
		'description' => __( 'List this coupon in the "Offers" panel on the cart and checkout pages. The Description field above is shown as the offer text.', 'skincare-clean' ),
	) );
} );

add_action( 'woocommerce_coupon_options_save', function ( $post_id ) {
	update_post_meta( $post_id, '_kg_show_offer', isset( $_POST['_kg_show_offer'] ) ? 'yes' : 'no' ); // phpcs:ignore WordPress.Security.NonceVerification
} );

/* ---------------------------------------------------------------
 * 2) Assets (cart + checkout only)
 * ------------------------------------------------------------- */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() ) || is_wc_endpoint_url( 'order-received' ) ) {
		return;
	}
	$dir = get_template_directory();
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'kg-offers', $uri . '/assets/css/offers.css', array( 'skincare-clean-style' ), filemtime( $dir . '/assets/css/offers.css' ) );
	wp_enqueue_script( 'kg-offers', $uri . '/assets/js/offers.js', array( 'wp-data', 'wp-dom-ready' ), filemtime( $dir . '/assets/js/offers.js' ), true );
	wp_localize_script( 'kg-offers', 'kgOffers', array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'shopUrl' => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
	) );
}, 31 );

/* ---------------------------------------------------------------
 * 3) AJAX: offers for the current cart
 * ------------------------------------------------------------- */
add_action( 'wp_ajax_kg_offers', 'kg_offers_ajax' );
add_action( 'wp_ajax_nopriv_kg_offers', 'kg_offers_ajax' );

function kg_offers_money( $amount ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
}

function kg_offers_ajax() {
	if ( ! function_exists( 'WC' ) ) {
		wp_send_json_success( array( 'offers' => array() ) );
	}
	if ( null === WC()->cart && function_exists( 'wc_load_cart' ) ) {
		wc_load_cart();
	}
	$cart = WC()->cart;
	if ( ! $cart || $cart->is_empty() ) {
		wp_send_json_success( array( 'offers' => array() ) );
	}

	$ids = get_posts( array(
		'post_type'      => 'shop_coupon',
		'post_status'    => 'publish',
		'posts_per_page' => 30,
		'fields'         => 'ids',
		'meta_key'       => '_kg_show_offer', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'     => 'yes',            // phpcs:ignore WordPress.DB.SlowDBQuery
	) );

	$applied  = array_map( 'strtolower', $cart->get_applied_coupons() );
	$subtotal = (float) $cart->get_subtotal();
	$offers   = array();

	foreach ( $ids as $id ) {
		$coupon = new WC_Coupon( $id );
		$code   = $coupon->get_code();
		if ( ! $code ) continue;

		$status = 'available';
		$saving = 0;
		$need   = 0;
		$reason = '';

		$is_applied = in_array( strtolower( $code ), $applied, true );

		$discounts = new WC_Discounts( $cart );
		$valid     = $discounts->is_coupon_valid( $coupon );

		if ( is_wp_error( $valid ) ) {
			$err = $valid->get_error_code();
			// expired / used up / not found: do not list at all
			if ( in_array( $err, array( WC_Coupon::E_WC_COUPON_EXPIRED, WC_Coupon::E_WC_COUPON_USAGE_LIMIT_REACHED, WC_Coupon::E_WC_COUPON_NOT_EXIST ), true ) && ! $is_applied ) {
				continue;
			}
			if ( ! $is_applied ) {
				$status = 'unavailable';
				if ( WC_Coupon::E_WC_COUPON_MIN_SPEND_LIMIT_NOT_MET === $err ) {
					$need = max( 0, (float) $coupon->get_minimum_amount() - $subtotal );
				} else {
					$reason = wp_strip_all_tags( $valid->get_error_message() );
				}
			}
		}

		if ( 'available' === $status || $is_applied ) {
			$d = new WC_Discounts( $cart );
			$d->apply_coupon( $coupon, false );
			$by = $d->get_discounts_by_coupon();
			$saving = isset( $by[ $code ] ) ? (float) $by[ $code ] : ( $by ? (float) reset( $by ) : 0 );
		}

		// "Know more" details
		$more = array();
		if ( $coupon->get_minimum_amount() > 0 ) {
			$more[] = sprintf( __( 'Minimum order value %s', 'skincare-clean' ), kg_offers_money( $coupon->get_minimum_amount() ) );
		}
		if ( $coupon->get_maximum_amount() > 0 ) {
			$more[] = sprintf( __( 'Maximum order value %s', 'skincare-clean' ), kg_offers_money( $coupon->get_maximum_amount() ) );
		}
		if ( $coupon->get_free_shipping() ) {
			$more[] = __( 'Includes free shipping', 'skincare-clean' );
		}
		if ( $coupon->get_individual_use() ) {
			$more[] = __( 'Cannot be combined with other coupons', 'skincare-clean' );
		}
		if ( $coupon->get_exclude_sale_items() ) {
			$more[] = __( 'Not valid on sale items', 'skincare-clean' );
		}
		if ( $coupon->get_date_expires() ) {
			$more[] = sprintf( __( 'Valid till %s', 'skincare-clean' ), wc_format_datetime( $coupon->get_date_expires(), 'd M Y' ) );
		}
		if ( $coupon->get_usage_limit_per_user() > 0 ) {
			$more[] = sprintf( __( 'Limit %d use(s) per customer', 'skincare-clean' ), $coupon->get_usage_limit_per_user() );
		}

		$offers[] = array(
			'code'       => $code,
			'desc'       => wp_strip_all_tags( $coupon->get_description() ),
			'status'     => $status,
			'applied'    => $is_applied,
			'saving'     => $saving,
			'savingText' => $saving > 0 ? kg_offers_money( $saving ) : '',
			'freeShip'   => (bool) $coupon->get_free_shipping(),
			'need'       => $need,
			'needText'   => $need > 0 ? kg_offers_money( $need ) : '',
			'reason'     => $reason,
			'more'       => $more,
		);
	}

	// Applied first, then best saving; unavailable by smallest gap
	usort( $offers, function ( $a, $b ) {
		if ( $a['applied'] !== $b['applied'] ) return $a['applied'] ? -1 : 1;
		if ( $a['status'] !== $b['status'] ) return 'available' === $a['status'] ? -1 : 1;
		if ( 'available' === $a['status'] ) return $b['saving'] <=> $a['saving'];
		return $a['need'] <=> $b['need'];
	} );

	wp_send_json_success( array( 'offers' => $offers ) );
}

/* ===============================================================
 * 4) HEADER ANNOUNCEMENT BAR (.sc-announce): coupons + GloCoin offers
 *
 *  - Coupons: tick "Show in header bar" on the coupon (WooCommerce >
 *    Marketing > Coupons > edit coupon > General). The coupon "Description"
 *    is the text shown next to the code. Expired / used-up / email-restricted
 *    coupons are never shown. Customers tap the code to copy it.
 *  - GloCoin: messages come from WooCommerce > GloCoin settings (bonus, % back,
 *    coin value) and appear only while the GloCoin plugin is active.
 *  - "Free shipping" stays as the first message (edit via the filter below).
 *
 *  Filters:  kg_announce_static   array of plain-text messages shown first
 *            kg_announce_messages array of final HTML messages (add / remove / reorder)
 * =============================================================== */
add_action( 'woocommerce_coupon_options', function () {
	woocommerce_wp_checkbox( array(
		'id'          => '_kg_show_announce',
		'label'       => __( 'Show in header bar', 'skincare-clean' ),
		'description' => __( 'Show this code, with the Description above, in the rotating bar at the top of every page. Keep the Description short.', 'skincare-clean' ),
	) );
} );

add_action( 'woocommerce_coupon_options_save', function ( $post_id ) {
	update_post_meta( $post_id, '_kg_show_announce', isset( $_POST['_kg_show_announce'] ) ? 'yes' : 'no' ); // phpcs:ignore WordPress.Security.NonceVerification
	delete_transient( 'kg_announce_coupons' );
} );

// Any coupon publish / unpublish / trash refreshes the bar straight away.
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( $post && 'shop_coupon' === $post->post_type ) {
		delete_transient( 'kg_announce_coupons' );
	}
}, 10, 3 );

/** Money for the bar: no trailing .00 (₹200 not ₹200.00). */
function kg_announce_money( $amount ) {
	return preg_replace( '/\.00$/', '', kg_offers_money( $amount ) );
}

/** Coupons flagged for the bar, cached for 10 minutes. Returns [ ['code','text','expires'], ... ] */
function kg_announce_coupons() {
	if ( ! class_exists( 'WC_Coupon' ) ) {
		return array();
	}
	$list = get_transient( 'kg_announce_coupons' );
	if ( false === $list ) {
		$list = array();
		$ids  = get_posts( array(
			'post_type'      => 'shop_coupon',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_key'       => '_kg_show_announce', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => 'yes',               // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		foreach ( $ids as $id ) {
			$c    = new WC_Coupon( $id );
			$code = $c->get_code();
			if ( ! $code ) {
				continue;
			}
			// Private / limited coupons must never be advertised.
			if ( $c->get_email_restrictions() ) {
				continue;
			}
			if ( $c->get_usage_limit() > 0 && $c->get_usage_count() >= $c->get_usage_limit() ) {
				continue;
			}
			$text = trim( wp_strip_all_tags( $c->get_description() ) );
			if ( '' === $text ) {
				$type = $c->get_discount_type();
				$amt  = (float) $c->get_amount();
				if ( 'percent' === $type ) {
					$text = sprintf( __( '%s%% off', 'skincare-clean' ), rtrim( rtrim( number_format( $amt, 2 ), '0' ), '.' ) );
				} elseif ( 'fixed_product' === $type ) {
					$text = sprintf( __( '%s off per item', 'skincare-clean' ), kg_announce_money( $amt ) );
				} elseif ( $amt > 0 ) {
					$text = sprintf( __( '%s off your order', 'skincare-clean' ), kg_announce_money( $amt ) );
				} elseif ( $c->get_free_shipping() ) {
					$text = __( 'Free shipping', 'skincare-clean' );
				}
				if ( $text && $c->get_minimum_amount() > 0 ) {
					$text .= ' ' . sprintf( __( 'on orders above %s', 'skincare-clean' ), kg_announce_money( $c->get_minimum_amount() ) );
				}
			}
			$list[] = array(
				'code'    => $code,
				'text'    => mb_substr( $text, 0, 110 ),
				'expires' => $c->get_date_expires() ? (int) $c->get_date_expires()->getTimestamp() : 0,
			);
		}
		set_transient( 'kg_announce_coupons', $list, 10 * MINUTE_IN_SECONDS );
	}
	// Expiry is re-checked on every page view, so a coupon never outlives its end date.
	return array_values( array_filter( $list, function ( $x ) {
		return ! $x['expires'] || $x['expires'] > time();
	} ) );
}

/** All messages for the bar, as ready-to-print HTML (already escaped). */
function kg_announce_messages() {
	$out = array();

	foreach ( (array) apply_filters( 'kg_announce_static', array( __( 'Free shipping', 'skincare-clean' ) ) ) as $line ) {
		if ( '' !== trim( $line ) ) {
			$out[] = esc_html( $line );
		}
	}

	foreach ( kg_announce_coupons() as $c ) {
		$out[] = '<em class="sc-ann-label">' . esc_html__( 'Use code', 'skincare-clean' ) . '</em> '
			. '<button type="button" class="sc-ann-code" data-sc-copy="' . esc_attr( $c['code'] ) . '" title="' . esc_attr__( 'Tap to copy', 'skincare-clean' ) . '">' . esc_html( strtoupper( $c['code'] ) ) . '</button>'
			. ( $c['text'] ? ' <em class="sc-ann-desc">&ndash; ' . esc_html( $c['text'] ) . '</em>' : '' );
	}

	if ( class_exists( 'KGC_Settings' ) && class_exists( 'KGC_Ledger' ) && KGC_Settings::enabled() && function_exists( 'wc_get_page_permalink' ) ) {
		$account = wc_get_page_permalink( 'myaccount' );
		$wallet  = function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( 'glocoin-wallet', '', $account ) : $account;
		$bonus   = (int) KGC_Settings::get( 'reg_bonus' );
		$pct     = (float) KGC_Settings::get( 'earn_pct' );
		$logged  = is_user_logged_in();

		if ( ! $logged && $bonus > 0 ) {
			$out[] = '<a href="' . esc_url( $account ) . '">' . sprintf( esc_html__( 'Join Klar & Glo and get %s free', 'skincare-clean' ), '<b>' . esc_html( number_format_i18n( $bonus ) ) . ' GloCoins</b>' ) . '</a>';
		}
		if ( $pct > 0 ) {
			$pct_txt = rtrim( rtrim( number_format( $pct, 2 ), '0' ), '.' );
			$rate    = preg_replace( '/\.00$/', '', html_entity_decode( wp_strip_all_tags( wc_price( KGC_Settings::rate() ) ), ENT_QUOTES, 'UTF-8' ) );
			$out[]   = '<a href="' . esc_url( $logged ? $wallet : $account ) . '">' . sprintf( esc_html__( 'Earn %1$s back in GloCoins on every order. 1 GloCoin = %2$s', 'skincare-clean' ), '<b>' . esc_html( $pct_txt ) . '%</b>', esc_html( $rate ) ) . '</a>';
		}
		if ( $logged ) {
			$bal = (int) KGC_Ledger::balance( get_current_user_id() );
			if ( $bal > 0 ) {
				$out[] = '<a href="' . esc_url( $wallet ) . '">' . sprintf( esc_html__( 'You have %s to use at checkout', 'skincare-clean' ), '<b>' . esc_html( number_format_i18n( $bal ) ) . ' GloCoins</b>' ) . '</a>';
			}
		}
	}

	return array_values( array_filter( (array) apply_filters( 'kg_announce_messages', $out ) ) );
}

function kg_render_announce_bar() {
	$msgs = kg_announce_messages();
	if ( ! $msgs ) {
		return;
	}
	// Each message is ONE top-level <span> (the theme's rotator swaps these); nothing nested uses <span>.
	echo '<div class="sc-announce"><div class="sc-announce-track" data-sc-announce>';
	foreach ( $msgs as $i => $html ) {
		echo '<span' . ( 0 === $i ? ' class="is-active"' : '' ) . '>' . $html . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts above
	}
	echo '</div></div>';
}
