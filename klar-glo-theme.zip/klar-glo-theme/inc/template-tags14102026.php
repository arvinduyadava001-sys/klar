<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Original inline SVG icons for the "Common Concerns" tiles.
 * Drawn from scratch — no stock photography, so there's nothing to license.
 */
function sc_concern_icon( $key ) {
	$icons = array(
		'dullness'          => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round"><circle cx="24" cy="24" r="9"/><path d="M24 3v6M24 39v6M3 24h6M39 24h6M9.5 9.5l4.2 4.2M34.3 34.3l4.2 4.2M38.5 9.5l-4.2 4.2M13.7 34.3l-4.2 4.2"/></svg>',
		'hyperpigmentation' => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6"><circle cx="24" cy="24" r="16"/><circle cx="18" cy="19" r="2.6" fill="#111111" stroke="none"/><circle cx="29" cy="25" r="2" fill="#111111" stroke="none"/><circle cx="21" cy="30" r="1.6" fill="#111111" stroke="none"/></svg>',
		'barrier-repair'    => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6" stroke-linejoin="round"><path d="M24 4l16 6v10c0 11-7 18-16 24C15 38 8 31 8 20V10z"/></svg>',
		'sensitivity'       => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6" stroke-linejoin="round"><path d="M24 42s-14-9-14-20a8 8 0 0 1 14-5 8 8 0 0 1 14 5c0 11-14 20-14 20z"/></svg>',
		'dehydration'       => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6" stroke-linejoin="round"><path d="M24 5c8 10 14 17.5 14 24.5A14 14 0 1 1 10 29.5C10 22.5 16 15 24 5z"/></svg>',
		'sun-protection'    => '<svg viewBox="0 0 48 48" width="38" height="38" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round"><circle cx="24" cy="24" r="8"/><path d="M24 4v6M24 38v6M4 24h6M38 24h6M8.5 8.5l4.2 4.2M35.3 35.3l4.2 4.2M39.5 8.5l-4.2 4.2M12.7 35.3l-4.2 4.2"/></svg>',
	);
	return isset( $icons[ $key ] ) ? $icons[ $key ] : '';
}

/**
 * Original inline SVG icons for the "Know Your Ingredients" cards.
 */
function sc_ingredient_icon( $key ) {
	$icons = array(
		'niacinamide' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="14" y="6" width="20" height="36" rx="10"/><line x1="14" y1="24" x2="34" y2="24"/></svg>',
		'centella-asiatica' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M24 6C12 10 8 22 12 34c4 8 16 10 22 4 8-8 4-22-4-28-2-1.5-4-3-6-4z"/><path d="M24 10v28M24 18c-4 0-8 2-10 6M24 26c4 0 8 2 10 6"/></svg>',
		'ginseng-exosome' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M24 8c-2 6-6 8-10 10-3 1.5-5 4-5 8 0 6 5 10 11 10h8c6 0 11-4 11-10 0-4-2-6.5-5-8-4-2-8-4-10-10z"/><path d="M24 8v32M18 20c2 2 4 3 6 3M30 20c-2 2-4 3-6 3"/></svg>',
		'hyaluronic-acid' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M24 6c8 10 14 18 14 25a14 14 0 1 1-28 0c0-7 6-15 14-25z"/><path d="M17 30c0 4 3 7 7 7" opacity="0.6"/></svg>',
		'ceramides' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="10" width="34" height="7"/><rect x="7" y="20.5" width="34" height="7"/><rect x="7" y="31" width="34" height="7"/></svg>',
		'retinol' => '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#111111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M24 5l4.5 13.8H43L31.7 27l4.3 13.8L24 32.6 12 40.8 16.3 27 5 18.8h14.5z"/></svg>',
	);
	return isset( $icons[ $key ] ) ? $icons[ $key ] : '';
}

/**
 * Generic bottle-outline icon shown when a product has no featured image yet.
 */
function sc_product_fallback_icon() {
	return '<svg viewBox="0 0 48 48" width="44" height="44" fill="none" stroke="#a8a8a8" stroke-width="1.4" stroke-linejoin="round"><rect x="16" y="11" width="16" height="29" rx="3"/><rect x="20" y="4" width="8" height="7" rx="1.5"/><line x1="16" y1="21" x2="32" y2="21"/></svg>';
}

/**
 * Polished, brand-colored packaging illustrations per product type.
 * These are original flat-design mockups (not photos of the real product)
 * shown until a real product photo is uploaded as the featured image.
 * Pass the product's post_name (slug) or a generic type key.
 */
function sc_product_illustration( $slug ) {
	$map = array(
		'klar-glo-sunscreen'          => 'tube',
		'klar-glo-glow-serum'         => 'dropper',
		'klar-glo-skin-tonic'         => 'mist',
		'klar-glo-night-cream'        => 'jar',
		'klar-glo-hydrating-cleanser' => 'pump',
		'klar-glo-hydra-gel-cream'    => 'jar-gel',
	);
	$type = isset( $map[ $slug ] ) ? $map[ $slug ] : 'dropper';

	$illustrations = array(

		'tube' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0" stop-color="#eef1ec"/><stop offset="1" stop-color="#c9d6c4"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="150" rx="30" ry="6" fill="#00000012"/>
			<path d="M35 40 L85 40 L78 145 Q60 155 42 145 Z" fill="url(#g1)" stroke="#5c7a5e" stroke-width="1.5"/>
			<path d="M42 30 Q60 20 78 30 L85 40 L35 40 Z" fill="#5c7a5e"/>
			<rect x="46" y="70" width="28" height="34" rx="3" fill="#ffffff" opacity=".9"/>
			<text x="60" y="84" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="95" font-family="Arial" font-size="6" fill="#5c7a5e" text-anchor="middle">SPF</text>
		</svg>',

		'dropper' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0" stop-color="#f6f4ef"/><stop offset="1" stop-color="#e3ddc9"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="150" rx="26" ry="6" fill="#00000012"/>
			<rect x="34" y="55" width="52" height="90" rx="8" fill="url(#g2)" stroke="#b08d2f" stroke-width="1.5"/>
			<rect x="44" y="18" width="32" height="42" rx="4" fill="#3a3a3a"/>
			<rect x="52" y="6" width="16" height="16" rx="3" fill="#b08d2f"/>
			<rect x="42" y="82" width="36" height="34" rx="3" fill="#ffffff" opacity=".92"/>
			<text x="60" y="97" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="108" font-family="Arial" font-size="6" fill="#b08d2f" text-anchor="middle">SERUM</text>
		</svg>',

		'mist' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g3" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0" stop-color="#eaf2ee"/><stop offset="1" stop-color="#cfe3d8"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="150" rx="24" ry="6" fill="#00000012"/>
			<rect x="38" y="60" width="44" height="82" rx="10" fill="url(#g3)" stroke="#5c7a5e" stroke-width="1.5"/>
			<rect x="50" y="34" width="20" height="30" rx="3" fill="#5c7a5e"/>
			<path d="M46 34 L74 20 L78 26 L50 40 Z" fill="#3f5a41"/>
			<rect x="44" y="88" width="32" height="30" rx="3" fill="#ffffff" opacity=".92"/>
			<text x="60" y="102" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="112" font-family="Arial" font-size="6" fill="#5c7a5e" text-anchor="middle">TONIC</text>
		</svg>',

		'jar' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g4" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0" stop-color="#f3f1ec"/><stop offset="1" stop-color="#d8d2bf"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="140" rx="34" ry="7" fill="#00000012"/>
			<rect x="26" y="60" width="68" height="70" rx="14" fill="url(#g4)" stroke="#8a6d3a" stroke-width="1.5"/>
			<rect x="26" y="60" width="68" height="16" rx="8" fill="#8a6d3a"/>
			<rect x="38" y="90" width="44" height="30" rx="3" fill="#ffffff" opacity=".92"/>
			<text x="60" y="103" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="114" font-family="Arial" font-size="6" fill="#8a6d3a" text-anchor="middle">NIGHT</text>
		</svg>',

		'pump' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g5" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0" stop-color="#eef1ec"/><stop offset="1" stop-color="#c9d6c4"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="150" rx="28" ry="6" fill="#00000012"/>
			<rect x="32" y="55" width="56" height="90" rx="10" fill="url(#g5)" stroke="#5c7a5e" stroke-width="1.5"/>
			<rect x="50" y="30" width="20" height="28" rx="3" fill="#3f5a41"/>
			<rect x="56" y="16" width="8" height="16" rx="2" fill="#3f5a41"/>
			<rect x="40" y="82" width="40" height="32" rx="3" fill="#ffffff" opacity=".92"/>
			<text x="60" y="96" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="107" font-family="Arial" font-size="6" fill="#5c7a5e" text-anchor="middle">CLEANSER</text>
		</svg>',

		'jar-gel' => '<svg viewBox="0 0 120 160" width="88%" height="88%">
			<defs><linearGradient id="g6" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0" stop-color="#f5eef0"/><stop offset="1" stop-color="#e4c9cf"/>
			</linearGradient></defs>
			<ellipse cx="60" cy="140" rx="34" ry="7" fill="#00000012"/>
			<rect x="26" y="60" width="68" height="70" rx="14" fill="url(#g6)" stroke="#a15b68" stroke-width="1.5"/>
			<rect x="26" y="60" width="68" height="16" rx="8" fill="#a15b68"/>
			<rect x="38" y="90" width="44" height="30" rx="3" fill="#ffffff" opacity=".92"/>
			<text x="60" y="103" font-family="Arial" font-size="7" fill="#111" text-anchor="middle" font-weight="700">KLAR&amp;GLO</text>
			<text x="60" y="114" font-family="Arial" font-size="6" fill="#a15b68" text-anchor="middle">GEL CREAM</text>
		</svg>',
	);

	return isset( $illustrations[ $type ] ) ? $illustrations[ $type ] : sc_product_fallback_icon();
}

/**
 * Custom nav walker: appends a "featured product" panel with image
 * to the first-level dropdown of any top-level menu item that has children.
 */
class SC_Nav_Walker extends Walker_Nav_Menu {
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		if ( 0 === $depth ) {
			$image = get_theme_mod( 'sc_megamenu_image', '' );
			$title = get_theme_mod( 'sc_megamenu_title', '' );
			$url   = get_theme_mod( 'sc_megamenu_url', '#' );
			if ( $image && $title ) {
				$output .= '<li class="sc-mega-featured"><a href="' . esc_url( $url ) . '"><span class="sc-mega-featured-img"><img src="' . esc_url( $image ) . '" alt="' . esc_attr( $title ) . '"></span><span class="sc-mega-featured-title">' . esc_html( $title ) . '</span></a></li>';
			}
		}
		$output .= "</ul>\n";
	}
}

/**
 * Bundled placeholder product photo shipped with the theme, used until a
 * real featured image is set on the product itself.
 */
function sc_product_bundled_image( $slug ) {
	$known = array(
		'klar-glo-sunscreen',
		'klar-glo-glow-serum',
		'klar-glo-skin-tonic',
		'klar-glo-night-cream',
		'klar-glo-hydrating-cleanser',
		'klar-glo-hydra-gel-cream',
	);
	if ( in_array( $slug, $known, true ) ) {
		return get_template_directory_uri() . '/assets/img/products/' . $slug . '.png';
	}
	return '';
}

/**
 * Returns ready-to-use <img> or <svg> markup for a product thumbnail:
 * real featured image > bundled placeholder photo > generic SVG icon.
 */
function sc_product_thumb_markup( $post_id, $title = '' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail( $post_id, 'large', array( 'sizes' => '(max-width: 768px) 60vw, 25vw' ) );
	}
	$slug    = get_post_field( 'post_name', $post_id );
	$bundled = sc_product_bundled_image( $slug );
	if ( $bundled ) {
		return '<img src="' . esc_url( $bundled ) . '" alt="' . esc_attr( $title ) . '" loading="lazy">';
	}
	return '<span class="sc-illustration">' . sc_product_illustration( $slug ) . '</span>';
}

function sc_render_announcement_bar() {
	$raw = get_theme_mod( 'sc_announce_messages', "Free shipping on orders over ₹1500" );
	$lines = array_filter( array_map( 'trim', explode( "\n", $raw ) ) );
	if ( empty( $lines ) ) return;
	echo '<div class="sc-announce"><div class="sc-announce-track" data-sc-announce>';
	foreach ( $lines as $i => $line ) {
		printf( '<span class="%s">%s</span>', $i === 0 ? 'is-active' : '', esc_html( $line ) );
	}
	echo '</div></div>';
}

/**
 * Output a simple product-style grid.
 * Works with WooCommerce products if active, otherwise falls back
 * to regular posts so the theme is usable without WooCommerce.
 *
 * @param int    $count   Number of items.
 * @param string $heading Section heading.
 * @param string $view_all_url
 */
function sc_render_bestsellers( $count = 8, $heading = 'Bestsellers', $view_all_url = '#' ) {
	echo '<div class="sc-grid-head"><h2>' . esc_html( $heading ) . '</h2><a href="' . esc_url( $view_all_url ) . '">' . esc_html__( 'View All', 'skincare-clean' ) . '</a></div>';

	echo '<div class="sc-carousel" data-sc-carousel>';
	echo '<button type="button" class="sc-carousel-arrow sc-carousel-prev" data-sc-carousel-prev aria-label="' . esc_attr__( 'Previous products', 'skincare-clean' ) . '">' . sc_carousel_arrow_svg( 'left' ) . '</button>';

	if ( class_exists( 'WooCommerce' ) ) {
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => $count,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'post_status'    => 'publish',
		);
		$q = new WP_Query( $args );
		echo '<div class="sc-product-grid" data-sc-carousel-track>';
		if ( $q->have_posts() ) {
			while ( $q->have_posts() ) { $q->the_post();
				global $product;
				echo '<div class="sc-product-card">';
				if ( $product && $product->is_on_sale() ) echo '<span class="sc-product-badge">' . esc_html__( 'Sale', 'skincare-clean' ) . '</span>';
				echo '<a href="' . esc_url( get_permalink() ) . '" class="sc-product-thumb">' . sc_product_thumb_markup( get_the_ID(), get_the_title() ) . '</a>';
				echo '<div class="sc-product-title">' . esc_html( get_the_title() ) . '</div>';
				if ( $product ) echo '<div class="sc-product-price">' . $product->get_price_html() . '</div>';
				echo '<a href="' . esc_url( get_permalink() ) . '" class="sc-btn">' . esc_html__( 'View Product', 'skincare-clean' ) . '</a>';
				echo '</div>';
			}
			wp_reset_postdata();
		}
		echo '</div>';
	} else {
		$q = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => $count ) );
		echo '<div class="sc-product-grid" data-sc-carousel-track>';
		if ( $q->have_posts() ) {
			while ( $q->have_posts() ) { $q->the_post();
				echo '<div class="sc-product-card">';
				echo '<a href="' . esc_url( get_permalink() ) . '" class="sc-product-thumb">' . ( has_post_thumbnail() ? get_the_post_thumbnail( get_the_ID(), 'large', array( 'sizes' => '(max-width: 768px) 60vw, 25vw' ) ) : sc_product_fallback_icon() ) . '</a>';
				echo '<div class="sc-product-title">' . esc_html( get_the_title() ) . '</div>';
				echo '<div class="sc-product-sub">' . esc_html( get_the_excerpt() ) . '</div>';
				echo '<a href="' . esc_url( get_permalink() ) . '" class="sc-btn">' . esc_html__( 'Read More', 'skincare-clean' ) . '</a>';
				echo '</div>';
			}
			wp_reset_postdata();
		}
		echo '</div>';
	}

	echo '<button type="button" class="sc-carousel-arrow sc-carousel-next" data-sc-carousel-next aria-label="' . esc_attr__( 'Next products', 'skincare-clean' ) . '">' . sc_carousel_arrow_svg( 'right' ) . '</button>';
	echo '</div>';
}

/**
 * Small left/right chevron SVG used by the bestsellers carousel arrows.
 *
 * @param string $dir 'left' or 'right'.
 */
function sc_carousel_arrow_svg( $dir = 'right' ) {
	$path = ( 'left' === $dir ) ? 'M15 18l-6-6 6-6' : 'M9 18l6-6-6-6';
	return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="' . $path . '"></path></svg>';
}
