<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Rich per-product content used on the single product page:
 * subtitle, feature checkmarks, key actives & benefits, how-to-use,
 * and the full ingredient list — sourced from the actual product
 * carton copy provided for KLAR & GLO.
 */
function sc_product_details_data() {
	return array(

		'klar-glo-sunscreen' => array(
			'subtitle'  => 'Broad Spectrum SPF, Non-Comedogenic',
			'short_desc' => 'A lightweight, white-cast-free Korean sunscreen with broad spectrum protection. Formulated with 2% Niacinamide, 1% Rice Ferment, 2% Orange Extract and 1% Ginseng Exosome, it helps control sebum, soothe the skin, reduce the look of hyperpigmentation and strengthen the skin barrier. Non-comedogenic.',
			'features'  => array( 'White Cast Free', 'Non-Comedogenic', 'Broad Spectrum Protection', 'Lightweight Formula' ),
			'actives'   => array( 'Niacinamide 2%', 'Rice Ferment 1%', 'Orange Extract 2%', 'Ginseng Exosome 1% (Korean)' ),
			'active_details' => array(
				array( 'name' => 'Niacinamide 2%', 'desc' => 'Helps reduce the appearance of hyperpigmentation and strengthens the skin barrier.' ),
				array( 'name' => 'Rice Ferment 1%', 'desc' => 'Helps brighten and refine skin texture while delivering antioxidant support.' ),
				array( 'name' => 'Orange Extract 2%', 'desc' => 'Helps even out skin tone and adds a boost of vitamin C-rich antioxidant protection.' ),
				array( 'name' => 'Ginseng Exosome 1% (Korean)', 'desc' => "Helps calm inflammation and supports the skin's natural renewal process." ),
			),
			'benefits'  => array( 'Controls sebum', 'Soothes inflammation', 'Reduces hyperpigmentation', 'Strengthens skin barrier', 'Targets dullness', 'Soothes & calms skin' ),
			'how_to_use'=> 'Apply generously and evenly to the face, neck, and other exposed skin areas. Use at least 15 minutes before sun exposure. Reapply every 2 hours for continued protection, especially after swimming, excessive sweating, or towel drying.',
			'ingredients' => 'Purified Water, Ethylhexyl Methoxycinnamate & Butyl Methoxydibenzoylmethane & Benzophenone-3 & Phospholipids & 1,3-Butylene Glycol, Citrus Aurantium Dulcis (Orange) Fruit Extract, Curcuma Longa Root Extract, Glycerin, Titanium Dioxide, Cetearyl Olivate & Sorbitan Olivate, Zinc Oxide, Panax Ginseng Root Extract & Panax Ginseng Vesicles & Hexanediol & Water, Oryza Sativa (Rice) Extract, Phenoxyethanol, Carbomer, Allantoin, Tocopheryl Acetate, Sodium Gluconate, Fragrance.',
			'potent' => 'Controls Sebum, Soothes Inflammation, Reduces Hyperpigmentation, Strengthens Skin Barrier, Targets Dullness, Soothes & Calms Skin.',
			'caution' => 'For external use only. Keep out of reach of children. Avoid direct contact with eyes. In case of contact, rinse thoroughly with water. Perform a patch test before first use. Discontinue use if irritation, redness, or discomfort occurs.',
		),

		'klar-glo-glow-serum' => array(
			'subtitle'  => '10% Niacinamide Brightening Serum',
			'short_desc' => 'A potent brightening serum with 10% Niacinamide, 2% Alpha Arbutin and 2% Ginseng Exosome, supported by Copper Peptide, Zinc PCA and Hyaluronic Acid. It penetrates deep to repair the skin barrier, fade dark spots, even out skin tone and target dullness.',
			'features'  => array( 'Barrier Repair', 'Deep Penetration', 'Brightens & Evens Tone' ),
			'actives'   => array( 'Niacinamide 10%', 'Ginseng Exosome 2%', 'Alpha Arbutin 2%', 'Copper Peptide 1%', 'Collaplant 1%', 'Zinc PCA 1%', 'Prodew 600 0.2%', 'Hyaluronic Acid 1%' ),
			'active_details' => array(
				array( 'name' => 'Niacinamide 10%', 'desc' => 'Helps brighten skin tone and visibly reduce the appearance of dark spots.' ),
				array( 'name' => 'Ginseng Exosome 2%', 'desc' => "Helps support deep skin renewal and enhances the skin's overall radiance." ),
				array( 'name' => 'Alpha Arbutin 2%', 'desc' => 'Helps fade the appearance of dark spots and even out skin tone.' ),
				array( 'name' => 'Copper Peptide 1%', 'desc' => "Helps support the skin's natural repair process for a firmer-looking complexion." ),
				array( 'name' => 'Collaplant 1%', 'desc' => 'Helps improve skin elasticity and supports a plumper, smoother appearance.' ),
				array( 'name' => 'Zinc PCA 1%', 'desc' => 'Helps balance oil production and refine the look of pores.' ),
				array( 'name' => 'Prodew 600 0.2%', 'desc' => "Helps strengthen the skin's moisture barrier for lasting hydration." ),
				array( 'name' => 'Hyaluronic Acid 1%', 'desc' => 'Provides lightweight hydration to keep skin dewy and smooth.' ),
			),
			'benefits'  => array( 'Brightens & evens skin tone', 'Fades dark spots', 'Targets dullness', 'Deep barrier repair' ),
			'how_to_use'=> 'Cleanse your face thoroughly and pat dry. Apply 2–3 drops of serum onto the face and neck. Gently massage until fully absorbed. Follow with moisturizer and sunscreen. Use twice daily for best results.',
			'ingredients' => 'Purified Water, Niacinamide, Panax Ginseng Root Extract & Panax Ginseng Vesicles & Hexanediol & Water, Alpha Arbutin, Glycerin, Hydrolyzed Adansonia Digitata Seed Extract & Hydrolyzed Soy Protein & Proline & Rice Amino Acids, Zinc Pyrrolidone Carboxylic Acid, Hyaluronic Acid & Hydrolyzed Hyaluronic Acid & Sodium Hyaluronate & Hydrolyzed Sodium Hyaluronate & Potassium Hyaluronate & Sodium Acetylated Hyaluronate & Hydroxypropyltrimonium Hyaluronate & Sodium Hyaluronate Crosspolymer & Dimethylsilanol Hyaluronate & Hydrolyzed Calcium Hyaluronate & Sodium Sulfated Hyaluronate & Sodium Stearoyl Hyaluronate & Sodium Oleoyl Hyaluronate & 1,2-Hexanediol & Ethylhexylglycerin & Water, Copper Tripeptide-1 & Water & Propanediol, D-Panthenol, Phenoxyethanol & Ethylhexylglycerin, Hexanediol, Betaine & Sodium PCA & Sodium Lactate & PCA & Serine & Alanine & Glycine & Glutamic Acid & Lysine HCl & Threonine & Arginine & Proline & Water, Ethylene Diamine Tetra Acetic Acid, Fragrance.',
			'potent' => 'Barrier Repair, Deep Penetration, Brightens & Evens Skin Tone, Fades Dark Spots, Targets Dullness.',
			'caution' => 'For External Use only. Keep out of reach of children. Avoid contact with eyes. If product gets into eyes, rinse thoroughly with water. Patch test recommended. Discontinue use if irritation occurs.',
		),

		'klar-glo-skin-tonic' => array(
			'subtitle'  => 'Hydrating Face Mist with Centella Asiatica',
			'short_desc' => 'A refreshing, skin-reviving face mist with Korean-inspired actives to hydrate, soothe and visibly brighten skin through the day. 2% Centella Asiatica (Korea) calms irritation and supports the barrier, 5% Niacinamide refines texture and tone, while Sea Buckthorn, Rice Extract, Amino Acids, Hyaluronic Acid and Ceramides add antioxidant protection, glow and lasting hydration.',
			'features'  => array( 'Calms Irritation', 'Strengthens Barrier', 'Antioxidant Protection' ),
			'actives'   => array( '2% Centella Asiatica Extract (Korea)', '5% Niacinamide', '2% Sea Buckthorn Extract', '1% Rice Extract with Amino Acids', 'Hyaluronic Acid', 'Ceramides' ),
			'active_details' => array(
				array( 'name' => 'Centella Asiatica Extract 2% (Korea)', 'desc' => 'Helps soothe irritation and supports a calmer, more resilient skin barrier.' ),
				array( 'name' => 'Niacinamide 5%', 'desc' => 'Helps refine texture and even out the appearance of skin tone.' ),
				array( 'name' => 'Sea Buckthorn Extract 2%', 'desc' => 'Helps deliver antioxidant protection and supports a natural, healthy glow.' ),
				array( 'name' => 'Rice Extract with Amino Acids 1%', 'desc' => 'Helps nourish and brighten skin while softening texture.' ),
				array( 'name' => 'Hyaluronic Acid', 'desc' => 'Helps attract and retain moisture for plump, hydrated skin.' ),
				array( 'name' => 'Ceramides', 'desc' => 'Helps reinforce the skin barrier and lock in long-lasting hydration.' ),
			),
			'benefits'  => array( 'Hydrates & soothes', 'Brightens skin tone', 'Reduces dullness', 'Refines texture', 'Long-lasting moisture retention' ),
			'how_to_use'=> 'Spray the mist evenly onto your face from a 6-8 inch distance with your eyes closed. Use it on freshly cleansed skin before applying serum/moisturizer, or anytime during the day to refresh and hydrate. Can also be applied over makeup. Allow it to absorb naturally into the skin — no need to wipe or pat.',
			'ingredients' => 'Purified Water, Niacinamide, Centella Asiatica Leaf Extract, Sea Buckthorn Extract, Propanediol, Betaine, Glycerin, Oryza Sativa (Rice) Seed Extract, 1,2-Hexanediol, Betaine & Sodium PCA & Sodium Lactate & PCA & Serine & Alanine & Glycine & Glutamic Acid & Lysine HCl & Threonine & Arginine & Proline & Water, Laminaria Digitata Extract & Cetyl-PG Hydroxyethyl Palmitamide & Ceramide 1 & Ceramide 2 & Ceramide 3 & Ceramide 4 & Ceramide 6, Sodium Hyaluronate & Hydroxypropyltrimonium Hyaluronate & Hydrolyzed Sodium Hyaluronate & Hydrolyzed Calcium Hyaluronate & Sodium Sulfated Hyaluronate & Sodium Acetylated Hyaluronate & Hydrolyzed Hyaluronic Acid & Dimethylsilanol Hyaluronate & Sodium Hyaluronate Crosspolymer & Hyaluronic Acid & Sodium Stearoyl Hyaluronate & Sodium Oleoyl Hyaluronate & Potassium Hyaluronate, Phenoxyethanol, Sodium Pyrrolidone Carboxylic Acid, Dipotassium Glycyrrhizate, Ethylene Diamine Tetraacetic Acid, Carbomer, Sodium Citrate, Fragrance.',
			'potent' => 'A refreshing, skin-reviving face mist formulated with Korean-inspired actives to hydrate, soothe, and visibly brighten the skin throughout the day. Infused with 2% Centella Asiatica Extract (Korea), this mist helps calm irritation and strengthen the skin barrier, while 5% Niacinamide works to improve skin tone, reduce dullness, and refine texture. Powered by Sea Buckthorn Extract and Rice Extract, it delivers antioxidant protection and a natural glow, enhancing skin radiance over time. The addition of Amino Acids, Hyaluronic Acid, and Ceramides ensures deep hydration, moisture retention, and long-lasting barrier support.',
			'caution' => 'For External Use Only. Keep out of reach of children. Avoid contact with eyes. If product gets into eyes, rinse thoroughly with water. Patch test recommended. Discontinue use if irritation occurs.',
		),

		'klar-glo-night-cream' => array(
			'subtitle'  => 'Overnight Repair with Retinol & Rose PDRN',
			'short_desc' => 'An advanced overnight repair moisturiser that deeply nourishes, hydrates and rejuvenates skin while you sleep. With 0.2% Retinol, Ceramides and 2% Rose PDRN, it helps improve skin texture, reduce fine lines and support skin regeneration, while Hyaluronic Acid 4D gives multi-layer hydration and botanical extracts soothe the barrier.',
			'features'  => array( 'Barrier Repair', 'Multi-Layer Hydration', 'Overnight Regeneration' ),
			'actives'   => array( '0.2% Apple Stem Cell Extract', '1% Orchid Extract', '0.5% Ceramides Complex', '1% Centella Asiatica Extract', '0.2% Retinol', '2% Rose PDRN', 'Hyaluronic Acid 4D' ),
			'active_details' => array(
				array( 'name' => 'Apple Stem Cell Extract', 'desc' => 'Helps support skin renewal and promotes a smoother, firmer, more youthful-looking appearance.' ),
				array( 'name' => 'Orchid Extract', 'desc' => 'Helps nourish and hydrate the skin while supporting a radiant, healthy-looking complexion.' ),
				array( 'name' => 'Ceramide Complex', 'desc' => 'Helps strengthen the skin barrier and lock in moisture for soft, supple-looking skin.' ),
				array( 'name' => 'Centella Asiatica Extract', 'desc' => 'Helps soothe and calm the skin while supporting skin barrier health.' ),
				array( 'name' => 'Retinol', 'desc' => 'Helps improve the appearance of fine lines, uneven texture, and dull-looking skin.' ),
				array( 'name' => 'Rose PDRN', 'desc' => 'Helps support skin renewal and promotes a smoother, revitalized, and healthy-looking complexion.' ),
				array( 'name' => 'Hyaluronic Acid 4D', 'desc' => 'Provides multi-level hydration to help keep skin plump, smooth, and deeply moisturized.' ),
			),
			'benefits'  => array( 'Improves skin texture', 'Reduces fine lines', 'Supports skin regeneration', 'Multi-layer hydration', 'Strengthens skin barrier' ),
			'how_to_use'=> 'Apply as the last step of your night routine, after cleansing and serum. Massage gently onto face and neck. As with any Retinol product, introduce gradually (2-3 nights a week initially) and always follow with sunscreen the next morning.',
			'ingredients' => 'Purified Water, Sodium DNA & Rosa Damascena Flower Extract & Butylene Glycol & 1,2-Hexanediol & Ethylhexylglycerin & Water, Citrullus Lanatus (Watermelon) Fruit Extract & Water & Glycerin, Cetearyl Olivate & Sorbitan Olivate, Glycerin, Propanediol, Butylene Glycol, Carbomer, Capric/Caprylic Triglyceride, Isopropyl Myristate, Centella Asiatica Leaf Extract, Orchid Extract, Dimethicone, Polyglyceryl-3 Methylglucose Distearate, Laminaria Digitata Extract & Cetyl-PG Hydroxyethyl Palmitamide & Ceramide 1 & Ceramide 2 & Ceramide 3 & Ceramide 4 & Ceramide 6, Sodium Hyaluronate Crosspolymer & Sodium Hyaluronate & Sodium Acetylated Hyaluronate & Hydrolyzed Sodium Hyaluronate & Pentylene Glycol & Ethylhexylglycerin & Aqua, D-Panthenol, Polyacrylate-13 & Polyisobutene & Polysorbate 20, Dipotassium Glycyrrhizate, Allantoin, Malus Domestica Fruit Cell Culture Extract & Xanthan Gum & Glycerin & Lecithin & Phenoxyethanol & Aqua, Retinol & Polysorbate 20, Tocopheryl Acetate, Phenoxyethanol, Pentaerythrityl Tetra-di-t-butyl Hydroxyhydrocinnamate, Butyl Hydroxytoluene, Ethylene Diamine Tetraacetic Acid, Fragrance.',
			'potent' => 'This Night Moisturiser is an advanced overnight repair formula designed to deeply nourish, hydrate, and rejuvenate the skin while you sleep. Enriched with Retinol, Ceramides, and PDRN, it helps improve skin texture, reduce fine lines, and support skin regeneration. Hyaluronic Acid-4D provides multi-layer hydration, while botanical extracts soothe and strengthen the skin barrier.',
			'caution' => 'For External Use only. Keep out of reach of children. Avoid contact with eyes. If product gets into eyes, rinse thoroughly with water. Patch test recommended. Discontinue use if irritation occurs.',
		),

		'klar-glo-hydrating-cleanser' => array(
			'subtitle'  => 'Gentle Daily Cleanser — Paraben & Sulphate Free',
			'short_desc' => 'A gentle, sulphate-free and paraben-free cleanser that removes dirt, oil and pollution while keeping skin hydrated. Enriched with Fermented Rice Water, Sea Buckthorn, Moringa, 2% Centella Asiatica and 2% Niacinamide, plus Hyaluronic Acid and Ceramides, it brightens, improves texture, supports the barrier and reduces sensitivity.',
			'features'  => array( 'Paraben Free', 'Sulphate Free', 'Barrier Repair' ),
			'actives'   => array( 'Fermented Rice Water 1%', 'Sea Buckthorn Extract 2%', 'Moringa Extract 1%', 'Centella Asiatica Extract 2%', 'Niacinamide 2%', 'Hyaluronic Acid (HA 13D) 0.2%', 'Ceramide Complex 0.2%' ),
			'active_details' => array(
				array( 'name' => 'Fermented Rice Water 1%', 'desc' => 'Helps gently brighten skin and soften texture.' ),
				array( 'name' => 'Sea Buckthorn Extract 2%', 'desc' => 'Helps deliver antioxidant nourishment while cleansing.' ),
				array( 'name' => 'Moringa Extract 1%', 'desc' => 'Helps purify and nourish skin without stripping moisture.' ),
				array( 'name' => 'Centella Asiatica Extract 2%', 'desc' => 'Helps calm sensitivity and supports a healthy skin barrier.' ),
				array( 'name' => 'Niacinamide 2%', 'desc' => 'Helps even out tone and refine the look of pores as you cleanse.' ),
				array( 'name' => 'Hyaluronic Acid (HA 13D) 0.2%', 'desc' => 'Helps maintain hydration even during cleansing.' ),
				array( 'name' => 'Ceramide Complex 0.2%', 'desc' => 'Helps reinforce the skin barrier and prevent moisture loss.' ),
			),
			'benefits'  => array( 'Removes dirt, oil and pollution', 'Brightens and hydrates skin', 'Improves skin texture', 'Reduces sensitivity' ),
			'how_to_use'=> 'Take a small amount of cleanser, apply on clean face & neck, and gently massage into the skin. Rinse thoroughly with water. Use morning and night.',
			'ingredients' => 'Purified Water, Decyl Glucoside, Cocamidopropyl Betaine, Niacinamide, Centella Asiatica Leaf Extract, Sea Buckthorn Extract, 1,3-Propanediol, Moringa Oleifera Seed Oil, Oryza Sativa (Rice) Seed Water, Glycerin, Phenoxyethanol, D-Panthenol, Allantoin, Hydroxyethyl Acrylate/Sodium Acryloyldimethyl Taurate Copolymer, Sodium Hyaluronate & Hydroxypropyltrimonium Hyaluronate & Hydrolyzed Sodium Hyaluronate & Hydrolyzed Calcium Hyaluronate & Sodium Sulfated Hyaluronate & Sodium Acetylated Hyaluronate & Hydrolyzed Hyaluronic Acid & Dimethylsilanol Hyaluronate & Sodium Hyaluronate Crosspolymer & Hyaluronic Acid & Sodium Stearoyl Hyaluronate & Sodium Oleoyl Hyaluronate & Potassium Hyaluronate, Laminaria Digitata Extract & Cetyl-PG Hydroxyethyl Palmitamide & Ceramide 1 & Ceramide 2 & Ceramide 3 & Ceramide 4 & Ceramide 6, Sodium PCA, Vitamin E Millicapsules, Butylated Hydroxytoluene, Disodium EDTA, Lactic Acid, Fragrance.',
			'potent' => 'Removes dirt, oil and pollution. Brightens and hydrates skin. Improves skin texture. Reduces sensitivity. Barrier Repair. Paraben Free. Sulphate Free.',
			'caution' => 'For External Use only. Keep out of reach of children. Avoid contact with eyes. If product gets into eyes, rinse thoroughly with water. Patch test recommended. Discontinue use if irritation occurs.',
		),

		'klar-glo-hydra-gel-cream' => array(
			'subtitle'  => 'Lightweight Gel-Cream with Vitamin C & Pomegranate',
			'short_desc' => 'A lightweight gel-cream packed with 2% Pomegranate Extract, 1% Vitamin C, Vitamin E, 1% Multi-Vitamin Complex, 2% Centella, 0.5% Hyaluronic Acid, 1% Pentavitin and 2% Aquaxyl. It plumps and firms, locks in moisture, brightens skin tone, boosts radiance and protects against environmental stress.',
			'features'  => array( 'Plumps & Firms', 'Boosts Radiance', 'Environmental Protection' ),
			'actives'   => array( '2% Pomegranate Extract', '1% Vitamin C', 'Vitamin E', '1% Multi-Vitamin Complex', '2% Centella Extract', '0.5% Hyaluronic Acid', '1% Pentavitin', '2% Aquaxyl' ),
			'active_details' => array(
				array( 'name' => 'Pomegranate Extract 2%', 'desc' => 'Helps deliver antioxidant protection for a firmer, more radiant look.' ),
				array( 'name' => 'Vitamin C 1%', 'desc' => 'Helps brighten skin tone and defend against environmental stress.' ),
				array( 'name' => 'Vitamin E', 'desc' => 'Helps nourish and protect skin from free-radical damage.' ),
				array( 'name' => 'Multi-Vitamin Complex 1%', 'desc' => 'Helps replenish skin with essential nutrients for a healthy glow.' ),
				array( 'name' => 'Centella Extract 2%', 'desc' => "Helps soothe skin and support the barrier's resilience." ),
				array( 'name' => 'Hyaluronic Acid 0.5%', 'desc' => 'Helps plump skin with lightweight, lasting hydration.' ),
				array( 'name' => 'Pentavitin 1%', 'desc' => 'Helps maintain long-term moisture balance for smoother skin.' ),
				array( 'name' => 'Aquaxyl 2%', 'desc' => "Helps improve the skin's natural moisture retention over time." ),
			),
			'benefits'  => array( 'Plumps and firms', 'Moisture retention', 'Brightens skin tone', 'Boosts radiance', 'Protects against environmental stress' ),
			'how_to_use'=> 'Apply a small amount to clean face and neck, morning and/or evening, gently massaging until fully absorbed. Follow with sunscreen during the day.',
			'ingredients' => 'Aqua, Glycerin, Propanediol, Caprylic/Capric Triglyceride, Cetearyl Alcohol, Cetyl Alcohol, Phenoxyethanol, Carbomer, Tocopheryl Acetate, Sodium Ascorbyl Phosphate, Punica Granatum Extract, Centella Asiatica Extract, Sodium Hyaluronate, Saccharide Isomerate, Xylitylglucoside, Anhydroxylitol, Xylitol, Panthenol, Allantoin, Tocopherol, Sodium Hydroxide, Ethylhexylglycerin, Disodium EDTA, Parfum.',
			'potent' => 'Plumps and firms. Moisture retention. Brightens skin tone. Boosts radiance. Protects against environmental stress.',
			'caution' => 'For External Use only. Keep out of reach of children. Avoid contact with eyes. If product gets into eyes, rinse thoroughly with water. Patch test recommended. Discontinue use if irritation occurs.',
		),
	);
}

/**
 * Star rating row under the product title.
 * Uses WooCommerce's REAL review data (average rating + review count),
 * so numbers update automatically as customers post reviews. With no
 * reviews yet it shows empty stars + a "Be the first to review" link.
 * Replaces WooCommerce's default rating output (removed below).
 */
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );

/**
 * Genuine ratings from other platforms (leave empty until you have real numbers).
 * Example:  'klar-glo-sunscreen' => array( 'rating' => 4.3, 'reviews' => 87 ),
 */
function sc_product_rating_overrides() {
	return array(
		'klar-glo-sunscreen'         => array( 'rating' => '5', 'reviews' => '7' ),
		'klar-glo-glow-serum'        => array( 'rating' => '4', 'reviews' => '6' ),
		'klar-glo-skin-tonic'        => array( 'rating' => '6', 'reviews' => '8' ),
		'klar-glo-night-cream'       => array( 'rating' => '4', 'reviews' => '9' ),
		'klar-glo-hydrating-cleanser'=> array( 'rating' => '7', 'reviews' => '10' ),
		'klar-glo-hydra-gel-cream'   => array( 'rating' => '6', 'reviews' => '11' ),
	);
}

function sc_render_product_rating_row() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$count  = (int) $product->get_review_count();
	$avg    = (float) $product->get_average_rating();

	// Optional: genuine rating from another platform (Amazon / Nykaa / etc.).
	// Fill 'rating' and 'reviews' in sc_product_rating_overrides() below — ONLY with
	// real numbers. Used only while the store itself has no reviews for the product.
	if ( 0 === $count ) {
		$slug = get_post_field( 'post_name', $product->get_id() );
		$ov   = sc_product_rating_overrides();
		if ( isset( $ov[ $slug ] ) && ! empty( $ov[ $slug ]['rating'] ) && ! empty( $ov[ $slug ]['reviews'] ) ) {
			$avg   = (float) $ov[ $slug ]['rating'];
			$count = (int) $ov[ $slug ]['reviews'];
		}
	}
	$pct    = $count > 0 ? max( 0, min( 100, ( $avg / 5 ) * 100 ) ) : 0;
	$star = 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z';
	$mk = function ( $fill ) use ( $star ) {
	$out = '';

	for ( $i = 0; $i < 5; $i++ ) {
		$out .= '<svg viewBox="0 0 24 24" width="18" height="18" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:inline-block;vertical-align:middle;flex-shrink:0;">';
		$out .= '<path fill="' . esc_attr( $fill ) . '" d="' . esc_attr( $star ) . '"/>';
		$out .= '</svg>';
	}

	return $out;
};
	echo "\n<!-- sc-rating-row -->\n";
	echo '<div class="sc-rating-row" style="display:flex;align-items:center;gap:10px;margin:0 0 12px;">';
	echo '<span class="sc-stars" role="img" aria-label="' . esc_attr( sprintf( __( 'Rated %s out of 5', 'skincare-clean' ), number_format_i18n( $avg, 1 ) ) ) . '" style="position:relative;display:inline-block;line-height:0;white-space:nowrap;">';
	echo '<span class="sc-stars-base" style="display:inline-block;white-space:nowrap;">' . $mk( '#d8d8d8' ) . '</span>';
	echo '<span class="sc-stars-fill" style="position:absolute;top:0;left:0;height:100%;overflow:hidden;width:' . esc_attr( $pct ) . '%;"><span class="sc-stars-inner" style="display:inline-block;white-space:nowrap;">' . $mk( '#F5A623' ) . '</span></span>';
	echo '</span>';
	if ( $count > 0 ) {
		echo '<a class="sc-rating-count woocommerce-review-link" href="#reviews" style="font-size:14px;font-weight:600;">' . esc_html( number_format_i18n( $count ) ) . ' ' . esc_html( _n( 'Review', 'Reviews', $count, 'skincare-clean' ) ) . '</a>';
	} else {
		echo '<a class="sc-rating-count woocommerce-review-link" href="#reviews" style="font-size:14px;font-weight:600;">' . esc_html__( 'Be the first to review', 'skincare-clean' ) . '</a>';
	}
	echo '</div>';
}
add_action( 'woocommerce_single_product_summary', 'sc_render_product_rating_row', 6 );

/**
 * Part 1: subtitle + brief description + feature checkmarks — shown right
 * after the title and star rating, before the price.
 */
function sc_render_product_subtitle_features() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$slug = get_post_field( 'post_name', $product->get_id() );
	$data = sc_product_details_data();
	if ( ! isset( $data[ $slug ] ) ) {
		return;
	}
	$d = $data[ $slug ];
	if ( ! empty( $d['subtitle'] ) ) {
		echo '<p class="sc-product-subtitle">' . esc_html( $d['subtitle'] ) . '</p>';
	}
	if ( ! empty( $d['short_desc'] ) ) {
		echo '<p class="sc-product-short-desc">' . esc_html( $d['short_desc'] ) . '</p>';
	}
	if ( ! empty( $d['features'] ) ) {
		echo '<ul class="sc-feature-checks">';
		foreach ( $d['features'] as $f ) {
			echo '<li><svg viewBox="0 0 16 16" width="14" height="14"><path d="M2 8l4 4 8-8" fill="none" stroke="#5c7a5e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>' . esc_html( $f ) . '</li>';
		}
		echo '</ul>';
	}
}
add_action( 'woocommerce_single_product_summary', 'sc_render_product_subtitle_features', 8 );

/**
 * Right-column accordions shown directly under Add to Cart — sourced
 * strictly from the product carton copy (Benefits, Directions For Use,
 * Caution), no invented marketing claims.
 */
function sc_render_product_cart_accordions() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$slug = get_post_field( 'post_name', $product->get_id() );
	$data = sc_product_details_data();
	if ( ! isset( $data[ $slug ] ) ) {
		return;
	}
	$d = $data[ $slug ];
	?>
	<div class="sc-accordion sc-accordion-cart">
		<?php if ( ! empty( $d['potent'] ) ) : ?>
		<!--details class="sc-accordion-item">
			<summary><?php esc_html_e( 'What Makes It Potent?', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body"><p><?php echo esc_html( $d['potent'] ); ?></p></div>
		</details-->
		<?php endif; ?>

		<?php if ( ! empty( $d['benefits'] ) ) : ?>
		<details class="sc-accordion-item">
			<summary><?php esc_html_e( 'Benefits', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body">
				<ul class="sc-plain-list">
					<?php foreach ( $d['benefits'] as $benefit ) : ?>
						<li><?php echo esc_html( $benefit ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</details>
		<?php endif; ?>

		<?php if ( ! empty( $d['how_to_use'] ) ) : ?>
		<details class="sc-accordion-item">
			<summary><?php esc_html_e( 'How to Use', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body"><p><?php echo esc_html( $d['how_to_use'] ); ?></p></div>
		</details>
		<?php endif; ?>

		<?php if ( ! empty( $d['caution'] ) ) : ?>
		<details class="sc-accordion-item">
			<summary><?php esc_html_e( 'Caution', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body"><p><?php echo esc_html( $d['caution'] ); ?></p></div>
		</details>
		<?php endif; ?>

		<details class="sc-accordion-item">
			<summary><?php esc_html_e( 'Shipping & Returns', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body">
				<p><?php esc_html_e( 'Free shipping on orders above ₹1,500. Orders are typically dispatched within 1–2 business days and delivered within 4–7 business days depending on your location.', 'skincare-clean' ); ?></p>
				<p><?php esc_html_e( 'If you receive a damaged, defective, or incorrect product, you can request a return or replacement within 7 days of delivery. Please read our full Return & Refund Policy for eligibility details.', 'skincare-clean' ); ?></p>
			</div>
		</details>
	</div>
	<?php
}
add_action( 'woocommerce_single_product_summary', 'sc_render_product_cart_accordions', 32 );

/**
 * Collapsible sections: Key Actives / All Ingredients — shown full width,
 * in the same place the old "Description" tab used to sit (below the
 * image + summary columns, above Related Products).
 */
function sc_render_product_accordions() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$slug = get_post_field( 'post_name', $product->get_id() );
	$data = sc_product_details_data();
	$d    = isset( $data[ $slug ] ) ? $data[ $slug ] : array();
	if ( empty( $d['active_details'] ) && empty( $d['ingredients'] ) ) {
		return;
	}
	?>
	<div class="sc-accordion sc-accordion-fullwidth">
		<?php if ( ! empty( $d['active_details'] ) ) : ?>
		<details class="sc-accordion-item sc-accordion-item-lg" open>
			<summary><?php esc_html_e( 'Key Actives', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body sc-nested-accordion">
				<?php foreach ( $d['active_details'] as $active ) : ?>
					<details class="sc-accordion-item sc-accordion-item-sm">
						<summary><?php echo esc_html( $active['name'] ); ?></summary>
						<div class="sc-accordion-body"><p><?php echo esc_html( $active['desc'] ); ?></p></div>
					</details>
				<?php endforeach; ?>
			</div>
		</details>
		<?php endif; ?>

		<?php if ( ! empty( $d['ingredients'] ) ) : ?>
		<details class="sc-accordion-item">
			<summary><?php esc_html_e( 'All Ingredients', 'skincare-clean' ); ?></summary>
			<div class="sc-accordion-body"><p class="sc-ingredients-list"><?php echo esc_html( $d['ingredients'] ); ?></p></div>
		</details>
		<?php endif; ?>
	</div>
	<?php
}
add_action( 'woocommerce_after_single_product_summary', 'sc_render_product_accordions', 5 );


/**
 * ---------------------------------------------------------------
 * REVIEWS TAB — rating summary generated automatically from the
 * REAL ratings customers have submitted (average, % by star, and a
 * short plain-language summary), followed by the normal WooCommerce
 * review list + form. Nothing here is invented: with no reviews it
 * simply invites the first one.
 * ---------------------------------------------------------------
 */
function sc_reviews_tab_content() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$count  = (int) $product->get_review_count();
	$avg    = (float) $product->get_average_rating();
	$counts = $product->get_rating_counts(); // array( 5 => n, 4 => n, ... )

	echo '<div class="sc-review-summary">';
	if ( $count > 0 ) {
		$high = 0;
		foreach ( array( 4, 5 ) as $r ) {
			$high += isset( $counts[ $r ] ) ? (int) $counts[ $r ] : 0;
		}
		$high_pct = $count ? round( ( $high / max( 1, array_sum( $counts ) ) ) * 100 ) : 0;

		if ( $avg >= 4.5 ) {
			$line = __( 'Customers love this product — almost every reviewer rated it highly.', 'skincare-clean' );
		} elseif ( $avg >= 4 ) {
			$line = __( 'Most customers are happy with this product.', 'skincare-clean' );
		} elseif ( $avg >= 3 ) {
			$line = __( 'Customers have had mixed experiences with this product.', 'skincare-clean' );
		} else {
			$line = __( 'Some customers were not satisfied with this product — read the reviews below.', 'skincare-clean' );
		}

		echo '<div class="sc-review-score">';
		echo '<div class="sc-review-avg">' . esc_html( number_format_i18n( $avg, 1 ) ) . '<small>/5</small></div>';
		echo '<div class="sc-review-meta">';
		echo '<div class="sc-review-count">' . esc_html( sprintf( _n( 'Based on %s review', 'Based on %s reviews', $count, 'skincare-clean' ), number_format_i18n( $count ) ) ) . '</div>';
		echo '<p class="sc-review-line">' . esc_html( $line ) . ' ' . esc_html( sprintf( __( '%d%% gave 4 stars or more.', 'skincare-clean' ), $high_pct ) ) . '</p>';
		echo '</div></div>';

		echo '<div class="sc-review-bars">';
		$total = max( 1, array_sum( $counts ) );
		for ( $r = 5; $r >= 1; $r-- ) {
			$n   = isset( $counts[ $r ] ) ? (int) $counts[ $r ] : 0;
			$pct = round( ( $n / $total ) * 100 );
			echo '<div class="sc-review-bar"><span>' . esc_html( $r ) . '&#9733;</span><i><b style="width:' . esc_attr( $pct ) . '%"></b></i><em>' . esc_html( $n ) . '</em></div>';
		}
		echo '</div>';
		echo '<p class="sc-review-note">' . esc_html__( 'Summary is generated automatically from customer ratings.', 'skincare-clean' ) . '</p>';
	} else {
		echo '<p class="sc-review-line">' . esc_html__( 'No reviews yet — be the first to share your experience.', 'skincare-clean' ) . '</p>';
	}
	echo '</div>';

	comments_template();
}
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	if ( isset( $tabs['reviews'] ) ) {
		$tabs['reviews']['callback'] = 'sc_reviews_tab_content';
	}
	return $tabs;
}, 20 );


/**
 * ---------------------------------------------------------------
 * PINCODE / DELIVERY CHECK (single product page, under Add to Cart)
 * Validates a 6-digit Indian pincode, looks up the area via the free
 * India Post lookup (cached 30 days) and shows an estimated delivery
 * window (4-7 business days, same as the Shipping & Returns text).
 *
 * To block specific pincodes:
 *   add_filter( 'sc_unserviceable_pincodes', fn() => array( '194101' ) );
 * To turn the box off (e.g. a pincode plugin is already installed):
 *   add_filter( 'sc_enable_pincode_box', '__return_false' );
 * ---------------------------------------------------------------
 */
function sc_render_pincode_checker() {
	if ( ! apply_filters( 'sc_enable_pincode_box', true ) ) {
		return;
	}
	?>
	<div class="sc-pin-check" data-sc-pin-check>
		<label class="sc-pin-label" for="sc-pin-input">
			<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
			<?php esc_html_e( 'Check delivery', 'skincare-clean' ); ?>
		</label>
		<div class="sc-pin-row">
			<input id="sc-pin-input" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="postal-code" placeholder="<?php esc_attr_e( 'Enter 6-digit pincode', 'skincare-clean' ); ?>" data-sc-pin-input>
			<button type="button" data-sc-pin-btn><?php esc_html_e( 'Check', 'skincare-clean' ); ?></button>
		</div>
		<p class="sc-pin-msg" role="status" aria-live="polite" data-sc-pin-msg></p>
	</div>
	<?php
}
add_action( 'woocommerce_single_product_summary', 'sc_render_pincode_checker', 12 );

function sc_add_business_days( $days ) {
	$ts = time();
	while ( $days > 0 ) {
		$ts += DAY_IN_SECONDS;
		if ( (int) wp_date( 'N', $ts ) < 7 ) { // skip Sundays (store timezone)
			$days--;
		}
	}
	return $ts;
}

function sc_ajax_check_pincode() {
	$pin = isset( $_POST['pincode'] ) ? preg_replace( '/\D/', '', wp_unslash( $_POST['pincode'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! preg_match( '/^[1-9][0-9]{5}$/', $pin ) ) {
		wp_send_json( array( 'ok' => false, 'message' => __( 'Please enter a valid 6-digit pincode.', 'skincare-clean' ) ) );
	}

	$blocked = (array) apply_filters( 'sc_unserviceable_pincodes', array() );
	if ( in_array( $pin, $blocked, true ) ) {
		wp_send_json( array( 'ok' => false, 'message' => __( 'Sorry, we do not deliver to this pincode yet.', 'skincare-clean' ) ) );
	}

	$place = get_transient( 'sc_pin_' . $pin );
	if ( false === $place ) {
		$place    = '';
		$response = wp_remote_get( 'https://api.postalpincode.in/pincode/' . $pin, array( 'timeout' => 6 ) );
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$data = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $data ) && isset( $data[0]['Status'] ) ) {
				if ( 'Success' === $data[0]['Status'] && ! empty( $data[0]['PostOffice'][0] ) ) {
					$po    = $data[0]['PostOffice'][0];
					$place = trim( ( isset( $po['District'] ) ? $po['District'] : '' ) . ', ' . ( isset( $po['State'] ) ? $po['State'] : '' ), ' ,' );
					set_transient( 'sc_pin_' . $pin, $place, 30 * DAY_IN_SECONDS );
				} elseif ( 'Error' === $data[0]['Status'] || 'Success' !== $data[0]['Status'] ) {
					set_transient( 'sc_pin_' . $pin, 'INVALID', DAY_IN_SECONDS );
					$place = 'INVALID';
				}
			}
		}
	}
	if ( 'INVALID' === $place ) {
		wp_send_json( array( 'ok' => false, 'message' => __( 'We could not find this pincode. Please check and try again.', 'skincare-clean' ) ) );
	}

	$from = wp_date( 'D, j M', sc_add_business_days( 4 ) );
	$to   = wp_date( 'D, j M', sc_add_business_days( 7 ) );
	wp_send_json( array(
		'ok'      => true,
		'place'   => $place,
		'message' => sprintf( __( 'Delivery available. Estimated delivery: %1$s – %2$s.', 'skincare-clean' ), $from, $to ),
	) );
}
add_action( 'wp_ajax_sc_check_pincode', 'sc_ajax_check_pincode' );
add_action( 'wp_ajax_nopriv_sc_check_pincode', 'sc_ajax_check_pincode' );

/**
 * Product page gallery (self-contained: markup + CSS + JS all come from this file,
 * so it works even if style.css / main.js are cached or not updated).
 * Thumbnails on the LEFT, big image on the right; arrows, swipe, counter and
 * full-screen zoom. Uses the featured image + the "Product gallery" images
 * set in the WooCommerce product editor.
 */
function sc_render_product_gallery() {
	static $assets_done = false;
	global $product;
	if ( ! $product ) {
		return;
	}
	$ids     = array();
	$main_id = $product->get_image_id();
	if ( $main_id ) {
		$ids[] = (int) $main_id;
	}
	foreach ( $product->get_gallery_image_ids() as $gid ) {
		$ids[] = (int) $gid;
	}
	$ids    = array_values( array_unique( $ids ) );
	$slides = array();
	foreach ( $ids as $id ) {
		$full = wp_get_attachment_image_src( $id, 'full' );
		if ( ! $full ) {
			continue;
		}
		$thumb = wp_get_attachment_image_src( $id, 'medium' );
		$alt   = get_post_meta( $id, '_wp_attachment_image_alt', true );
		$slides[] = array(
			'id'    => $id,
			'full'  => $full[0],
			'thumb' => $thumb ? $thumb[0] : $full[0],
			'alt'   => $alt ? $alt : $product->get_name(),
		);
	}
	if ( empty( $slides ) ) {
		$slug = get_post_field( 'post_name', $product->get_id() );
		$fb   = function_exists( 'sc_product_bundled_image' ) ? sc_product_bundled_image( $slug ) : '';
		$src  = $fb ? $fb : wc_placeholder_img_src( 'woocommerce_single' );
		$slides[] = array( 'id' => 0, 'full' => $src, 'thumb' => $src, 'alt' => $product->get_name() );
	}
	$n = count( $slides );
	echo "\n<!-- sc-gal -->\n";
	?>
	<div class="sc-gal<?php echo $n < 2 ? ' sc-gal--single' : ''; ?>" data-sc-gal>
		<?php if ( $n > 1 ) : ?>
			<div class="sc-gal-thumbs-wrap">
				<div class="sc-gal-thumbs" data-sc-gal-thumbs>
					<?php foreach ( $slides as $i => $s ) : ?>
						<button type="button" class="sc-gal-thumb<?php echo 0 === $i ? ' is-active' : ''; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show image %d', 'skincare-clean' ), $i + 1 ) ); ?>">
							<img src="<?php echo esc_url( $s['thumb'] ); ?>" alt="" loading="lazy">
						</button>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="sc-gal-stage">
			<div class="sc-gal-track" data-sc-gal-track>
				<?php foreach ( $slides as $i => $s ) : ?>
					<div class="sc-gal-slide" data-full="<?php echo esc_url( $s['full'] ); ?>">
						<?php
						if ( $s['id'] ) {
							echo wp_get_attachment_image( $s['id'], 'large', false, array(
								'class'    => 'sc-gal-img',
								'alt'      => $s['alt'],
								'loading'  => 0 === $i ? 'eager' : 'lazy',
								'decoding' => 'async',
								'sizes'    => '(max-width: 900px) 80vw, 40vw',
							) );
						} else {
							echo '<img class="sc-gal-img" src="' . esc_url( $s['full'] ) . '" alt="' . esc_attr( $s['alt'] ) . '">';
						}
						?>
					</div>
				<?php endforeach; ?>
			</div>
			<button type="button" class="sc-gal-zoom" data-sc-gal-zoom aria-label="<?php esc_attr_e( 'View full size', 'skincare-clean' ); ?>">
				<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2M11 8v6M8 11h6"/></svg>
			</button>
			<?php if ( $n > 1 ) : ?>
				<button type="button" class="sc-gal-arrow prev" data-sc-gal-prev aria-label="<?php esc_attr_e( 'Previous image', 'skincare-clean' ); ?>">&#8249;</button>
				<button type="button" class="sc-gal-arrow next" data-sc-gal-next aria-label="<?php esc_attr_e( 'Next image', 'skincare-clean' ); ?>">&#8250;</button>
				<div class="sc-gal-count" data-sc-gal-count>1 / <?php echo esc_html( $n ); ?></div>
			<?php endif; ?>
		</div>
	</div>
	<?php
	if ( ! $assets_done ) {
		$assets_done = true;
		echo '<style id="sc-gal-css">' . <<<'SC_GAL_CSS_END'
/* Product page gallery: thumbnails on the LEFT, big image on the right */
.sc-single-product .sc-gal{ display:grid; grid-template-columns:88px minmax(0,1fr); gap:14px; align-items:start; width:100% !important; float:none !important; margin:0 !important; min-width:0; }
.sc-single-product .sc-gal.sc-gal--single{ grid-template-columns:minmax(0,1fr); }
.sc-gal-thumbs-wrap{ position:relative; align-self:stretch; min-height:0; }
.sc-gal-thumbs{ position:absolute; inset:0; display:flex; flex-direction:column; gap:10px; overflow-y:auto; scrollbar-width:none; }
.sc-gal-thumbs::-webkit-scrollbar{ display:none; }
.sc-gal-thumb{ flex:0 0 auto; width:100%; aspect-ratio:4 / 5; padding:0; background:#fff; border:1px solid #e6e6e6; cursor:pointer; opacity:.65; transition:opacity .2s, border-color .2s; }
.sc-gal-thumb:hover{ opacity:1; }
.sc-gal-thumb.is-active{ border-color:#111; opacity:1; }
.sc-single-product .sc-gal-thumb img{ width:100%; height:100%; object-fit:cover; display:block; aspect-ratio:auto; }
.sc-gal-stage{ position:relative; overflow:hidden; background:#fff; border:1px solid #e6e6e6; aspect-ratio:4 / 5; min-width:0; }
.sc-gal-track{ display:flex; height:100%; transition:transform .45s cubic-bezier(.65,0,.35,1); will-change:transform; touch-action:pan-y; }
.sc-gal-slide{ flex:0 0 100%; width:100%; height:100%; cursor:zoom-in; background:#fff; }
.sc-single-product .sc-gal-slide img.sc-gal-img{ width:100%; height:100%; display:block; object-fit:contain; aspect-ratio:auto; }
.sc-gal-arrow{ position:absolute; top:50%; transform:translateY(-50%); width:42px; height:42px; border-radius:50%; border:1px solid #e6e6e6; background:rgba(255,255,255,.92); color:#111; font-size:24px; line-height:1; cursor:pointer; display:flex; align-items:center; justify-content:center; padding:0 0 3px; z-index:3; }
.sc-gal-arrow:hover{ background:#fff; }
.sc-gal-arrow.prev{ left:12px; } .sc-gal-arrow.next{ right:12px; }
.sc-gal-count{ position:absolute; left:12px; bottom:12px; background:rgba(255,255,255,.92); border:1px solid #e6e6e6; border-radius:20px; padding:3px 12px; font-size:12px; font-weight:600; z-index:3; }
.sc-gal-zoom{ position:absolute; top:12px; right:12px; width:38px; height:38px; border-radius:50%; border:1px solid #e6e6e6; background:rgba(255,255,255,.92); color:#111; cursor:pointer; display:flex; align-items:center; justify-content:center; z-index:3; padding:0; }
@media (max-width:600px){
  .sc-single-product .sc-gal{ grid-template-columns:56px minmax(0,1fr); gap:8px; }
  .sc-gal-thumbs{ gap:8px; }
  .sc-gal-arrow{ width:34px; height:34px; font-size:20px; }
}
.sc-gal-lb{ position:fixed; inset:0; background:rgba(255,255,255,.98); z-index:99999; display:none; align-items:center; justify-content:center; }
.sc-gal-lb.is-open{ display:flex; }
.sc-gal-lb img{ max-width:92vw; max-height:90vh; object-fit:contain; }
.sc-gal-lb-close{ position:absolute; top:14px; right:18px; font-size:38px; line-height:1; background:none; border:0; cursor:pointer; color:#111; }
.sc-gal-lb-arrow{ position:absolute; top:50%; transform:translateY(-50%); width:46px; height:46px; border-radius:50%; border:1px solid #e6e6e6; background:#fff; font-size:26px; cursor:pointer; padding:0 0 3px; }
.sc-gal-lb-arrow.prev{ left:16px; } .sc-gal-lb-arrow.next{ right:16px; }
.sc-gal-lb.single .sc-gal-lb-arrow{ display:none; }
.sc-gal-lb-count{ position:absolute; bottom:16px; left:50%; transform:translateX(-50%); font-size:13px; font-weight:600; }
body.sc-gal-lb-open{ overflow:hidden; }
SC_GAL_CSS_END
		. '</style>';
		echo '<script id="sc-gal-js">' . <<<'SC_GAL_JS_END'
(function () {
	var galleries = document.querySelectorAll('[data-sc-gal]');
	if (!galleries.length) return;
	var lb, lbImg, lbCount, lbG = null, lbI = 0;
	function buildLb() {
		if (lb) return;
		lb = document.createElement('div');
		lb.className = 'sc-gal-lb';
		lb.innerHTML = '<button type="button" class="sc-gal-lb-close" aria-label="Close">&times;</button>' +
			'<button type="button" class="sc-gal-lb-arrow prev" aria-label="Previous">&#8249;</button>' +
			'<img alt="">' +
			'<button type="button" class="sc-gal-lb-arrow next" aria-label="Next">&#8250;</button>' +
			'<div class="sc-gal-lb-count"></div>';
		document.body.appendChild(lb);
		lbImg = lb.querySelector('img'); lbCount = lb.querySelector('.sc-gal-lb-count');
		lb.querySelector('.sc-gal-lb-close').addEventListener('click', closeLb);
		lb.querySelector('.prev').addEventListener('click', function (e) { e.stopPropagation(); stepLb(-1); });
		lb.querySelector('.next').addEventListener('click', function (e) { e.stopPropagation(); stepLb(1); });
		lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); });
		document.addEventListener('keydown', function (e) {
			if (!lb.classList.contains('is-open')) return;
			if (e.key === 'Escape') closeLb();
			if (e.key === 'ArrowLeft') stepLb(-1);
			if (e.key === 'ArrowRight') stepLb(1);
		});
	}
	function showLb() {
		var sl = lbG.querySelectorAll('.sc-gal-slide');
		lbImg.src = sl[lbI].getAttribute('data-full');
		lbCount.textContent = sl.length > 1 ? (lbI + 1) + ' / ' + sl.length : '';
		lb.classList.toggle('single', sl.length < 2);
	}
	function openLb(g, i) { buildLb(); lbG = g; lbI = i; showLb(); lb.classList.add('is-open'); document.body.classList.add('sc-gal-lb-open'); }
	function closeLb() { lb.classList.remove('is-open'); document.body.classList.remove('sc-gal-lb-open'); }
	function stepLb(d) { var n = lbG.querySelectorAll('.sc-gal-slide').length; lbI = (lbI + d + n) % n; showLb(); }

	galleries.forEach(function (g) {
		if (g.getAttribute('data-sc-init')) return;
		g.setAttribute('data-sc-init', '1');
		var track = g.querySelector('[data-sc-gal-track]');
		var slides = g.querySelectorAll('.sc-gal-slide');
		var thumbs = g.querySelectorAll('.sc-gal-thumb');
		var bar = g.querySelector('[data-sc-gal-thumbs]');
		var count = g.querySelector('[data-sc-gal-count]');
		var n = slides.length, i = 0, moved = false;
		function go(k) {
			i = (k + n) % n;
			track.style.transform = 'translateX(' + (-100 * i) + '%)';
			thumbs.forEach(function (t, idx) {
				t.classList.toggle('is-active', idx === i);
				if (idx === i && bar) {
					bar.scrollTo({ top: t.offsetTop - (bar.clientHeight - t.offsetHeight) / 2, behavior: 'smooth' });
				}
			});
			if (count) count.textContent = (i + 1) + ' / ' + n;
		}
		var prev = g.querySelector('[data-sc-gal-prev]'), next = g.querySelector('[data-sc-gal-next]');
		if (prev) prev.addEventListener('click', function () { go(i - 1); });
		if (next) next.addEventListener('click', function () { go(i + 1); });
		thumbs.forEach(function (t, idx) { t.addEventListener('click', function () { go(idx); }); });
		var sx = 0, sy = 0;
		track.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; moved = false; }, { passive: true });
		track.addEventListener('touchmove', function (e) { if (Math.abs(e.touches[0].clientX - sx) > 10) moved = true; }, { passive: true });
		track.addEventListener('touchend', function (e) {
			var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
			if (n > 1 && Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? i + 1 : i - 1);
		}, { passive: true });
		g.setAttribute('tabindex', '0');
		g.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft') go(i - 1); if (e.key === 'ArrowRight') go(i + 1); });
		slides.forEach(function (s) { s.addEventListener('click', function () { if (!moved) openLb(g, i); }); });
		var z = g.querySelector('[data-sc-gal-zoom]');
		if (z) z.addEventListener('click', function () { openLb(g, i); });
	});
})();
SC_GAL_JS_END
		. '</script>';
	}
}
add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
	remove_action( 'woocommerce_before_single_product_summary', 'sc_render_product_gallery', 20 );
	add_action( 'woocommerce_before_single_product_summary', 'sc_render_product_gallery', 20 );
}, 20 );