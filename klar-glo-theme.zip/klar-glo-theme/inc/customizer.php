<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function sc_customize_register( $wp_customize ) {

	// Panel
	$wp_customize->add_section( 'sc_hero_section', array(
		'title'       => __( 'Homepage Hero Slider', 'skincare-clean' ),
		'priority'    => 30,
		'description' => __( 'Configure up to 3 rotating hero slides. Leave a slide\'s title empty to hide it. Upload an image per slide — if left blank, a colored gradient is used instead.', 'skincare-clean' ),
	) );

	$slide_defaults = array(
		1 => array(
			'title'    => 'Korean-Inspired Skincare, Made Simple.',
			'subtitle' => 'KLAR & GLO formulations are built on Niacinamide, Centella Asiatica and Ginseng Exosome technology — for a clearer, calmer, more radiant barrier.',
			'btn'      => 'Shop Bestsellers',
			'url'      => '#bestsellers',
		),
		2 => array(
			'title'    => 'Broad Spectrum Sun Protection.',
			'subtitle' => 'White-cast free, non-comedogenic Sunscreen with Niacinamide 2% and Korean Ginseng Exosome.',
			'btn'      => 'Shop Sunscreen',
			'url'      => '#sunscreen',
		),
		3 => array(
			'title'    => '10% Niacinamide Glow Serum.',
			'subtitle' => 'Brightens uneven tone, fades dark spots, and repairs the skin barrier.',
			'btn'      => 'Shop Serums',
			'url'      => '#serums',
		),
	);

	$slide_banner_defaults = array(
		1 => 'hero-banner.png',
		2 => 'hero-banner-2.png',
		3 => 'hero-banner-3.png',
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		$d = $slide_defaults[ $i ];

		$wp_customize->add_setting( "sc_hero_slide{$i}_image", array( 'default' => get_template_directory_uri() . '/assets/img/' . $slide_banner_defaults[ $i ] ) );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, "sc_hero_slide{$i}_image_control", array(
			'label'    => sprintf( __( 'Slide %d — Background Image', 'skincare-clean' ), $i ),
			'section'  => 'sc_hero_section',
			'settings' => "sc_hero_slide{$i}_image",
		) ) );

		$wp_customize->add_setting( "sc_hero_slide{$i}_video", array( 'default' => '' ) );
		$wp_customize->add_control( new WP_Customize_Upload_Control( $wp_customize, "sc_hero_slide{$i}_video_control", array(
			'label'       => sprintf( __( 'Slide %d — Background Video (.mp4, optional — overrides image if set)', 'skincare-clean' ), $i ),
			'description' => __( 'Upload a short, silent, looping .mp4 (10–20 seconds works best) — e.g. product close-up, texture swatch, or lifestyle clip.', 'skincare-clean' ),
			'section'     => 'sc_hero_section',
			'settings'    => "sc_hero_slide{$i}_video",
			'mime_type'   => 'video',
		) ) );

		$wp_customize->add_setting( "sc_hero_slide{$i}_title", array( 'default' => $d['title'] ) );
		$wp_customize->add_control( "sc_hero_slide{$i}_title", array(
			'label' => sprintf( __( 'Slide %d — Title (leave blank to hide this slide)', 'skincare-clean' ), $i ),
			'section' => 'sc_hero_section', 'type' => 'text',
		) );

		$wp_customize->add_setting( "sc_hero_slide{$i}_subtitle", array( 'default' => $d['subtitle'] ) );
		$wp_customize->add_control( "sc_hero_slide{$i}_subtitle", array(
			'label' => sprintf( __( 'Slide %d — Subtitle', 'skincare-clean' ), $i ),
			'section' => 'sc_hero_section', 'type' => 'textarea',
		) );

		$wp_customize->add_setting( "sc_hero_slide{$i}_button_text", array( 'default' => $d['btn'] ) );
		$wp_customize->add_control( "sc_hero_slide{$i}_button_text", array(
			'label' => sprintf( __( 'Slide %d — Button Text', 'skincare-clean' ), $i ),
			'section' => 'sc_hero_section', 'type' => 'text',
		) );

		$wp_customize->add_setting( "sc_hero_slide{$i}_button_url", array( 'default' => $d['url'] ) );
		$wp_customize->add_control( "sc_hero_slide{$i}_button_url", array(
			'label' => sprintf( __( 'Slide %d — Button URL', 'skincare-clean' ), $i ),
			'section' => 'sc_hero_section', 'type' => 'text',
		) );
	}

	// Announcement bar
	$wp_customize->add_section( 'sc_announce_section', array(
		'title' => __( 'Announcement Bar', 'skincare-clean' ), 'priority' => 25,
	) );
	$wp_customize->add_setting( 'sc_announce_messages', array(
		'default' => "Free shipping on orders over ₹999\nKorean-inspired formulations, made in India (ISO & GMP Certified)\nPatch test recommended before first use.",
	) );
	$wp_customize->add_control( 'sc_announce_messages', array(
		'label' => __( 'Messages (one per line, rotates automatically)', 'skincare-clean' ),
		'section' => 'sc_announce_section', 'type' => 'textarea',
	) );

	// Mega menu featured product
	$wp_customize->add_section( 'sc_megamenu_section', array(
		'title'       => __( 'Mega Menu Featured Product', 'skincare-clean' ),
		'priority'    => 26,
		'description' => __( 'Shown as a spotlight card inside every dropdown menu with sub-items (like a mega menu). Leave the title empty to hide it.', 'skincare-clean' ),
	) );
	$wp_customize->add_setting( 'sc_megamenu_image', array( 'default' => get_template_directory_uri() . '/assets/img/products/klar-glo-glow-serum.png' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'sc_megamenu_image_control', array(
		'label'    => __( 'Featured Product Image', 'skincare-clean' ),
		'section'  => 'sc_megamenu_section',
		'settings' => 'sc_megamenu_image',
	) ) );
	$wp_customize->add_setting( 'sc_megamenu_title', array( 'default' => 'New: KLAR & GLO Glow Serum' ) );
	$wp_customize->add_control( 'sc_megamenu_title', array(
		'label' => __( 'Featured Product Title', 'skincare-clean' ), 'section' => 'sc_megamenu_section', 'type' => 'text',
	) );
	$wp_customize->add_setting( 'sc_megamenu_url', array( 'default' => '#' ) );
	$wp_customize->add_control( 'sc_megamenu_url', array(
		'label' => __( 'Featured Product Link', 'skincare-clean' ), 'section' => 'sc_megamenu_section', 'type' => 'text',
	) );
	// Homepage promo tiles (Corporate Gift + Klar Glo Rewards)
	$wp_customize->add_section( 'sc_promo_section', array(
		'title'       => __( 'Homepage Promo Tiles', 'skincare-clean' ),
		'priority'    => 27,
		'description' => __( 'The two tiles (Corporate Gift / Klar Glo Rewards) shown under "Build Your Regimen". Leave a link empty to use the page with slug corporate-gift / klar-glo-rewards.', 'skincare-clean' ),
	) );
	$sc_promo_defaults = array(
		1 => array( 'Corporate Gift', 'Premium skincare gift sets for teams & clients', 'Shop Now' ),
		2 => array( 'Klar Glo Rewards', 'Earn & redeem rewards on every purchase', 'Show more' ),
	);
	foreach ( $sc_promo_defaults as $n => $d ) {
		$wp_customize->add_setting( "sc_promo{$n}_image", array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, "sc_promo{$n}_image_control", array(
			/* translators: %d tile number */
			'label' => sprintf( __( 'Tile %d Image', 'skincare-clean' ), $n ), 'section' => 'sc_promo_section', 'settings' => "sc_promo{$n}_image",
		) ) );
		foreach ( array( 'title' => $d[0], 'sub' => $d[1], 'btn' => $d[2], 'url' => '' ) as $f => $def ) {
			$wp_customize->add_setting( "sc_promo{$n}_{$f}", array( 'default' => $def, 'sanitize_callback' => ( 'url' === $f ? 'esc_url_raw' : 'sanitize_text_field' ) ) );
			$wp_customize->add_control( "sc_promo{$n}_{$f}", array(
				'label' => sprintf( __( 'Tile %1$d %2$s', 'skincare-clean' ), $n, ucfirst( 'sub' === $f ? 'subtitle' : ( 'btn' === $f ? 'button text' : ( 'url' === $f ? 'link (optional)' : $f ) ) ) ),
				'section' => 'sc_promo_section', 'type' => 'text',
			) );
		}
	}
}
add_action( 'customize_register', 'sc_customize_register' );
