<?php
/**
 * Mobile-number + OTP login, header live search and site-wide search scope.
 *
 * SMS provider: set it under  Settings > Mobile OTP Login  (Fast2SMS or MSG91),
 * or hook the filter  sc_otp_send_sms( $sent, $phone, $otp )  to use your own gateway.
 * While no provider is set and WP_DEBUG_LOG is on, the OTP is written to wp-content/debug.log
 * (testing only – nothing is shown on screen).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/** ---------------------------------------------------------
 * Helpers
 * --------------------------------------------------------- */
function sc_otp_settings() {
	return wp_parse_args( get_option( 'sc_otp_settings', array() ), array(
		'method'      => 'email',  // email | mobile  (how customers log in with OTP)
		'provider'    => 'none',   // none | fast2sms | msg91 (only used when method = mobile)
		'api_key'     => '',
		'msg91_tpl'   => '',       // MSG91 template id
		'brand'       => 'KLAR & GLO',
		'demo_phones' => '',       // comma separated test numbers
		'demo_otp'    => '123456', // fixed OTP for those numbers
	) );
}

/** Return a clean 10-digit Indian mobile number, or '' when invalid. */
function sc_otp_clean_phone( $raw ) {
	$d = preg_replace( '/\D/', '', (string) $raw );
	if ( strlen( $d ) === 12 && strpos( $d, '91' ) === 0 ) { $d = substr( $d, 2 ); }
	if ( strlen( $d ) === 11 && $d[0] === '0' )            { $d = substr( $d, 1 ); }
	return preg_match( '/^[6-9][0-9]{9}$/', $d ) ? $d : '';
}

/** Current login method: 'email' (OTP by email) or 'mobile' (OTP by SMS). */
function sc_otp_method() {
	$c = sc_otp_settings();
	return 'mobile' === $c['method'] ? 'mobile' : 'email';
}

/** Return a clean lower-case email, or '' when invalid. */
function sc_otp_clean_email( $raw ) {
	$e = strtolower( trim( sanitize_email( (string) $raw ) ) );
	return is_email( $e ) ? $e : '';
}

/** Send the OTP by email. */
function sc_otp_send_email( $email, $otp ) {
	$cfg     = sc_otp_settings();
	$brand   = $cfg['brand'] ? $cfg['brand'] : get_bloginfo( 'name' );
	$subject = sprintf( __( 'Your %s login OTP: %s', 'skincare-clean' ), $brand, $otp );
	$body    = sprintf(
		"Hi,\n\nYour one-time password (OTP) to log in to %s is:\n\n    %s\n\nThis OTP is valid for 5 minutes. Please do not share it with anyone.\nIf you did not request it, you can ignore this email.\n\n- %s",
		$brand, $otp, $brand
	);
	$ok = wp_mail( $email, $subject, $body );
	update_option( 'sc_otp_last_result', gmdate( 'Y-m-d H:i:s' ) . ' UTC | email | ' . ( $ok ? 'wp_mail accepted the message for ' : 'wp_mail FAILED for ' ) . $email, false );
	return (bool) $ok;
}

function sc_otp_client_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
}

/** Count an action against a transient bucket. Returns false when the limit is passed. */
function sc_otp_rate_ok( $key, $limit, $window ) {
	$k = 'sc_otp_rl_' . md5( $key );
	$n = (int) get_transient( $k );
	if ( $n >= $limit ) { return false; }
	set_transient( $k, $n + 1, $window );
	return true;
}

/** Log the SMS gateway's answer so a failed OTP can be diagnosed (wp-content/debug.log, needs WP_DEBUG_LOG). */
function sc_otp_log( $provider, $res ) {
	if ( is_wp_error( $res ) ) { $out = 'WP_Error: ' . $res->get_error_message(); }
	else { $out = 'HTTP ' . wp_remote_retrieve_response_code( $res ) . ' ' . wp_remote_retrieve_body( $res ); }
	update_option( 'sc_otp_last_result', gmdate( 'Y-m-d H:i:s' ) . ' UTC | ' . $provider . ' | ' . $out, false );
	if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) { error_log( '[KLAR&GLO OTP] ' . $provider . ' ' . $out ); }
}

/** ---------------------------------------------------------
 * Sending the SMS
 * --------------------------------------------------------- */
function sc_otp_send_sms( $phone, $otp ) {
	$cfg  = sc_otp_settings();
	$sent = apply_filters( 'sc_otp_send_sms', null, $phone, $otp );
	if ( null !== $sent ) { return (bool) $sent; }

	if ( 'fast2sms' === $cfg['provider'] && $cfg['api_key'] ) {
		$res = wp_remote_post( 'https://www.fast2sms.com/dev/bulkV2', array(
			'timeout' => 15,
			'headers' => array( 'authorization' => $cfg['api_key'], 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( array( 'route' => 'otp', 'variables_values' => $otp, 'numbers' => $phone ) ),
		) );
		sc_otp_log( 'Fast2SMS', $res );
		if ( is_wp_error( $res ) ) { return false; }
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		return ! empty( $body['return'] );
	}

	if ( 'msg91' === $cfg['provider'] && $cfg['api_key'] && $cfg['msg91_tpl'] ) {
		$res = wp_remote_post( 'https://control.msg91.com/api/v5/otp?' . http_build_query( array(
			'template_id' => $cfg['msg91_tpl'], 'mobile' => '91' . $phone, 'otp' => $otp,
		) ), array(
			'timeout' => 15,
			'headers' => array( 'authkey' => $cfg['api_key'], 'Content-Type' => 'application/json' ),
			'body'    => '{}',
		) );
		sc_otp_log( 'MSG91', $res );
		if ( is_wp_error( $res ) ) { return false; }
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		return isset( $body['type'] ) && 'success' === $body['type'];
	}

	sc_otp_log( 'none', new WP_Error( 'cfg', 'No working provider: provider=' . $cfg['provider'] . ', api_key ' . ( $cfg['api_key'] ? 'set' : 'EMPTY' ) . ', msg91_tpl ' . ( $cfg['msg91_tpl'] ? 'set' : 'EMPTY' ) ) );
	// No gateway configured: testing only, write to debug.log.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		error_log( sprintf( '[KLAR&GLO OTP] %s => %s', $phone, $otp ) );
		return true;
	}
	return false;
}

/** ---------------------------------------------------------
 * AJAX: send OTP  (by email or SMS, see Settings > Mobile OTP Login)
 * --------------------------------------------------------- */
function sc_ajax_otp_send() {
	$method = sc_otp_method();

	if ( 'email' === $method ) {
		$id = sc_otp_clean_email( isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' );
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'skincare-clean' ) ) );
		}
	} else {
		$id = sc_otp_clean_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a valid 10-digit mobile number.', 'skincare-clean' ) ) );
		}
	}

	// Abuse limits: 1 OTP / 30s per id, 5 / hour per id, 20 / hour per IP.
	if ( get_transient( 'sc_otp_cool_' . md5( $id ) ) ) {
		wp_send_json_error( array( 'message' => __( 'Please wait 30 seconds before asking for a new OTP.', 'skincare-clean' ) ) );
	}
	if ( ! sc_otp_rate_ok( 'p' . $id, 5, HOUR_IN_SECONDS ) || ! sc_otp_rate_ok( 'ip' . sc_otp_client_ip(), 20, HOUR_IN_SECONDS ) ) {
		wp_send_json_error( array( 'message' => __( 'Too many attempts. Please try again after some time.', 'skincare-clean' ) ) );
	}

	$otp = (string) random_int( 100000, 999999 );

	if ( 'email' === $method ) {
		if ( ! sc_otp_send_email( $id, $otp ) ) {
			wp_send_json_error( array( 'message' => __( 'We could not send the OTP email right now. Please try again shortly.', 'skincare-clean' ) ) );
		}
		$msg = sprintf( __( 'OTP sent to %s', 'skincare-clean' ), $id );
	} else {
		$cfg_demo  = sc_otp_settings();
		$demo_list = array_filter( array_map( 'sc_otp_clean_phone', explode( ',', (string) $cfg_demo['demo_phones'] ) ) );
		$is_demo   = $demo_list && in_array( $id, $demo_list, true ) && preg_match( '/^[0-9]{6}$/', (string) $cfg_demo['demo_otp'] );
		if ( $is_demo ) { $otp = (string) $cfg_demo['demo_otp']; }
		if ( ! $is_demo && ! sc_otp_send_sms( $id, $otp ) ) {
			wp_send_json_error( array( 'message' => __( 'We could not send the OTP right now. Please try again shortly.', 'skincare-clean' ) ) );
		}
		$msg = sprintf( __( 'OTP sent to +91 %s', 'skincare-clean' ), $id );
	}

	set_transient( 'sc_otp_' . md5( $id ), array( 'hash' => wp_hash( $otp . '|' . $id ), 'tries' => 0 ), 5 * MINUTE_IN_SECONDS );
	set_transient( 'sc_otp_cool_' . md5( $id ), 1, 30 );

	wp_send_json_success( array( 'message' => $msg ) );
}
add_action( 'wp_ajax_nopriv_sc_otp_send', 'sc_ajax_otp_send' );
add_action( 'wp_ajax_sc_otp_send', 'sc_ajax_otp_send' );

/** ---------------------------------------------------------
 * AJAX: verify OTP and log the customer in (creating the account the first time)
 * --------------------------------------------------------- */
function sc_otp_find_user_by_phone( $phone ) {
	$users = get_users( array(
		'number'     => 1,
		'meta_query' => array(
			'relation' => 'OR',
			array( 'key' => 'sc_mobile',     'value' => $phone ),
			array( 'key' => 'billing_phone', 'value' => $phone ),
		),
	) );
	return $users ? $users[0] : null;
}

function sc_ajax_otp_verify() {
	$method = sc_otp_method();
	$id     = 'email' === $method
		? sc_otp_clean_email( isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' )
		: sc_otp_clean_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
	$otp    = preg_replace( '/\D/', '', isset( $_POST['otp'] ) ? wp_unslash( $_POST['otp'] ) : '' );
	if ( ! $id || strlen( $otp ) !== 6 ) {
		wp_send_json_error( array( 'message' => __( 'Please enter the 6-digit OTP.', 'skincare-clean' ) ) );
	}

	$key  = 'sc_otp_' . md5( $id );
	$data = get_transient( $key );
	if ( ! $data ) {
		wp_send_json_error( array( 'message' => __( 'This OTP has expired. Please request a new one.', 'skincare-clean' ), 'expired' => true ) );
	}
	if ( $data['tries'] >= 5 ) {
		delete_transient( $key );
		wp_send_json_error( array( 'message' => __( 'Too many wrong attempts. Please request a new OTP.', 'skincare-clean' ), 'expired' => true ) );
	}
	if ( ! hash_equals( $data['hash'], wp_hash( $otp . '|' . $id ) ) ) {
		$data['tries']++;
		set_transient( $key, $data, 5 * MINUTE_IN_SECONDS );
		wp_send_json_error( array( 'message' => __( 'That OTP is not correct. Please check and try again.', 'skincare-clean' ) ) );
	}
	delete_transient( $key ); // single use

	$role = class_exists( 'WooCommerce' ) ? 'customer' : 'subscriber';

	if ( 'email' === $method ) {
		$user = get_user_by( 'email', $id );
		if ( ! $user ) {
			$base  = sanitize_user( strstr( $id, '@', true ), true );
			$login = $base ? $base : 'user';
			while ( username_exists( $login ) ) { $login = $base . wp_rand( 100, 99999 ); }
			$user_id = wp_insert_user( array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => $id,
				'display_name' => $base ? $base : $id,
				'nickname'     => $base ? $base : $id,
				'role'         => $role,
			) );
			if ( is_wp_error( $user_id ) ) {
				wp_send_json_error( array( 'message' => __( 'Could not create your account. Please try again.', 'skincare-clean' ) ) );
			}
			update_user_meta( $user_id, 'billing_email', $id );
			$user = get_user_by( 'id', $user_id );
		}
	} else {
		$user = sc_otp_find_user_by_phone( $id );
		if ( ! $user ) {
			$user_id = wp_insert_user( array(
				'user_login'   => 'u' . $id,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => '', // no email needed; customer can add one in My Account
				'display_name' => '+91 ' . $id,
				'nickname'     => '+91 ' . $id,
				'role'         => $role,
			) );
			if ( is_wp_error( $user_id ) ) {
				wp_send_json_error( array( 'message' => __( 'Could not create your account. Please try again.', 'skincare-clean' ) ) );
			}
			update_user_meta( $user_id, 'sc_mobile', $id );
			update_user_meta( $user_id, 'billing_phone', $id );
			$user = get_user_by( 'id', $user_id );
		}
	}

	// Never let this form log anyone in to a privileged account.
	if ( user_can( $user, 'manage_options' ) || user_can( $user, 'edit_others_posts' ) ) {
		wp_send_json_error( array( 'message' => __( 'This account cannot be used for OTP login. Please use the admin login page.', 'skincare-clean' ) ) );
	}

	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, true );
	do_action( 'wp_login', $user->user_login, $user );

	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	$redirect = wp_validate_redirect( $redirect, home_url( '/' ) );
	wp_send_json_success( array( 'redirect' => $redirect ) );
}
add_action( 'wp_ajax_nopriv_sc_otp_verify', 'sc_ajax_otp_verify' );
add_action( 'wp_ajax_sc_otp_verify', 'sc_ajax_otp_verify' );

/** ---------------------------------------------------------
 * Login modal markup (printed from header.php)
 * --------------------------------------------------------- */
function sc_render_otp_login_modal() {
	if ( is_user_logged_in() ) { return; }
	$method = sc_otp_method();
	?>
	<div class="sc-login" data-sc-login data-sc-method="<?php echo esc_attr( $method ); ?>" hidden>
		<div class="sc-login-backdrop" data-sc-login-close></div>
		<div class="sc-login-box" role="dialog" aria-modal="true" aria-labelledby="sc-login-title">
			<button type="button" class="sc-login-x" data-sc-login-close aria-label="<?php esc_attr_e( 'Close', 'skincare-clean' ); ?>">&times;</button>

			<div class="sc-login-step" data-sc-step="phone">
				<h3 id="sc-login-title"><?php esc_html_e( 'Login / Sign up', 'skincare-clean' ); ?></h3>
				<?php if ( 'email' === $method ) : ?>
				<p class="sc-login-sub"><?php esc_html_e( 'Enter your email address and we will send you an OTP.', 'skincare-clean' ); ?></p>
				<label class="sc-login-phone">
					<input type="email" autocomplete="email" autocapitalize="off" spellcheck="false" placeholder="<?php esc_attr_e( 'Email address', 'skincare-clean' ); ?>" data-sc-login-phone>
				</label>
				<?php else : ?>
				<p class="sc-login-sub"><?php esc_html_e( 'Enter your mobile number and we will send you an OTP.', 'skincare-clean' ); ?></p>
				<label class="sc-login-phone">
					<span class="sc-login-cc">+91</span>
					<input type="tel" inputmode="numeric" maxlength="10" autocomplete="tel-national" placeholder="<?php esc_attr_e( 'Mobile number', 'skincare-clean' ); ?>" data-sc-login-phone>
				</label>
				<?php endif; ?>
				<button type="button" class="sc-btn sc-login-btn" data-sc-login-send><?php esc_html_e( 'Send OTP', 'skincare-clean' ); ?></button>
				<p class="sc-login-msg" data-sc-login-msg role="alert"></p>
				<p class="sc-login-terms"><?php esc_html_e( 'By continuing you agree to our Terms & Privacy Policy.', 'skincare-clean' ); ?></p>
			</div>

			<div class="sc-login-step" data-sc-step="otp" hidden>
				<h3><?php esc_html_e( 'Enter OTP', 'skincare-clean' ); ?></h3>
				<p class="sc-login-sub"><span data-sc-login-sentto></span> <button type="button" class="sc-login-link" data-sc-login-change><?php esc_html_e( 'Change', 'skincare-clean' ); ?></button></p>
				<input type="text" class="sc-login-otp" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="------" data-sc-login-otp aria-label="<?php esc_attr_e( 'OTP', 'skincare-clean' ); ?>">
				<button type="button" class="sc-btn sc-login-btn" data-sc-login-verify><?php esc_html_e( 'Verify & Login', 'skincare-clean' ); ?></button>
				<p class="sc-login-msg" data-sc-login-msg2 role="alert"></p>
				<p class="sc-login-resend"><button type="button" class="sc-login-link" data-sc-login-resend disabled><?php esc_html_e( 'Resend OTP', 'skincare-clean' ); ?></button> <span data-sc-login-timer></span></p>
			</div>
		</div>
	</div>
	<?php
}

/** ---------------------------------------------------------
 * Scripts: header search + login behaviour
 * --------------------------------------------------------- */
function sc_header_scripts() {
	wp_enqueue_script( 'skincare-clean-header', get_template_directory_uri() . '/assets/js/header-email.js', array(), SC_THEME_VERSION, true );
	wp_localize_script( 'skincare-clean-header', 'scAuth', array(
		'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
		'loggedIn' => is_user_logged_in(),
		'method'   => sc_otp_method(),
		'isAccount'=> function_exists( 'is_account_page' ) && is_account_page(),
		'checkout' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
	) );
}
add_action( 'wp_enqueue_scripts', 'sc_header_scripts', 20 );

/** On the My Account page for logged-out visitors, open the OTP login instead of the password form. */
add_filter( 'body_class', function ( $c ) {
	if ( ! is_user_logged_in() && function_exists( 'is_account_page' ) && is_account_page() ) { $c[] = 'sc-otp-account'; }
	return $c;
} );

/** ---------------------------------------------------------
 * Live search (header search bar)
 * --------------------------------------------------------- */
function sc_search_post_types() {
	$types = array( 'post', 'page' );
	if ( post_type_exists( 'product' ) ) { $types[] = 'product'; }
	return $types;
}

function sc_ajax_live_search() {
	$term = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	if ( mb_strlen( $term ) < 2 ) { wp_send_json_success( array( 'items' => array() ) ); }

	$q = new WP_Query( array(
		's'              => $term,
		'post_type'      => sc_search_post_types(),
		'post_status'    => 'publish',
		'posts_per_page' => 6,
		'no_found_rows'  => true,
	) );
	$items = array();
	foreach ( $q->posts as $p ) {
		$price = '';
		if ( 'product' === $p->post_type && function_exists( 'wc_get_product' ) ) {
			$prod  = wc_get_product( $p->ID );
			$price = $prod ? wp_strip_all_tags( html_entity_decode( $prod->get_price_html() ) ) : '';
		}
		$obj   = get_post_type_object( $p->post_type );
		$items[] = array(
			'title' => get_the_title( $p ),
			'url'   => get_permalink( $p ),
			'img'   => get_the_post_thumbnail_url( $p, 'thumbnail' ) ?: '',
			'type'  => 'product' === $p->post_type ? __( 'Product', 'skincare-clean' ) : ( 'post' === $p->post_type ? __( 'Blog', 'skincare-clean' ) : __( 'Page', 'skincare-clean' ) ),
			'price' => $price,
		);
	}
	wp_send_json_success( array( 'items' => $items ) );
}
add_action( 'wp_ajax_nopriv_sc_live_search', 'sc_ajax_live_search' );
add_action( 'wp_ajax_sc_live_search', 'sc_ajax_live_search' );

/** Make the normal search results page cover products, blogs and pages. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_search() ) {
		$q->set( 'post_type', sc_search_post_types() );
	}
} );

/** ---------------------------------------------------------
 * Settings page: Settings > Mobile OTP Login
 * --------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( 'Mobile OTP Login', 'Mobile OTP Login', 'manage_options', 'sc-otp', 'sc_otp_settings_page' );
} );
add_action( 'admin_init', function () {
	register_setting( 'sc_otp_group', 'sc_otp_settings', array(
		'sanitize_callback' => function ( $in ) {
			return array(
				'method'    => 'mobile' === ( $in['method'] ?? '' ) ? 'mobile' : 'email',
				'provider'  => in_array( $in['provider'] ?? '', array( 'none', 'fast2sms', 'msg91' ), true ) ? $in['provider'] : 'none',
				'api_key'   => sanitize_text_field( $in['api_key'] ?? '' ),
				'msg91_tpl' => sanitize_text_field( $in['msg91_tpl'] ?? '' ),
				'brand'     => sanitize_text_field( $in['brand'] ?? 'KLAR & GLO' ),
				'demo_phones' => sanitize_text_field( $in['demo_phones'] ?? '' ),
				'demo_otp'    => preg_match( '/^[0-9]{6}$/', $in['demo_otp'] ?? '' ) ? $in['demo_otp'] : '123456',
			);
		},
	) );
} );
function sc_otp_settings_page() {
	$c = sc_otp_settings();
	?>
	<div class="wrap">
		<h1>Mobile OTP Login</h1>
		<p>Choose the SMS service that will deliver the OTP to your customers.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'sc_otp_group' ); ?>
			<table class="form-table">
				<tr><th>Login method</th><td>
					<select name="sc_otp_settings[method]">
						<option value="email"  <?php selected( $c['method'], 'email' ); ?>>Email + OTP (OTP is sent by email, no SMS service needed)</option>
						<option value="mobile" <?php selected( $c['method'], 'mobile' ); ?>>Mobile number + OTP (needs an SMS provider below)</option>
					</select>
					<p class="description">Email OTP uses WordPress mail. For reliable delivery install an SMTP plugin (e.g. WP Mail SMTP).</p></td></tr>
				<tr><th>SMS provider</th><td>
					<select name="sc_otp_settings[provider]">
						<option value="none"     <?php selected( $c['provider'], 'none' ); ?>>None (testing: OTP goes to debug.log)</option>
						<option value="fast2sms" <?php selected( $c['provider'], 'fast2sms' ); ?>>Fast2SMS</option>
						<option value="msg91"    <?php selected( $c['provider'], 'msg91' ); ?>>MSG91</option>
					</select></td></tr>
				<tr><th>API key / Auth key</th><td><input type="password" class="regular-text" name="sc_otp_settings[api_key]" value="<?php echo esc_attr( $c['api_key'] ); ?>" autocomplete="off"></td></tr>
				<tr><th>MSG91 Template ID</th><td><input type="text" class="regular-text" name="sc_otp_settings[msg91_tpl]" value="<?php echo esc_attr( $c['msg91_tpl'] ); ?>"><p class="description">Only needed for MSG91 (DLT-approved OTP template).</p></td></tr>
				<tr><th>Demo / test numbers</th><td><input type="text" class="regular-text" name="sc_otp_settings[demo_phones]" value="<?php echo esc_attr( $c['demo_phones'] ); ?>" placeholder="9876543210, 9123456780"><p class="description">These numbers skip the SMS and log in with the fixed demo OTP below. Leave empty to turn demo mode off. Do not use a number you do not control, and remove it before launch.</p></td></tr>
				<tr><th>Demo OTP (6 digits)</th><td><input type="text" class="small-text" maxlength="6" name="sc_otp_settings[demo_otp]" value="<?php echo esc_attr( $c['demo_otp'] ); ?>"></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<h2>Last SMS attempt</h2>
		<p><code style="white-space:pre-wrap;display:block;padding:10px;background:#fff"><?php echo esc_html( get_option( 'sc_otp_last_result', 'No OTP has been sent yet.' ) ); ?></code></p>
		<p class="description">Send a test OTP from the website, then reload this page. The line above is the exact reply from the SMS service.</p>
	</div>
	<?php
}
