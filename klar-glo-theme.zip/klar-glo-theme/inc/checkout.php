<?php
/**
 * KLAR & GLO – Checkout customisation
 *  - Email ki jagah Mobile number (WooCommerce Block Checkout)
 *  - Checkout page ka naya design
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Mobile-only checkout ke liye placeholder email ka domain (apne domain se badal sakte ho). */
if ( ! defined( 'KG_PLACEHOLDER_EMAIL_DOMAIN' ) ) {
	define( 'KG_PLACEHOLDER_EMAIL_DOMAIN', 'guest.klarglo.in' );
}

/** Sirf checkout page par CSS + JS load karo */
function kg_checkout_assets() {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_wc_endpoint_url( 'order-received' ) ) {
		return;
	}
	$dir = get_template_directory();
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'kg-checkout', $uri . '/assets/css/checkout.css', array( 'skincare-clean-style' ), filemtime( $dir . '/assets/css/checkout.css' ) );
	wp_enqueue_script( 'kg-checkout', $uri . '/assets/js/checkout.js', array( 'wp-data', 'wp-dom-ready' ), filemtime( $dir . '/assets/js/checkout.js' ), true );
	wp_localize_script( 'kg-checkout', 'kgCheckout', array(
		'emailDomain' => KG_PLACEHOLDER_EMAIL_DOMAIN,
	) );
}
add_action( 'wp_enqueue_scripts', 'kg_checkout_assets', 30 );

/** Billing phone khali ho to shipping phone copy kar do (admin order me hamesha number dikhe) */
add_action( 'woocommerce_store_api_checkout_update_order_from_request', function ( $order ) {
	if ( ! $order->get_billing_phone() && $order->get_shipping_phone() ) {
		$order->set_billing_phone( $order->get_shipping_phone() );
	}
}, 10, 1 );

/** Placeholder email par mail bhejne ki koshish na ho (bounce se bachne ke liye) */
add_filter( 'pre_wp_mail', function ( $return, $atts ) {
	$to = isset( $atts['to'] ) ? (array) $atts['to'] : array();
	if ( empty( $to ) ) {
		return $return;
	}
	$suffix = '@' . KG_PLACEHOLDER_EMAIL_DOMAIN;
	foreach ( $to as $addr ) {
		if ( substr( strtolower( trim( $addr ) ), -strlen( $suffix ) ) !== $suffix ) {
			return $return; // koi real recipient hai -> normal bhejo
		}
	}
	return true; // sab placeholder hain -> skip
}, 10, 2 );

/**
 * Cart + Checkout: "Free shipping / FREE"  ->  "Shipping / ~~₹55.00~~ FREE"
 * Change the struck-through amount with:
 *   add_filter( 'kg_checkout_shipping_was', fn() => '₹99.00' );
 */
function kg_shipping_row_assets() {
	if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() ) ) {
		return;
	}
	$dir = get_template_directory();
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'kg-shipping-row', $uri . '/assets/css/shipping-row.css', array( 'skincare-clean-style' ), filemtime( $dir . '/assets/css/shipping-row.css' ) );
	wp_enqueue_script( 'kg-shipping-row', $uri . '/assets/js/shipping-row.js', array( 'wp-dom-ready' ), filemtime( $dir . '/assets/js/shipping-row.js' ), true );
	wp_localize_script( 'kg-shipping-row', 'kgShipping', array(
		'was' => apply_filters( 'kg_checkout_shipping_was', "₹55.00" ),
	) );
}
add_action( 'wp_enqueue_scripts', 'kg_shipping_row_assets', 30 );
