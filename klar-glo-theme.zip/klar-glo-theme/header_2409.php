<?php if ( ! defined( 'ABSPATH' ) ) exit; ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="sc-utility-bar">
	<div class="container">
		<a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'skincare-clean' ); ?></a>
		<a href="#"><?php esc_html_e( 'Track Order', 'skincare-clean' ); ?></a>
		<?php if ( is_user_logged_in() ) : ?>
			<a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>"><?php esc_html_e( 'Log Out', 'skincare-clean' ); ?></a>
		<?php else : ?>
			<a href="<?php echo esc_url( wp_login_url() ); ?>"><?php esc_html_e( 'Sign In', 'skincare-clean' ); ?></a>
		<?php endif; ?>
	</div>
</div>

<?php sc_render_announcement_bar(); ?>

<header class="sc-header">
	<div class="sc-header-inner">
		<button class="sc-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'skincare-clean' ); ?>" data-sc-menu-toggle>
			<span></span><span></span><span></span>
		</button>

		<div class="sc-logo">
			<?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
			<?php endif; ?>
		</div>

		<nav class="sc-nav" data-sc-nav>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'fallback_cb'    => 'sc_default_menu',
				'walker'         => new SC_Nav_Walker(),
			) );
			?>
		</nav>

		<div class="sc-header-icons">
			<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="<?php esc_attr_e( 'Search', 'skincare-clean' ); ?>" title="<?php esc_attr_e( 'Search', 'skincare-clean' ); ?>">
				<svg class="sc-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
				<span class="sc-label screen-reader-text"><?php esc_html_e( 'Search', 'skincare-clean' ); ?></span>
			</a>
			<a href="<?php echo esc_url( wp_login_url() ); ?>" aria-label="<?php esc_attr_e( 'Login', 'skincare-clean' ); ?>" title="<?php esc_attr_e( 'Login', 'skincare-clean' ); ?>">
				<svg class="sc-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
				<span class="sc-label screen-reader-text"><?php esc_html_e( 'Login', 'skincare-clean' ); ?></span>
			</a>
			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="sc-cart-link" aria-label="<?php esc_attr_e( 'Cart', 'skincare-clean' ); ?>" title="<?php esc_attr_e( 'Cart', 'skincare-clean' ); ?>">
					<svg class="sc-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
					<span class="sc-label screen-reader-text"><?php esc_html_e( 'Cart', 'skincare-clean' ); ?></span>
					<span class="sc-cart-count"><?php echo esc_html( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span>
				</a>
			<?php else : ?>
				<a href="#" class="sc-cart-link" aria-label="<?php esc_attr_e( 'Cart', 'skincare-clean' ); ?>" title="<?php esc_attr_e( 'Cart', 'skincare-clean' ); ?>">
					<svg class="sc-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
					<span class="sc-label screen-reader-text"><?php esc_html_e( 'Cart', 'skincare-clean' ); ?></span> <span class="sc-cart-count">0</span>
				</a>
			<?php endif; ?>
		</div>
	</div>
</header>

<?php
function sc_default_menu() {
	echo '<ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'skincare-clean' ) . '</a></li>
	<li><a href="shop">' . esc_html__( 'Shop', 'skincare-clean' ) . '</a></li>
	<li><a href="#">' . esc_html__( 'Bestsellers', 'skincare-clean' ) . '</a></li>
	<li><a href="#">' . esc_html__( 'Skin concerns', 'skincare-clean' ) . '</a></li>
	<li><a href="#">' . esc_html__( 'Blogs', 'skincare-clean' ) . '</a></li>
	<li><a href="#">' . esc_html__( 'About', 'skincare-clean' ) . '</a></li></ul>';
}
