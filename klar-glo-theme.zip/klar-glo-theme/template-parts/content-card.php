<?php
/** Blog card used on the blog page, archives and related posts. */
if ( ! defined( 'ABSPATH' ) ) exit;
$cats = get_the_category();
?>
<article <?php post_class( 'sc-post-card' ); ?>>
	<a href="<?php the_permalink(); ?>" class="sc-thumb" aria-hidden="true" tabindex="-1">
		<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'large', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) ); else : ?>
			<span class="sc-thumb-fallback">KLAR &amp; GLO</span>
		<?php endif; ?>
	</a>
	<div class="sc-post-body">
		<div class="sc-meta">
			<?php if ( $cats ) : ?><span class="sc-cat"><?php echo esc_html( $cats[0]->name ); ?></span><span class="sc-dot">&middot;</span><?php endif; ?>
			<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		</div>
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<div class="sc-post-excerpt"><?php the_excerpt(); ?></div>
		<a class="sc-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'skincare-clean' ); ?> &rarr;</a>
	</div>
</article>
